import os
import shutil
import subprocess

workspace = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules"
temp_dir = r"C:\Users\Sunil\AppData\Local\Temp\git_sync_temp"

# Clean up temp dir
if os.path.exists(temp_dir):
    shutil.rmtree(temp_dir)
os.makedirs(temp_dir)

# Folders to copy
folders = [
    "collection",
    "defense-impairment",
    "execution",
    "impact",
    "initial-access",
    "lateral-movement",
    "privilege-escalation",
    "exfiltration",
    "reconnaissance",
    "new work"
]

# Files to copy
files = [
    "ocsf_mapped_new_sprint.xlsx",
    "techniques_table.xlsx",
    "unshared_rules_record.md",
    "RED_TEAM_LOG_SOURCE_REQUIREMENTS.md"
]

# Switch to the source branch where all our work is present
print("Switching to source branch: sprint-updates-batch2")
subprocess.run(["git", "checkout", "sprint-updates-batch2"], cwd=workspace, check=True)

# Copy folders to temp
for f in folders:
    src = os.path.join(workspace, f)
    dst = os.path.join(temp_dir, f)
    if os.path.exists(src):
        shutil.copytree(src, dst)
        print(f"Copied folder {f} to temp")

# Copy files to temp
for f in files:
    src = os.path.join(workspace, f)
    dst = os.path.join(temp_dir, f)
    if os.path.exists(src):
        shutil.copy(src, dst)
        print(f"Copied file {f} to temp")

# Checkout new branch main-sprint-updates based on origin/main
print("Checking out main-sprint-updates from origin/main")
subprocess.run(["git", "checkout", "-B", "main-sprint-updates", "origin/main"], cwd=workspace, check=True)

# Move folders from temp to window-correlation-rules/
target_root = os.path.join(workspace, "window-correlation-rules")
os.makedirs(target_root, exist_ok=True)

def copy_recursive(src_dir, dst_dir):
    os.makedirs(dst_dir, exist_ok=True)
    for item in os.listdir(src_dir):
        s = os.path.join(src_dir, item)
        d = os.path.join(dst_dir, item)
        if os.path.isdir(s):
            copy_recursive(s, d)
        else:
            try:
                if os.path.exists(d):
                    os.unlink(d)
                shutil.copy2(s, d)
            except Exception as e:
                print(f"Warning: could not overwrite/copy {d} due to: {e}. Trying write mode...")
                try:
                    with open(s, 'r', encoding='utf-8') as sf, open(d, 'w', encoding='utf-8') as df:
                        df.write(sf.read())
                except Exception as ex:
                    print(f"Error copying {d}: {ex}")

for f in folders:
    src = os.path.join(temp_dir, f)
    dst = os.path.join(target_root, f)
    if os.path.exists(src):
        copy_recursive(src, dst)
        print(f"Restored folder {f} to window-correlation-rules/{f}")

# Move files from temp to workspace root
for f in files:
    src = os.path.join(temp_dir, f)
    dst = os.path.join(workspace, f)
    if os.path.exists(src):
        shutil.copy(src, dst)
        print(f"Restored file {f} to workspace root")

# Clean up temp dir
shutil.rmtree(temp_dir)
print("Sync script finished successfully.")
