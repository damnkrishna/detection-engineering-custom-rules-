import json
import re

file_path = r'C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\credential-access\AN0105-T1555.003-DET0037.md'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

json_match = re.search(r'```json\n(.*?)\n```', content, re.DOTALL)
if json_match:
    json_str = json_match.group(1)
    events = json.loads(json_str)
    
    # Filter out Volume tests
    clean_events = [ev for ev in events if not ev['metadata']['test_case'].startswith('VOL-')]
    
    # Generate clean formatted JSON
    json_lines = ["[\n"]
    for i, ev in enumerate(clean_events):
        json_lines.append("  " + json.dumps(ev, indent=2).replace('\n', '\n  '))
        if i < len(clean_events) - 1:
            json_lines[-1] += ",\n"
        else:
            json_lines[-1] += "\n"
    json_lines.append("]")
    
    new_json_block = "".join(json_lines)
    
    # Replace the old json block
    content = content[:json_match.start()] + "```json\n" + new_json_block + "\n```" + content[json_match.end():]
    
    # Add note about volume testing in the intro of section 5
    old_intro = "The following array contains the raw, OCSF-normalized JSON events that map 1:1 with the Test Cases described in Section 4. This payload can be ingested directly into the Detection Engine pipeline for automated unit testing."
    new_intro = "The following array contains the raw, OCSF-normalized JSON events that map 1:1 with the Test Cases described in Section 4. This payload can be ingested directly into the Detection Engine pipeline for automated unit testing.\n\n*Note on Volume/Stress Testing: To test pipeline throughput and backpressure, take TP-01 and TN-01 from this array and script a generator to replicate them 500+ times with incrementing timestamps and slightly varied fields (like PIDs or temp paths).* "
    content = content.replace(old_intro, new_intro)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
        
    print("Successfully stripped volume tests")
else:
    print("JSON block not found")
