import openpyxl

def inspect_techniques():
    path = "techniques_table.xlsx"
    out_path = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\techniques_table_contents.txt"
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(f"Sheets in techniques_table.xlsx: {wb.sheetnames}\n")
            for name in wb.sheetnames:
                sheet = wb[name]
                f.write(f"\n--- Sheet: {name} ---\n")
                for row in list(sheet.iter_rows(values_only=True)):
                    if any(row):
                        f.write(str(row) + "\n")
        print(f"Techniques table successfully dumped to {out_path}")
    except Exception as e:
        print("Error reading techniques table:", e)

if __name__ == '__main__':
    inspect_techniques()
