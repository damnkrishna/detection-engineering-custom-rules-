import re
import yaml
import sys
import os

def validate_yaml_blocks(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
    if not yaml_blocks:
        print("No YAML blocks found to validate!")
        return True
        
    all_ok = True
    for i, block in enumerate(yaml_blocks, 1):
        try:
            yaml.safe_load(block)
            print(f"YAML block {i} is valid.")
        except Exception as e:
            print(f"Error parsing YAML block {i}: {e}")
            print("Content of failing block:")
            print(block)
            all_ok = False
            
    return all_ok

if __name__ == '__main__':
    impact_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\impact"
    files = [
        "AN0584-T1499-DET0208.md",
        "AN0602-T1486-DET0215.md",
        "AN0662-T1491-DET0238.md",
        "AN0702-T1565.002-DET0254.md",
        "AN0741-T1496-DET0267.md",
        "AN0827-T1561.002-DET0297.md",
        "AN0850-T1499.004-DET0304.md",
        "AN0882-T1561.001-DET0316.md",
        "AN0933-T1490-DET0329.md",
        "AN0969-T1498.001-DET0343.md"
    ]
    all_success = True
    for fname in files:
        f = os.path.join(impact_dir, fname)
        print(f"\nValidating {fname}...")
        success = validate_yaml_blocks(f)
        if not success:
            all_success = False
            
    if not all_success:
        print("\nSome YAML blocks failed validation.")
        sys.exit(1)
    else:
        print("\nAll YAML blocks across all 10 files are syntactically valid!")
