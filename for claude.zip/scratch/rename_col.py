import pandas as pd
import openpyxl

file_path = 'important_files/detection_coverage_matrix_final.xlsx'
wb = openpyxl.load_workbook(file_path)
ws = wb.active

# Find header row
header_row_idx = 1
for r_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=5), start=1):
    vals = [cell.value for cell in row]
    if 'Name / Category' in vals:
        header_row_idx = r_idx
        break

headers = {cell.value: idx for idx, cell in enumerate(ws[header_row_idx])}
config_col = headers.get('Needs IT Setup? (Y/N)')
if config_col is None:
    config_col = headers.get('Needs Config Change (Y/N)')

if config_col is not None:
    ws.cell(row=header_row_idx, column=config_col+1).value = 'Needs Log/API Config? (Y/N)'
    wb.save(file_path)

    # Export to CSV
    df = pd.read_excel(file_path, skiprows=header_row_idx-1)
    df.to_csv('important_files/detection_coverage_matrix_final.csv', index=False)
    print("Column renamed successfully.")
else:
    print("Could not find the target column.")
