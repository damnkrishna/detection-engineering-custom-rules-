import os
import openpyxl

def inspect_trackers():
    xlsx_files = [f for f in os.listdir('.') if f.endswith('.xlsx')]
    print("Found Excel files:", xlsx_files)
    
    for f in xlsx_files:
        try:
            wb = openpyxl.load_workbook(f, read_only=True)
            print(f"\nStructure for {f}:")
            for name in wb.sheetnames:
                sheet = wb[name]
                print(f"  Sheet: {name} (Max row: {sheet.max_row}, Max col: {sheet.max_column})")
                # Print header row (up to first 10 columns)
                for r in sheet.iter_rows(max_row=1, max_col=10, values_only=True):
                    print("    Header:", r)
        except Exception as e:
            print(f"  Error reading {f}: {e}")

if __name__ == '__main__':
    inspect_trackers()
