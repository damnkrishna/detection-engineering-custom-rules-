import re
import yaml
import sys

def validate_yaml_blocks(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
    if not yaml_blocks:
        print("No YAML blocks found to validate!")
        return True
        
    all_ok = True
    for i, block in enumerate(yaml_blocks, 1):
        try:
            yaml.safe_load(block)
            print(f"YAML block {i} is valid.")
        except Exception as e:
            print(f"Error parsing YAML block {i}: {e}")
            print("Content of failing block:")
            print(block)
            all_ok = False
            
    return all_ok

if __name__ == '__main__':
    files = [
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0243-T1056.001-DET0089.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0282-T1056-DET0102.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0389-T1056.004-DET0139.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1321-T1056.003-DET0480.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1440-T1056.002-DET0521.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0823-T1557-DET0296.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1091-T1557.002-DET0387.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1274-T1557.001-DET0462.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1290-T1557.003-DET0468.md"
    ]
    all_success = True
    for f in files:
        print(f"\nValidating {f}...")
        success = validate_yaml_blocks(f)
        if not success:
            all_success = False
            
    if not all_success:
        sys.exit(1)
    else:
        print("\nAll YAML blocks across all files are syntactically valid!")
