import openpyxl

def read_sprint():
    path = "ocsf_mapped_new_sprint.xlsx"
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.active
        print(f"Active Sheet Name: {sheet.title}")
        rows = list(sheet.iter_rows(values_only=True))
        print("Headers (all columns):")
        print(rows[0])
        print("\nFirst 15 Data Rows:")
        for idx, row in enumerate(rows[1:16], 1):
            print(f"{idx}: {row[:12]}")
    except Exception as e:
        print("Error reading excel:", e)

if __name__ == '__main__':
    read_sprint()
