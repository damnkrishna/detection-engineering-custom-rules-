import openpyxl

def check_entire_sheet():
    path = "ocsf_mapped_new_sprint.xlsx"
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.active
        print(f"Sheet name: {sheet.title}")
        rows = list(sheet.iter_rows(values_only=True))
        
        # Look at headers to know column index
        headers = rows[0]
        print("Header length:", len(headers))
        for i, h in enumerate(headers):
            print(f"Col {i}: {h}")
            
        # Count statuses
        statuses = {}
        target_ans = {
            "AN2064", "AN2065", "AN2066", "AN2067", "AN2068", 
            "AN2069", "AN2070", "AN2071", "AN2072", "AN2073", 
            "AN2074", "AN2075", "AN0108", "AN0216", "AN1137", 
            "AN1283", "AN1543"
        }
        found_targets = {}
        
        for idx, row in enumerate(rows[1:], 1):
            # Check length of row
            status_val = row[11] if len(row) > 11 else None # Column index 11 is status
            statuses[status_val] = statuses.get(status_val, 0) + 1
            
            an_val = row[0]
            if an_val in target_ans:
                found_targets[an_val] = {
                    'status': status_val,
                    'tactic': row[3],
                    'technique': row[4],
                    'row_num': idx + 1
                }
                
        print("\nStatus Distribution:")
        for s, count in statuses.items():
            print(f"  {s}: {count}")
            
        print("\nTarget Reconnaissance / Exfiltration Analytics Found:")
        for k, v in found_targets.items():
            print(f"  {k}: {v}")
            
        # Also print any that are NOT marked as 'Done'
        not_done = []
        for idx, row in enumerate(rows[1:], 1):
            status_val = row[11] if len(row) > 11 else None
            if status_val != 'Done':
                not_done.append((idx + 1, row[0], row[3], row[4], status_val))
                
        print(f"\nTotal rows not marked 'Done': {len(not_done)}")
        if not_done:
            print("First 10 not marked 'Done':")
            for nd in not_done[:10]:
                print(f"  Row {nd[0]}: {nd[1]} | {nd[2]} | {nd[3]} | Status: {nd[4]}")
                
    except Exception as e:
        print("Error checking sheet:", e)

if __name__ == '__main__':
    check_entire_sheet()
