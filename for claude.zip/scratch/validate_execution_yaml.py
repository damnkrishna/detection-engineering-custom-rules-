import os
import re
import yaml

execution_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\execution"
files = [
    "AN0942-T1059.010-DET0332.md",
    "AN0962-T1204.004-DET0340.md",
    "AN1031-T1047-DET0364.md",
    "AN1185-T1569.002-DET0421.md",
    "AN1252-T1059.001-DET0455.md",
    "AN1314-T1204-DET0478.md",
    "AN1357-T1559-DET0493.md",
    "AN1393-T1559.002-DET0504.md",
    "AN1428-T1059-DET0516.md",
    "AN1465-T1106-DET0529.md"
]

all_valid = True

for fname in files:
    path = os.path.join(execution_dir, fname)
    print(f"Validating {fname}...")
    if not os.path.exists(path):
        print(f"Error: {fname} does not exist!")
        all_valid = False
        continue

    with open(path, 'r', encoding='utf-8') as fh:
        content = fh.read()

    yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
    if not yaml_blocks:
        print("Error: No YAML blocks found!")
        all_valid = False
        continue

    for idx, block in enumerate(yaml_blocks, 1):
        try:
            data = yaml.safe_load(block)
            if not isinstance(data, dict):
                print(f"Error in YAML block {idx}: parsed content is not a dictionary")
                all_valid = False
                continue
            # Check basic Sigma fields
            required = ['title', 'id', 'status', 'description', 'author', 'date', 'logsource', 'detection']
            missing = [f for f in required if f not in data]
            if missing:
                print(f"Error in YAML block {idx}: missing top-level fields {missing}")
                all_valid = False
            else:
                # Check nested condition
                detection = data.get('detection', {})
                if not isinstance(detection, dict) or 'condition' not in detection:
                    print(f"Error in YAML block {idx}: missing condition inside detection")
                    all_valid = False
                else:
                    print(f"YAML block {idx} is valid.")
        except Exception as e:
            print(f"Error in YAML block {idx} parsing: {e}")
            all_valid = False

if all_valid:
    print("All YAML blocks across all Execution files are syntactically valid!")
else:
    print("Some YAML blocks contain errors.")
