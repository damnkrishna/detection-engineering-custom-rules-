import openpyxl

def find_pending_details():
    sprint_path = "ocsf_mapped_new_sprint.xlsx"
    tech_path = "techniques_table.xlsx"
    
    # 1. Read pending rules from sprint Excel
    pending_rules = []
    try:
        wb = openpyxl.load_workbook(sprint_path, data_only=True)
        sheet = wb.active
        rows = list(sheet.iter_rows(values_only=True))
        # Headers: Col 0: Analytic, Col 1: Category, Col 2: Platform, Col 3: Tactic, Col 4: Technique, Col 5: Technique Name, Col 6: Detection Strategy, Col 11: Status
        for r in rows[1:]:
            if any(r):
                status = r[11]
                if status == 'Not-Yet Done':
                    pending_rules.append({
                        'analytic': r[0],
                        'category': r[1],
                        'tactic': r[3],
                        'technique': r[4],
                        'tech_name': r[5],
                        'strategy': r[6]
                    })
    except Exception as e:
        print("Error reading sprint Excel:", e)
        
    print(f"Total pending rules in ocsf_mapped_new_sprint.xlsx: {len(pending_rules)}")
    
    # Group by individual Tactic/Category
    by_tactic = {}
    for rule in pending_rules:
        tactics_str = rule['tactic']
        if tactics_str:
            t_list = [t.strip().lower() for t in tactics_str.split(',')]
            for t in t_list:
                if t not in by_tactic:
                    by_tactic[t] = []
                by_tactic[t].append(rule)
        
    print("\nPending rules count by individual tactic/category:")
    for t in sorted(by_tactic.keys()):
        print(f"- {t}: {len(by_tactic[t])} rules pending")
        
    # Let's list the details for the tactics with the fewest rules
    fewest_tactics = ['collection', 'privilege-escalation', 'execution']
    for t in fewest_tactics:
        if t in by_tactic:
            print(f"\n--- Pending Rules for Tactic: {t} ---")
            for idx, r in enumerate(by_tactic[t], 1):
                print(f"{idx}. {r['analytic']} - {r['technique']} ({r['tech_name']})")
                print(f"   Strategy: {r['strategy']}\n")

if __name__ == '__main__':
    find_pending_details()
