import openpyxl

def update_sprint_excel():
    sprint_path = "ocsf_mapped_new_sprint.xlsx"
    target_analytics = {
        "AN1008", "AN1012", "AN1097", "AN1140", "AN1165", 
        "AN1361", "AN1434", "AN1489", "AN1538", "AN1622"
    }
    
    wb = openpyxl.load_workbook(sprint_path)
    ws = wb.active
    
    updated_count = 0
    # Headers: Col 0: Analytic, Col 1: Category, Col 2: Platform, Col 3: Tactic, Col 4: Technique, Col 5: Technique Name, Col 6: Detection Strategy, Col 11: Status
    for row in range(2, ws.max_row + 1):
        analytic = ws.cell(row=row, column=1).value
        if analytic in target_analytics:
            old_status = ws.cell(row=row, column=12).value
            ws.cell(row=row, column=12).value = "Done"
            print(f"Row {row} ({analytic}): Status was '{old_status}' -> setting to 'Done'")
            updated_count += 1
            
    wb.save(sprint_path)
    print(f"Saved {sprint_path} successfully. Total rows updated: {updated_count}")

def update_techniques_excel():
    tech_path = "techniques_table.xlsx"
    
    # 1. Uncovered techniques to move: T1529, T1657, T1667
    techs_to_move = {
        "T1529": {
            "name": "System Shutdown/Reboot",
            "tactics": "Impact",
            "subs": "T1529",
            "count": 2,
            "sources": "AN1538-T1529-DET0559.md"
        },
        "T1657": {
            "name": "Financial Theft",
            "tactics": "Impact",
            "subs": "T1657",
            "count": 2,
            "sources": "AN1361-T1657-DET0495.md"
        },
        "T1667": {
            "name": "Email Bombing",
            "tactics": "Impact",
            "subs": "T1667",
            "count": 2,
            "sources": "AN1008-T1667-DET0355.md"
        }
    }
    
    # 2. Existing covered techniques to update (we added new rules):
    # - T1499: now has AN1012, AN1165 (Count +4, because each has 2 sub-rules!)
    # - T1498: now has AN1140, AN1434 (Count +4, because each has 2 sub-rules!)
    # - T1496: now has AN1489 (Count +2)
    # - T1565: now has AN1097 (Count +2)
    # - T1491: now has AN1622 (Count +2)
    
    wb = openpyxl.load_workbook(tech_path)
    covered_ws = wb['Covered Techniques']
    uncovered_ws = wb['Uncovered Techniques']
    
    # Update existing covered counts and sources
    for row in range(2, covered_ws.max_row + 1):
        parent_id = covered_ws.cell(row=row, column=1).value
        if parent_id == 'T1499':
            covered_ws.cell(row=row, column=5).value = (covered_ws.cell(row=row, column=5).value or 0) + 4
            covered_ws.cell(row=row, column=6).value = str(covered_ws.cell(row=row, column=6).value) + ", AN1012-T1499.001-DET0356.md, AN1165-T1499.003-DET0415.md"
            print("Updated T1499 count and sources")
        elif parent_id == 'T1498':
            covered_ws.cell(row=row, column=5).value = (covered_ws.cell(row=row, column=5).value or 0) + 4
            covered_ws.cell(row=row, column=6).value = str(covered_ws.cell(row=row, column=6).value) + ", AN1140-T1498.002-DET0408.md, AN1434-T1498-DET0518.md"
            print("Updated T1498 count and sources")
        elif parent_id == 'T1496':
            covered_ws.cell(row=row, column=5).value = (covered_ws.cell(row=row, column=5).value or 0) + 2
            covered_ws.cell(row=row, column=6).value = str(covered_ws.cell(row=row, column=6).value) + ", AN1489-T1496.001-DET0540.md"
            print("Updated T1496 count and sources")
        elif parent_id == 'T1565':
            covered_ws.cell(row=row, column=5).value = (covered_ws.cell(row=row, column=5).value or 0) + 2
            covered_ws.cell(row=row, column=6).value = str(covered_ws.cell(row=row, column=6).value) + ", AN1097-T1565.003-DET0391.md"
            print("Updated T1565 count and sources")
        elif parent_id == 'T1491':
            covered_ws.cell(row=row, column=5).value = (covered_ws.cell(row=row, column=5).value or 0) + 2
            covered_ws.cell(row=row, column=6).value = str(covered_ws.cell(row=row, column=6).value) + ", AN1622-T1491.002-DET0590.md"
            print("Updated T1491 count and sources")
            
    # Delete from Uncovered Techniques
    rows_to_delete = []
    for row in range(2, uncovered_ws.max_row + 1):
        parent_id = uncovered_ws.cell(row=row, column=1).value
        if parent_id in techs_to_move:
            rows_to_delete.append(row)
            
    print(f"Deleting rows from Uncovered Techniques: {rows_to_delete}")
    # Delete in reverse order to keep indices valid
    for r in sorted(rows_to_delete, reverse=True):
        uncovered_ws.delete_rows(r)
        
    # Append to Covered Techniques
    for tid, info in techs_to_move.items():
        new_row = [
            tid,
            info['name'],
            info['tactics'],
            info['subs'],
            info['count'],
            info['sources']
        ]
        covered_ws.append(new_row)
        print(f"Appended {tid} to Covered Techniques sheet")
        
    wb.save(tech_path)
    print(f"Saved {tech_path} successfully.")

if __name__ == '__main__':
    print("=== Updating ocsf_mapped_new_sprint.xlsx ===")
    update_sprint_excel()
    print("\n=== Updating techniques_table.xlsx ===")
    update_techniques_excel()
