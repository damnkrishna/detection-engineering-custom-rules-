import openpyxl

def update_trackers():
    sprint_path = "ocsf_mapped_new_sprint.xlsx"
    tech_path = "techniques_table.xlsx"
    
    # 1. Update ocsf_mapped_new_sprint.xlsx
    try:
        wb_sprint = openpyxl.load_workbook(sprint_path)
        sheet = wb_sprint.active
        # Rows to update (1-based index including headers in excel)
        # Note: row_num in script output was 1-based (216, 218, 219, 222, 224 were Done,
        # but rows 251, 252, 253, 254, 255, 256, 289 were Not-Yet Done)
        rows_to_update = [251, 252, 253, 254, 255, 256, 289]
        for r_idx in rows_to_update:
            # Col 11 is Status (column L, index 12 in 1-based excel column)
            cell = sheet.cell(row=r_idx, column=12)
            print(f"Row {r_idx} before: {cell.value}")
            cell.value = "Done"
            print(f"Row {r_idx} after: {cell.value}")
            
        wb_sprint.save(sprint_path)
        print("ocsf_mapped_new_sprint.xlsx updated successfully.")
    except Exception as e:
        print("Error updating sprint Excel:", e)
        
    # 2. Update techniques_table.xlsx
    try:
        wb_tech = openpyxl.load_workbook(tech_path)
        sheet_cov = wb_tech["Covered Techniques"]
        
        # We need to find the rows for T1556 and T1484
        for row in sheet_cov.iter_rows(min_row=2):
            parent_id = row[0].value
            if parent_id == "T1556":
                # Original Subtechniques Covered: 'T1556, T1556.002'
                # Original Rules Count: 4
                # Original Rule Sources: 'AN0287-T1556-DET0104.md, all_sigma_rules.txt, extracted_sigma_rules.txt, message.txt'
                row[3].value = "T1556, T1556.001, T1556.002, T1556.005, T1556.006, T1556.007, T1556.008"
                row[4].value = (row[4].value or 0) + 13 # we wrote 13 split rules in total
                new_sources = [
                    "AN0543-T1556.006-DET0190.md",
                    "AN0757-T1556.001-DET0271.md",
                    "AN0814-T1556.007-DET0293.md",
                    "AN1303-T1556.002-DET0472.md",
                    "AN1598-T1556.008-DET0580.md",
                    "AN1621-T1556.005-DET0589.md"
                ]
                row[5].value = str(row[5].value) + ", " + ", ".join(new_sources)
                print("Updated T1556 entry.")
                
            elif parent_id == "T1484":
                # Original Subtechniques Covered: 'T1484, T1484.001'
                # Original Rules Count: 5
                # Original Rule Sources: 'AN0755-T1484-DET0270.md, AN0854-T1484.001-DET0305.md, all_sigma_rules.txt, extracted_sigma_rules.txt, message.txt'
                row[3].value = "T1484, T1484.001, T1484.002"
                row[4].value = (row[4].value or 0) + 2 # we wrote 2 split rules in total
                row[5].value = str(row[5].value) + ", AN1259-T1484.002-DET0458.md"
                print("Updated T1484 entry.")
                
        wb_tech.save(tech_path)
        print("techniques_table.xlsx updated successfully.")
    except Exception as e:
        print("Error updating techniques table:", e)

if __name__ == '__main__':
    update_trackers()
