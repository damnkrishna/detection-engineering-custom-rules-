import pandas as pd
import json

df = pd.read_csv('important_files/detection_coverage_matrix_final.csv')
res = []

allowed_tools = ['edr', 'firewall', 'iam', 'ad', 'itsm', 'entra', 'okta', 'identity']

for i, r in df.iterrows():
    details = str(r.get('Coverage Details', '')).lower()
    tool = str(r.get('Extra Tooling / Log Source Needed', '')).lower()
    name = str(r.get('Name / Category', ''))
    
    if 'soar' in details or 'soar' in tool:
        # User wants "every row where 'Extra Tooling' or 'Coverage Details' references a SOAR integration with anything other than EDR, firewall, IAM/AD, or ITSM"
        
        # We look for non-standard tools.
        non_standard = []
        if 'tip ' in details or 'tip api' in tool or ' tip' in tool:
            non_standard.append('TIP')
        if 'dns ' in details or 'dns api' in tool or 'secure dns' in tool:
            non_standard.append('Secure DNS')
        if 'email gateway' in details or 'email gateway' in tool or 'seg' in tool:
            non_standard.append('Email Gateway')
        if 'swg' in details or 'swg' in tool or 'secure web gateway' in details:
            non_standard.append('SWG')
        if 'ztna' in details or 'ztna' in tool:
            non_standard.append('ZTNA Platform')
        if 'endpoint dlp' in details or 'endpoint dlp' in tool or 'device control' in tool:
            non_standard.append('Endpoint DLP')
        if 'ngfw' in tool or 'ngfw' in details:
            non_standard.append('NGFW')
            
        if non_standard:
            res.append({'name': name, 'integrations': ', '.join(non_standard)})

print(json.dumps(res, indent=2))
