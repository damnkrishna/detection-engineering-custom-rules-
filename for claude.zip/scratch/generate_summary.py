import pandas as pd

df = pd.read_csv('important_files/detection_coverage_matrix_final.csv')

upgraded = []
hybrid = []
untouched = []

for i, r in df.iterrows():
    name = str(r.get('Name / Category', '')).strip()
    status = str(r.get('Coverage Status', '')).strip()
    details = str(r.get('Coverage Details', '')).strip()
    gap = str(r.get('Gap Type', '')).strip()
    tool = str(r.get('Extra Tooling / Log Source Needed', '')).strip()
    
    if status == 'Covered – SOAR-dependent':
        upgraded.append(f"| **{name}** | {tool} |")
    elif 'once integrated' in details or 'SOAR playbook' in details:
        if status != 'Covered – SOAR-dependent':
            # It's a hybrid gap. Find the limiter.
            limiter = f"Missing log/rule ({tool})"
            if gap == 'Missing Logs': limiter = f"Missing log ({tool})"
            if gap == 'Missing Rule': limiter = f"Missing rule ({tool})"
            hybrid.append(f"| **{name}** | {limiter} |")
    else:
        untouched.append(f"| **{name}** | {gap} |")

md_content = f"""# SOAR Coverage Matrix Update Summary

This document serves as a verification record of the SOAR planning assumption updates applied to `detection_coverage_matrix_final.xlsx`.

**Planning Assumption Applied:**
> "This matrix assumes a SOAR platform is deployed and able to execute response actions across our EDR, firewall, IAM/AD, and ITSM tooling. Rows marked 'Covered – SOAR-dependent' reflect this planning assumption, not a verified current-state integration. Rows with both a detection gap and a response gap remain classified as detection gaps, since SOAR cannot act on an alert that never fires."

---

## 1. Fully Upgraded to "Covered – SOAR-dependent"
*These {len(upgraded)} capabilities possessed a pure response/action gap with no underlying detection/telemetry limitations.*

| Capability Name | Required SOAR Action |
| :--- | :--- |
"""
md_content += "\n".join(upgraded)

md_content += f"""

---

## 2. Kept as Detection Gaps with SOAR Side-note (Hybrid)
*These {len(hybrid)} capabilities have a response gap, but also suffer from a missing log or missing rule. They were kept as detection gaps because SOAR cannot orchestrate a response for an alert that never fires.*

| Capability Name | Underlying Detection Limiter |
| :--- | :--- |
"""
md_content += "\n".join(hybrid)

md_content += f"""

---

## 3. Left Completely Untouched
*These {len(untouched)} capabilities were skipped because they either have no response limitation at all, or they represent an architectural gap where no sensor/agent exists for SOAR to trigger through.*

| Capability Name | Reason for Skipping / Gap Type |
| :--- | :--- |
"""
md_content += "\n".join(untouched)

with open('important_files/soar_changes_summary.md', 'w') as f:
    f.write(md_content)

print("soar_changes_summary.md has been perfectly synced with the CSV.")
