import re
import yaml
import sys
import os

def validate_yaml_blocks(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
    if not yaml_blocks:
        print("No YAML blocks found to validate!")
        return True
        
    all_ok = True
    for i, block in enumerate(yaml_blocks, 1):
        try:
            yaml.safe_load(block)
            print(f"YAML block {i} is valid.")
        except Exception as e:
            print(f"Error parsing YAML block {i}: {e}")
            print("Content of failing block:")
            print(block)
            all_ok = False
            
    return all_ok

if __name__ == '__main__':
    impact_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\impact"
    files = [
        "AN1008-T1667-DET0355.md",
        "AN1012-T1499.001-DET0356.md",
        "AN1097-T1565.003-DET0391.md",
        "AN1140-T1498.002-DET0408.md",
        "AN1165-T1499.003-DET0415.md",
        "AN1361-T1657-DET0495.md",
        "AN1434-T1498-DET0518.md",
        "AN1489-T1496.001-DET0540.md",
        "AN1538-T1529-DET0559.md",
        "AN1622-T1491.002-DET0590.md"
    ]
    all_success = True
    for fname in files:
        f = os.path.join(impact_dir, fname)
        print(f"\nValidating {fname}...")
        success = validate_yaml_blocks(f)
        if not success:
            all_success = False
            
    if not all_success:
        print("\nSome YAML blocks failed validation.")
        sys.exit(1)
    else:
        print("\nAll YAML blocks across all Batch 2 files are syntactically valid!")
