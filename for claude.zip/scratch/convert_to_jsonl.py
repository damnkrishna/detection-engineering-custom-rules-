import json
import re

# 1. Update the Rule Document
file_path = r'C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\credential-access\AN0105-T1555.003-DET0037.md'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

json_match = re.search(r'```json\n(.*?)\n```', content, re.DOTALL)
if json_match:
    json_str = json_match.group(1)
    events = json.loads(json_str)
    
    # Generate JSONL
    jsonl_lines = [json.dumps(ev) for ev in events]
    new_jsonl_block = "\n".join(jsonl_lines)
    
    # Replace the old json block with jsonl
    content = content[:json_match.start()] + "```jsonl\n" + new_jsonl_block + "\n```" + content[json_match.end():]
    
    # Update intro text to say JSONL instead of JSON array
    content = content.replace("JSON array", "JSONL (JSON Lines) payload")
    content = content.replace("array", "dataset")
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("Successfully converted rule dataset to JSONL")
else:
    print("Could not find JSON block in rule doc")

# 2. Update the Methodology Document
methodology_path = r'C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\important_files\rule_improvement_methodology.md'
with open(methodology_path, 'r', encoding='utf-8') as f:
    meth_content = f.read()

meth_content = meth_content.replace("JSON array", "JSONL (JSON Lines) format")
meth_content = meth_content.replace("array", "dataset")

with open(methodology_path, 'w', encoding='utf-8') as f:
    f.write(meth_content)
    print("Successfully updated methodology doc to mention JSONL")
