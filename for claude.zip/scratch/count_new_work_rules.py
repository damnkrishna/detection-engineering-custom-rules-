import os
import re
import yaml

def get_shared_uuids():
    shared_rules = {} # id -> title
    
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
    for file in txt_files:
        filepath = file
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        documents = content.split('---')
        for doc in documents:
            doc = doc.strip()
            if not doc:
                continue
            if 'id:' in doc and 'title:' in doc:
                try:
                    parsed = yaml.safe_load(doc)
                    if isinstance(parsed, dict) and 'id' in parsed:
                        rule_id = str(parsed.get('id')).strip().lower()
                        shared_rules[rule_id] = parsed.get('title', 'Unknown')
                except Exception:
                    id_match = re.search(r'id:\s*([a-fA-F0-9\-]+)', doc)
                    if id_match:
                        rule_id = id_match.group(1).strip().lower()
                        shared_rules[rule_id] = 'Unknown'
    return shared_rules

def find_new_work_rules(shared_uuids):
    new_work_rules = []
    
    for root, dirs, files in os.walk('./new work'):
        for file in files:
            if file.endswith('.md'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Find all json blocks in markdown
                json_blocks = re.findall(r'```json\s*\n(.*?)\n```', content, re.DOTALL)
                for i, block in enumerate(json_blocks, 1):
                    try:
                        # Clean JSON comments if any, or just load
                        parsed = yaml.safe_load(block) # yaml parses json too
                        if isinstance(parsed, dict):
                            rule_id = str(parsed.get('ruleId', parsed.get('id', ''))).strip().lower()
                            title = parsed.get('ruleName', parsed.get('title', 'Unknown'))
                            new_work_rules.append({
                                'id': rule_id,
                                'title': title,
                                'file': filepath,
                                'block_index': i
                            })
                    except Exception:
                        id_match = re.search(r'"ruleId":\s*"([^"]+)"', block)
                        title_match = re.search(r'"ruleName":\s*"([^"]+)"', block)
                        if id_match:
                            rule_id = id_match.group(1).strip().lower()
                            title = title_match.group(1).strip() if title_match else 'Unknown'
                            new_work_rules.append({
                                'id': rule_id,
                                'title': title,
                                'file': filepath,
                                'block_index': i
                            })
                                
    # Compare rules against shared_uuids and also look at text files contents
    unshared = []
    
    # Read text files to check for raw occurrence of ruleId
    txt_contents = ""
    txt_files = [tf for tf in os.listdir('.') if tf.endswith('.txt')]
    for tf in txt_files:
        with open(tf, 'r', encoding='utf-8', errors='ignore') as f:
            txt_contents += f.read().lower() + "\n"
            
    for mr in new_work_rules:
        # Check if the ruleId is in shared UUIDs or anywhere in text files
        if mr['id'] and mr['id'] not in shared_uuids and mr['id'] not in txt_contents:
            unshared.append(mr)
        elif not mr['id']:
            unshared.append(mr)
            
    print(f"Total JSON rules found in 'new work' folder: {len(new_work_rules)}")
    print(f"Total unshared rules in 'new work' folder: {len(unshared)}")
    
    # Write to a file
    output_path = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\unshared_new_work_rules.txt"
    with open(output_path, 'w', encoding='utf-8') as out:
        out.write("Unshared Rules in 'new work' folder\n")
        out.write("===================================\n\n")
        for idx, rule in enumerate(unshared, 1):
            out.write(f"{idx}. Title: {rule['title']}\n")
            out.write(f"   ID: {rule['id']}\n")
            out.write(f"   File: {rule['file']} (Block #{rule['block_index']})\n\n")
            
    print(f"Unshared new work rules list written to {output_path}")

if __name__ == '__main__':
    shared = get_shared_uuids()
    find_new_work_rules(shared)
