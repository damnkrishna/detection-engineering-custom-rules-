import os
import re
import yaml

def get_shared_uuids():
    shared_rules = {}
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
    for file in txt_files:
        with open(file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        documents = content.split('---')
        for doc in documents:
            doc = doc.strip()
            if not doc:
                continue
            if 'id:' in doc:
                try:
                    parsed = yaml.safe_load(doc)
                    if isinstance(parsed, dict) and 'id' in parsed:
                        shared_rules[str(parsed.get('id')).strip().lower()] = parsed.get('title', 'Unknown')
                except:
                    id_match = re.search(r'id:\s*([a-fA-F0-9\-]+)', doc)
                    if id_match:
                        shared_rules[id_match.group(1).strip().lower()] = 'Unknown'
    return shared_rules

def generate_record():
    shared = get_shared_uuids()
    
    # Lists of rules found
    md_rules = []
    new_work_rules = []
    
    # 1. Scan all md rules in tactic folders
    for root, dirs, files in os.walk('.'):
        if '.git' in root or '.gemini' in root or 'scratch' in root or 'new work' in root:
            continue
        for file in files:
            if file.endswith('.md') and not file.startswith('README') and not file.startswith('unshared'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Find YAML blocks
                yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
                for i, block in enumerate(yaml_blocks, 1):
                    if 'id:' in block or 'title:' in block:
                        try:
                            parsed = yaml.safe_load(block)
                            if isinstance(parsed, dict):
                                rule_id = str(parsed.get('id', '')).strip().lower()
                                title = parsed.get('title', 'Unknown')
                                md_rules.append({'id': rule_id, 'title': title, 'file': filepath, 'type': 'Sigma'})
                        except:
                            id_match = re.search(r'id:\s*([a-fA-F0-9\-]+)', block)
                            title_match = re.search(r'title:\s*(.+)', block)
                            if id_match:
                                rule_id = id_match.group(1).strip().lower()
                                title = title_match.group(1).strip() if title_match else 'Unknown'
                                md_rules.append({'id': rule_id, 'title': title, 'file': filepath, 'type': 'Sigma'})

    # 2. Scan new work folder
    for root, dirs, files in os.walk('./new work'):
        for file in files:
            if file.endswith('.md'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Find JSON blocks
                json_blocks = re.findall(r'```json\s*\n(.*?)\n```', content, re.DOTALL)
                for i, block in enumerate(json_blocks, 1):
                    try:
                        parsed = yaml.safe_load(block)
                        if isinstance(parsed, dict):
                            rule_id = str(parsed.get('ruleId', parsed.get('id', ''))).strip().lower()
                            title = parsed.get('ruleName', parsed.get('title', 'Unknown'))
                            new_work_rules.append({'id': rule_id, 'title': title, 'file': filepath, 'type': 'JSON Correlation'})
                    except:
                        id_match = re.search(r'"ruleId":\s*"([^"]+)"', block)
                        title_match = re.search(r'"ruleName":\s*"([^"]+)"', block)
                        if id_match:
                            rule_id = id_match.group(1).strip().lower()
                            title = title_match.group(1).strip() if title_match else 'Unknown'
                            new_work_rules.append({'id': rule_id, 'title': title, 'file': filepath, 'type': 'JSON Correlation'})

    # Filter unshared
    unshared_md = [r for r in md_rules if r['id'] not in shared]
    unshared_nw = [r for r in new_work_rules if r['id'] not in shared]
    
    total_unshared = len(unshared_md) + len(unshared_nw)
    print(f"Total unshared: {total_unshared} (MD: {len(unshared_md)}, NW: {len(unshared_nw)})")
    
    # Generate markdown content
    md_content = f"# Consolidated Record of Unshared Rules\n\n"
    md_content += f"This document tracks all {total_unshared} rules currently present in this repository (in `.md` or `.json` block format) that have **not** been shared yet.\n\n"
    md_content += "---\n\n"
    
    md_content += f"## 1. Unshared Tactic-Folder Rules ({len(unshared_md)} Rules)\n"
    # Group by folder
    grouped_md = {}
    for r in unshared_md:
        folder = os.path.dirname(r['file']).replace('.\\', '').replace('./', '')
        if folder not in grouped_md:
            grouped_md[folder] = []
        grouped_md[folder].append(r)
        
    for folder in sorted(grouped_md.keys()):
        md_content += f"\n### {folder.replace('-', ' ').title()}\n"
        for idx, r in enumerate(grouped_md[folder], 1):
            md_content += f"{idx}. **{r['title']}**\n"
            md_content += f"   - ID: `{r['id']}`\n"
            md_content += f"   - File: [{os.path.basename(r['file'])}](file:///{os.path.abspath(r['file']).replace(os.sep, '/')})\n"
            
    md_content += "\n---\n\n"
    md_content += f"## 2. Unshared Correlation Rules (`new work\\` Folder) ({len(unshared_nw)} Rules)\n"
    # Group new work by subfolder
    grouped_nw = {}
    for r in unshared_nw:
        folder = os.path.dirname(r['file']).replace('.\\', '').replace('./', '')
        if folder not in grouped_nw:
            grouped_nw[folder] = []
        grouped_nw[folder].append(r)
        
    for folder in sorted(grouped_nw.keys()):
        md_content += f"\n### {folder.replace('-', ' ').title()}\n"
        for idx, r in enumerate(grouped_nw[folder], 1):
            md_content += f"{idx}. **{r['title']}**\n"
            md_content += f"   - ID: `{r['id']}`\n"
            md_content += f"   - File: [{os.path.basename(r['file'])}](file:///{os.path.abspath(r['file']).replace(os.sep, '/')})\n"

    # Write outputs
    workspace_out = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\unshared_rules_record.md"
    brain_out = r"C:\Users\Sunil\.gemini\antigravity-ide\brain\deb73e25-fba5-46fb-90a3-b8793435d696\unshared_rules_record.md"
    
    with open(workspace_out, 'w', encoding='utf-8') as f:
        f.write(md_content)
    print(f"Written record to {workspace_out}")
    
    try:
        with open(brain_out, 'w', encoding='utf-8') as f:
            f.write(md_content)
        print(f"Written record to {brain_out}")
    except Exception as e:
        print("Error writing to brain:", e)

if __name__ == '__main__':
    generate_record()
