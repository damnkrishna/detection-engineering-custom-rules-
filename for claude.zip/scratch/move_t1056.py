import openpyxl

def move_to_covered():
    tech_path = "techniques_table.xlsx"
    wb = openpyxl.load_workbook(tech_path)
    
    sheet_unc = wb["Uncovered Techniques"]
    sheet_cov = wb["Covered Techniques"]
    
    # 1. Print headers to verify columns
    cov_headers = [cell.value for cell in sheet_cov[1]]
    unc_headers = [cell.value for cell in sheet_unc[1]]
    print("Covered Headers:", cov_headers)
    print("Uncovered Headers:", unc_headers)
    
    # 2. Find and copy the T1056 row data, then delete it from Uncovered
    row_to_delete = None
    t1056_data = None
    for idx in range(2, sheet_unc.max_row + 1):
        p_id = sheet_unc.cell(row=idx, column=1).value
        if p_id == "T1056":
            t1056_data = [sheet_unc.cell(row=idx, column=col).value for col in range(1, 5)]
            row_to_delete = idx
            break
            
    if row_to_delete:
        sheet_unc.delete_rows(row_to_delete)
        print(f"Deleted T1056 from Uncovered Techniques at row {row_to_delete}")
    else:
        print("T1056 not found in Uncovered Techniques.")
        
    # 3. Create the new row for Covered Techniques
    # Column mappings for Covered:
    # 0: Parent ID ('T1056')
    # 1: Technique Name ('Input Capture')
    # 2: Tactics ('Collection, Credential Access')
    # 3: Subtechniques Covered
    # 4: Rules Count
    # 5: Rule Sources
    subtechs = "T1056, T1056.001, T1056.002, T1056.003, T1056.004"
    rules_count = 9
    rule_sources = "AN0243-T1056.001-DET0089.md, AN0282-T1056-DET0102.md, AN0389-T1056.004-DET0139.md, AN1321-T1056.003-DET0480.md, AN1440-T1056.002-DET0521.md"
    
    new_row = [
        "T1056",
        "Input Capture",
        "Collection, Credential Access",
        subtechs,
        rules_count,
        rule_sources
    ]
    
    sheet_cov.append(new_row)
    print("Appended T1056 to Covered Techniques sheet.")
    
    wb.save(tech_path)
    print("Saved techniques_table.xlsx changes.")

if __name__ == '__main__':
    move_to_covered()
