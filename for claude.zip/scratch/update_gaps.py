import pandas as pd
import openpyxl

file_path = 'important_files/detection_coverage_matrix_final.xlsx'
wb = openpyxl.load_workbook(file_path)
ws = wb.active

# headers are on row 2
headers = {cell.value: idx for idx, cell in enumerate(ws[2])}
name_col = headers.get('Name / Category')
gap_type_col = headers.get('Gap Type')

for row in ws.iter_rows(min_row=3):
    if row[name_col].value is None:
        continue
    
    name = str(row[name_col].value)
    
    if name == 'Deep telemetry (process, file, network, registry)':
        row[gap_type_col].value = 'Covered'
        
    if name == 'DMARC / DKIM / SPF enforcement':
        row[gap_type_col].value = 'Missing Logs'

wb.save(file_path)

# Update CSV too
df = pd.read_excel(file_path, skiprows=1)
df.to_csv('important_files/detection_coverage_matrix_final.csv', index=False)
