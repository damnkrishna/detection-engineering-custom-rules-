import json
import re

file_path = r'C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\credential-access\AN0105-T1555.003-DET0037.md'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# UIDs mapping based on rule headers
rule1_uid = "7c8e9d1a-4f5b-6a2c-3d8e-1f2a3b4c5d6e"
rule2_uid = "0c75612e-c43b-4be8-89e6-d3b44e7a63a4"

# Extract JSONL block
jsonl_match = re.search(r'```jsonl\n(.*?)\n```', content, re.DOTALL)
if jsonl_match:
    jsonl_str = jsonl_match.group(1)
    lines = jsonl_str.strip().split('\n')
    
    benign_events = []
    tp_events = []
    
    for line in lines:
        if not line.strip(): continue
        # Handle trailing commas which are invalid in JSON but might have been added
        line = line.replace('true,}', 'true}')
        
        ev = json.loads(line)
        desc = ev['metadata']['description']
        
        # Determine UID
        uid = rule1_uid
        if '(Rule 2' in desc:
            uid = rule2_uid
            
        # Reconstruct metadata to guarantee order
        new_meta = {
            "test_case": ev['metadata']['test_case'],
            "description": ev['metadata']['description'],
            "expected_alert": ev['metadata']['expected_alert'],
            "rule_uid": uid
        }
        
        # Replace metadata in event
        # To strictly maintain order in the final JSON string, we create a new dict
        new_ev = {"metadata": new_meta}
        for k, v in ev.items():
            if k != "metadata":
                new_ev[k] = v
                
        # Route to correct bucket
        if ev['metadata']['expected_alert'] == False:
            benign_events.append(new_ev)
        else:
            tp_events.append(new_ev)
            
    # Generate new blocks
    benign_jsonl = "\n".join([json.dumps(e) for e in benign_events])
    tp_jsonl = "\n".join([json.dumps(e) for e in tp_events])
    
    new_blocks = "#### Benign Telemetry\n```jsonl\n" + benign_jsonl + "\n```\n\n#### True Positive Telemetry\n```jsonl\n" + tp_jsonl + "\n```"
    
    # Replace in content
    content = content[:jsonl_match.start()] + new_blocks + content[jsonl_match.end():]
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
        
    print("Successfully updated telemetry blocks and added rule_uid")
else:
    print("Could not find jsonl block")

# 2. Update Methodology
methodology_path = r'C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\important_files\rule_improvement_methodology.md'
with open(methodology_path, 'r', encoding='utf-8') as f:
    meth_content = f.read()

# Replace Step 2 text to include new requirements
old_step_2_start = "### Step 2: Generate Raw Telemetry (JSON)"
new_step_2_full = """### Step 2: Generate Raw Telemetry (JSONL)
The human-readable test cases are for analysts; the raw telemetry is for the Platform Engineering team.
* At the bottom of the `.md` file, provide the raw, OCSF-normalized events formatted as **JSONL (JSON Lines)**.
* **MANDATORY - Rule UID Mapping:** Inside the `metadata` object of every event, right after `expected_alert`, you MUST include `rule_uid`. This maps the event to the exact unique ID of the detection rule it is testing so the engine can correlate hits during replay.
* **MANDATORY - Separate Blocks:** Do not combine all events into one block. You must create two completely separate JSONL blocks:
  1. `#### Benign Telemetry` (Containing only True Negatives / expected_alert: false)
  2. `#### True Positive Telemetry` (Containing only True Positives / expected_alert: true)
* **Why:** Splitting them allows engineers to quickly pipe the benign dataset first to ensure zero false fires, and then pipe the malicious dataset to verify detection efficacy. The `rule_uid` is critical for automated validation scripts to query the SIEM/backend and prove the correct rule fired."""

# We will use regex to replace the entire Step 2 block
meth_content = re.sub(r'### Step 2: Generate Raw Telemetry \(JSONL?\).*?(?=### Step 3:)', new_step_2_full + '\n\n', meth_content, flags=re.DOTALL)

with open(methodology_path, 'w', encoding='utf-8') as f:
    f.write(meth_content)
    
print("Successfully updated methodology doc")
