import re
import os

def combine_rules(files, out_path):
    combined_content = ""
    rule_count = 0
    for filepath in files:
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            continue
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
        filename = os.path.basename(filepath)
        combined_content += f"# ==========================================================================\n"
        combined_content += f"# SOURCE FILE: {filename}\n"
        combined_content += f"# ==========================================================================\n\n"
        for i, block in enumerate(yaml_blocks, 1):
            rule_count += 1
            combined_content += f"---\n"
            combined_content += f"# Rule {i} from {filename}\n"
            combined_content += block.strip() + "\n\n"
    with open(out_path, 'w', encoding='utf-8') as out:
        out.write(combined_content)
    print(f"Combined {rule_count} rules into {out_path}")

if __name__ == '__main__':
    batch1 = [
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0243-T1056.001-DET0089.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0282-T1056-DET0102.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0389-T1056.004-DET0139.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1321-T1056.003-DET0480.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1440-T1056.002-DET0521.md",
    ]
    batch2 = [
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0823-T1557-DET0296.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1091-T1557.002-DET0387.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1274-T1557.001-DET0462.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1290-T1557.003-DET0468.md",
    ]
    combine_rules(batch1, r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\sprint_collection_batch1_combined.txt")
    combine_rules(batch2, r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\sprint_collection_batch2_combined.txt")
