import openpyxl

def update_collection_batch1():
    sprint_path = "ocsf_mapped_new_sprint.xlsx"
    tech_path = "techniques_table.xlsx"
    
    target_ids = {"AN0243", "AN0282", "AN0389", "AN1321", "AN1440"}
    
    wb_sprint = openpyxl.load_workbook(sprint_path)
    sheet = wb_sprint.active
    
    # 1. Update ocsf_mapped_new_sprint.xlsx
    updated_rows = []
    for r_idx in range(2, sheet.max_row + 1):
        analytic_id = str(sheet.cell(row=r_idx, column=1).value).strip()
        if analytic_id in target_ids:
            cell_status = sheet.cell(row=r_idx, column=12) # Column L
            print(f"Row {r_idx} ({analytic_id}) status: {cell_status.value} -> Done")
            cell_status.value = "Done"
            updated_rows.append(r_idx)
            
    wb_sprint.save(sprint_path)
    print(f"Updated {len(updated_rows)} rows in sprint sheet: {updated_rows}")
    
    # 2. Update techniques_table.xlsx
    # Techniques covered:
    # T1056: Input Capture (includes T1056.001, T1056.002, T1056.003, T1056.004)
    # Let's update techniques_table.xlsx 'Covered Techniques' sheet
    wb_tech = openpyxl.load_workbook(tech_path)
    sheet_cov = wb_tech["Covered Techniques"]
    
    found = False
    for row in sheet_cov.iter_rows(min_row=2):
        parent_id = row[0].value
        if parent_id == "T1056":
            found = True
            # Original Subtechniques Covered: 'T1056, T1056.002'? Let's check what it has:
            # Let's set it to contain: T1056, T1056.001, T1056.002, T1056.003, T1056.004
            row[3].value = "T1056, T1056.001, T1056.002, T1056.003, T1056.004"
            # We wrote 5 new files with: AN0243 (2 rules), AN0282 (2 rules), AN0389 (2 rules), AN1321 (1 rule), AN1440 (2 rules).
            # Total 9 split rules. Let's add 9 to the rules count.
            row[4].value = (row[4].value or 0) + 9
            new_sources = [
                "AN0243-T1056.001-DET0089.md",
                "AN0282-T1056-DET0102.md",
                "AN0389-T1056.004-DET0139.md",
                "AN1321-T1056.003-DET0480.md",
                "AN1440-T1056.002-DET0521.md"
            ]
            current_sources = str(row[5].value)
            row[5].value = current_sources + ", " + ", ".join(new_sources)
            print("Updated techniques_table.xlsx entry for T1056.")
            break
            
    wb_tech.save(tech_path)
    print("Workbook techniques_table.xlsx saved.")

if __name__ == '__main__':
    update_collection_batch1()
