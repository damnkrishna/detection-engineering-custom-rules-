import openpyxl

def update_collection_batch2():
    sprint_path = "ocsf_mapped_new_sprint.xlsx"
    tech_path = "techniques_table.xlsx"
    
    target_ids = {"AN0823", "AN1091", "AN1274", "AN1290"}
    
    # 1. Update ocsf_mapped_new_sprint.xlsx
    wb_sprint = openpyxl.load_workbook(sprint_path)
    sheet = wb_sprint.active
    
    updated_rows = []
    for r_idx in range(2, sheet.max_row + 1):
        analytic_id = str(sheet.cell(row=r_idx, column=1).value).strip()
        if analytic_id in target_ids:
            cell_status = sheet.cell(row=r_idx, column=12) # Column L
            print(f"Row {r_idx} ({analytic_id}) status: {cell_status.value} -> Done")
            cell_status.value = "Done"
            updated_rows.append(r_idx)
            
    wb_sprint.save(sprint_path)
    print(f"Updated {len(updated_rows)} rows in sprint sheet: {updated_rows}")
    
    # 2. Update techniques_table.xlsx
    # Techniques covered:
    # T1557: Adversary-in-the-Middle (includes T1557, T1557.001, T1557.002, T1557.003)
    wb_tech = openpyxl.load_workbook(tech_path)
    sheet_unc = wb_tech["Uncovered Techniques"]
    sheet_cov = wb_tech["Covered Techniques"]
    
    # Search for T1557 in Uncovered
    row_to_delete = None
    t1557_data = None
    for idx in range(2, sheet_unc.max_row + 1):
        p_id = sheet_unc.cell(row=idx, column=1).value
        if p_id == "T1557":
            t1557_data = [sheet_unc.cell(row=idx, column=col).value for col in range(1, 5)]
            row_to_delete = idx
            break
            
    if row_to_delete:
        sheet_unc.delete_rows(row_to_delete)
        print(f"Deleted T1557 from Uncovered Techniques at row {row_to_delete}")
        
        # Append to Covered
        # Rule count: AN0823 = 2, AN1091 = 2, AN1274 = 2, AN1290 = 2. Total = 8 split rules.
        subtechs = "T1557, T1557.001, T1557.002, T1557.003"
        rules_count = 8
        rule_sources = "AN0823-T1557-DET0296.md, AN1091-T1557.002-DET0387.md, AN1274-T1557.001-DET0462.md, AN1290-T1557.003-DET0468.md"
        
        new_row = [
            "T1557",
            "Adversary-in-the-Middle",
            "Collection, Credential Access",
            subtechs,
            rules_count,
            rule_sources
        ]
        sheet_cov.append(new_row)
        print("Appended T1557 to Covered Techniques sheet.")
    else:
        # Check if already in Covered
        for row in sheet_cov.iter_rows(min_row=2):
            parent_id = row[0].value
            if parent_id == "T1557":
                row[3].value = "T1557, T1557.001, T1557.002, T1557.003"
                row[4].value = (row[4].value or 0) + 8
                new_sources = [
                    "AN0823-T1557-DET0296.md",
                    "AN1091-T1557.002-DET0387.md",
                    "AN1274-T1557.001-DET0462.md",
                    "AN1290-T1557.003-DET0468.md"
                ]
                row[5].value = str(row[5].value) + ", " + ", ".join(new_sources)
                print("Updated existing T1557 in Covered Techniques.")
                break
                
    wb_tech.save(tech_path)
    print("Workbook techniques_table.xlsx saved.")

if __name__ == '__main__':
    update_collection_batch2()
