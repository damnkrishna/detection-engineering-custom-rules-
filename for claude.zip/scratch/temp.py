import pandas as pd
df = pd.read_csv('important_files/detection_coverage_matrix_final.csv')
for i, r in df.iterrows():
    if r.get('Gap Type') == 'Settings / Config Gap':
        print(f"{r.get('Name / Category')} - {r.get('Coverage Status')}")
