import openpyxl

wb = openpyxl.load_workbook(r'c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\ocsf_mapped_new_sprint.xlsx')
ws = wb.active

execution_rules = []
for r in range(2, ws.max_row + 1):
    status = ws.cell(row=r, column=12).value
    tactic = ws.cell(row=r, column=4).value
    if status and str(status).strip().lower() != 'done':
        if tactic and 'execution' in str(tactic).strip().lower():
            row_vals = {
                'row': r,
                'analytic': ws.cell(row=r, column=1).value,
                'tactic': str(tactic).strip(),
                'technique': ws.cell(row=r, column=5).value,
                'name': ws.cell(row=r, column=6).value,
                'strategy': ws.cell(row=r, column=7).value,
                'desc': ws.cell(row=r, column=11).value
            }
            execution_rules.append(row_vals)

print('Total pending execution rules:', len(execution_rules))
for rule in execution_rules:
    print(f"Row {rule['row']}: {rule['analytic']} - {rule['technique']} ({rule['name']})")
