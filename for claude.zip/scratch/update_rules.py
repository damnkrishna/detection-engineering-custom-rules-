import os
import re
import json

notes_path = r'c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\Rule_Verification_Notes (2).txt'
rules_dir = r'c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\json_correlation_rules'

def apply_modifications(rule_id, json_str, notes_block):
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError:
        return json_str

    notes_text = '\n'.join(notes_block).lower()
    
    # 1. contains -> equal
    if 'contains -> equal' in notes_text or 'contains -> equals' in notes_text or 'contain -> equal' in notes_text:
        for stage in data.get('stages', []):
            if 'signatureContains' in stage:
                stage['signatureEquals'] = stage.pop('signatureContains')
            if 'conditions' in stage:
                for cond in stage['conditions']:
                    if cond.get('op', '').lower() == 'contains':
                        cond['op'] = 'eq'

    # 2. groupby -> username or entity-key or src_ip
    if 'groupby' in notes_text or 'correlation-key' in notes_text or 'correlationkey' in notes_text:
        if 'username' in notes_text or 'account_name' in notes_text or '[username]' in notes_text:
            data['correlationKey'] = 'username'
        elif 'entity-key' in notes_text or 'entity_key' in notes_text:
            data['correlationKey'] = 'entity_key'
        elif 'src_ip' in notes_text:
            data['correlationKey'] = 'src_ip'

    # 3. requireDistinctField / maxDistinctField / GroupBy specific
    if 'hostname' in notes_text and 'require' in notes_text:
        data['requireDistinctField'] = 'hostname'
        
    if rule_id == 'USB_MALWARE_INJECTION':
        if 'stages' in data and len(data['stages']) > 2:
            data['stages'][2]['excludeSignatureContains'] = ['msiexec.exe', 'setup.exe']
            
    if 'withinseconds : 0 -> 600' in notes_text:
        for stage in data.get('stages', []):
            if stage.get('label') == 'file_drop' or stage.get('label') == 'execution' or data.get('id') == 'ZEEK_CONN_THEN_HIDS_EXEC':
                stage['maxGapSeconds'] = 600
                
    return json.dumps(data, indent=2)

def main():
    with open(notes_path, 'r', encoding='utf-8') as f:
        notes = f.read()

    blocks = re.split(r'^\d+\s+', notes, flags=re.MULTILINE)[1:]
    modifications = {}
    for block in blocks:
        lines = [line.strip() for line in block.split('\n') if line.strip()]
        if lines:
            rule_id = lines[0].strip()
            modifications[rule_id] = lines[1:]

    modified_count = 0
    for root, _, files in os.walk(rules_dir):
        for file in files:
            if file.endswith('.md'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                json_match = re.search(r'```json\n(.*?)\n```', content, re.DOTALL)
                if not json_match:
                    continue
                
                json_str = json_match.group(1)
                try:
                    data = json.loads(json_str)
                    rule_id = data.get('id')
                except:
                    continue
                    
                if rule_id in modifications:
                    new_json_str = apply_modifications(rule_id, json_str, modifications[rule_id])
                    if new_json_str != json_str:
                        new_content = content.replace(json_str, new_json_str)
                        with open(filepath, 'w', encoding='utf-8') as f:
                            f.write(new_content)
                        print(f"Modified {file} ({rule_id})")
                        modified_count += 1
                        
    print(f"Total files modified: {modified_count}")

if __name__ == '__main__':
    main()
