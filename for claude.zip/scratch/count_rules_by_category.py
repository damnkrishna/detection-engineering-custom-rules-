import os

def count_rules_by_category():
    categories = [
        'collection',
        'command-and-control',
        'credential-access',
        'defense-impairment',
        'discovery',
        'execution',
        'exfiltration',
        'impact',
        'initial-access',
        'lateral-movement',
        'persistence',
        'privilege-escalation',
        'reconnaissance',
        'stealth'
    ]
    
    counts = {}
    total = 0
    for cat in categories:
        cat_path = f"./{cat}"
        if os.path.exists(cat_path):
            # Count md files
            files = [f for f in os.listdir(cat_path) if f.endswith('.md') and f.startswith('AN')]
            counts[cat] = len(files)
            total += len(files)
        else:
            counts[cat] = 0
            
    # Also check "new work" subdirectory
    new_work_total = 0
    for root, dirs, files in os.walk('./new work'):
        md_count = len([f for f in files if f.endswith('.md') and (f.startswith('CR') or f.startswith('AN'))])
        new_work_total += md_count
            
    print(f"Total rule files counted: {total}")
    for cat, cnt in counts.items():
        print(f"- {cat}: {cnt}")
    print(f"- new work folder (additional correlation): {new_work_total}")

if __name__ == '__main__':
    count_rules_by_category()
