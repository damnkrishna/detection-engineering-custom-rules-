import os
import re

files = [
    "AN8044-T0000-DET8044.md",
    "AN8051-T0000-DET8051.md",
    "AN8053-T0000-DET8053.md",
    "AN8055-T1558-DET8055.md",
    "AN8063-T0000-DET8063.md",
    "AN8064-T1053-DET8064.md",
    "AN8066-T0000-DET8066.md",
    "AN8074-T0000-DET8074.md",
    "AN8078-T1091-DET8078.md"
]

out_path = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\finalized_rules.txt"
needs_fixing_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\needs_fixing"

with open(out_path, "w", encoding="utf-8") as out_f:
    for filename in files:
        filepath = os.path.join(needs_fixing_dir, filename)
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
            match = re.search(r"```json\n(.*?)\n```", content, re.DOTALL)
            if match:
                out_f.write(f"=== {filename} ===\n")
                out_f.write(match.group(1).strip())
                out_f.write("\n\n\n")

print(f"Extraction complete. Wrote to {out_path}")
