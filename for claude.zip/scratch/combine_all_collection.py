import re
import os

def combine_all(files, out_path):
    combined = ""
    rule_count = 0
    for filepath in files:
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            continue
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
        filename = os.path.basename(filepath)
        combined += f"# ==========================================================================\n"
        combined += f"# SOURCE FILE: {filename}\n"
        combined += f"# ==========================================================================\n\n"
        for i, block in enumerate(yaml_blocks, 1):
            rule_count += 1
            combined += f"---\n"
            combined += f"# Rule {i} from {filename}\n"
            combined += block.strip() + "\n\n"
    with open(out_path, 'w', encoding='utf-8') as out:
        out.write(combined)
    print(f"Combined {rule_count} rules from {len(files)} files into:\n  {out_path}")

if __name__ == '__main__':
    all_files = [
        # Batch 1 — T1056 Input Capture
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0243-T1056.001-DET0089.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0282-T1056-DET0102.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0389-T1056.004-DET0139.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1321-T1056.003-DET0480.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1440-T1056.002-DET0521.md",
        # Batch 2 — T1557 AiTM
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0823-T1557-DET0296.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1091-T1557.002-DET0387.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1274-T1557.001-DET0462.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1290-T1557.003-DET0468.md",
    ]
    combine_all(
        all_files,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\sprint_collection_all_rules.txt"
    )
