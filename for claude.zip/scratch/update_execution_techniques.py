import openpyxl

wb = openpyxl.load_workbook("techniques_table.xlsx")
covered_ws = wb["Covered Techniques"]
uncovered_ws = wb["Uncovered Techniques"]

# Newly covered techniques in this batch
newly_covered = {
    "T1059.010": "Command and Scripting Interpreter: AutoHotKey & AutoIT",
    "T1204.004": "User Execution: Malicious Copy and Paste",
    "T1047": "Windows Management Instrumentation",
    "T1569.002": "System Services: Service Execution",
    "T1059.001": "Command and Scripting Interpreter: PowerShell",
    "T1204": "User Execution",
    "T1559": "Inter-Process Communication",
    "T1559.002": "Inter-Process Communication: Dynamic Data Exchange",
    "T1059": "Command and Scripting Interpreter",
    "T1106": "Native API"
}

# 1. Remove from Uncovered Techniques
uncovered_rows_to_delete = []
for r in range(2, uncovered_ws.max_row + 1):
    tech_id = uncovered_ws.cell(row=r, column=1).value
    if tech_id and str(tech_id).strip() in newly_covered:
        uncovered_rows_to_delete.append(r)

# Delete from bottom to top
for r in sorted(uncovered_rows_to_delete, reverse=True):
    uncovered_ws.delete_rows(r)

print(f"Deleted uncovered rows: {uncovered_rows_to_delete}")

# 2. Add to Covered Techniques (or update count if already there)
# Column 1: Technique ID, Column 2: Tactic, Column 3: Source, Column 4: Rule Count
for tech_id, name in newly_covered.items():
    found = False
    for r in range(2, covered_ws.max_row + 1):
        existing_id = covered_ws.cell(row=r, column=1).value
        if existing_id and str(existing_id).strip() == tech_id:
            # Update rule count by incrementing it
            val = covered_ws.cell(row=r, column=4).value
            try:
                count = int(val) if val is not None else 0
            except ValueError:
                count = 0
            covered_ws.cell(row=r, column=4, value=count + 1)
            found = True
            print(f"Incremented covered technique {tech_id}")
            break
            
    if not found:
        # Add a new row
        new_row = covered_ws.max_row + 1
        covered_ws.cell(row=new_row, column=1, value=tech_id)
        covered_ws.cell(row=new_row, column=2, value="Execution")
        covered_ws.cell(row=new_row, column=3, value=f"execution/{tech_id}.md") # approximate file path
        covered_ws.cell(row=new_row, column=4, value=1)
        print(f"Added new covered technique {tech_id}")

wb.save("techniques_table.xlsx")
print("Successfully updated techniques_table.xlsx")
