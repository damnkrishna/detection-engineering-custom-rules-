import os
import re

def verify_unshared_new_rules():
    # Recon rule files
    files = [
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\reconnaissance\AN2067-T1592-DET0924.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\reconnaissance\AN2069-T1594-DET0926.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\reconnaissance\AN2070-T1595-DET0927.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\reconnaissance\AN2073-T1598-DET0930.md",
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\reconnaissance\AN2075-T1682-DET0932.md"
    ]
    
    # Extract all rule IDs from these files
    new_rule_ids = set()
    for f in files:
        with open(f, 'r', encoding='utf-8', errors='ignore') as file_obj:
            content = file_obj.read()
        ids = re.findall(r'id:\s*([a-fA-F0-9\-]+)', content)
        for rid in ids:
            new_rule_ids.add(rid.strip().lower())
            
    print(f"Extracted {len(new_rule_ids)} rule IDs from the new files.")
    
    # Read all text files
    txt_files = [tf for tf in os.listdir('.') if tf.endswith('.txt')]
    shared_in_txt = set()
    for tf in txt_files:
        with open(tf, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        for rid in new_rule_ids:
            if rid in content.lower():
                shared_in_txt.add(rid)
                
    print(f"Of the new rules, these IDs were found in text files: {shared_in_txt}")

if __name__ == '__main__':
    verify_unshared_new_rules()
