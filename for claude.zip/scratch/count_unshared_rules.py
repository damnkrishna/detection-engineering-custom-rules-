import os
import re
import yaml

def get_shared_uuids():
    shared_rules = {} # id -> {title, an_id, source_file}
    
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
    for file in txt_files:
        filepath = file
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        documents = content.split('---')
        for doc in documents:
            doc = doc.strip()
            if not doc:
                continue
            if 'id:' in doc and 'title:' in doc:
                try:
                    parsed = yaml.safe_load(doc)
                    if isinstance(parsed, dict) and 'id' in parsed:
                        rule_id = str(parsed.get('id')).strip().lower()
                        shared_rules[rule_id] = parsed.get('title', 'Unknown')
                except Exception:
                    id_match = re.search(r'id:\s*([a-fA-F0-9\-]+)', doc)
                    if id_match:
                        rule_id = id_match.group(1).strip().lower()
                        shared_rules[rule_id] = 'Unknown'
    return shared_rules

def find_md_rules(shared_uuids):
    md_rules = []
    
    for root, dirs, files in os.walk('.'):
        # Exclude directories like .git
        if '.git' in root or '.gemini' in root or 'scratch' in root:
            continue
            
        for file in files:
            if file.endswith('.md') and not file.startswith('README'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Find all yaml blocks in markdown
                yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
                for i, block in enumerate(yaml_blocks, 1):
                    # Check if it's a Sigma/correlation rule block
                    if 'id:' in block or 'title:' in block:
                        try:
                            parsed = yaml.safe_load(block)
                            if isinstance(parsed, dict):
                                rule_id = str(parsed.get('id', '')).strip().lower()
                                title = parsed.get('title', 'Unknown')
                                md_rules.append({
                                    'id': rule_id,
                                    'title': title,
                                    'file': filepath,
                                    'block_index': i
                                })
                        except Exception:
                            id_match = re.search(r'id:\s*([a-fA-F0-9\-]+)', block)
                            title_match = re.search(r'title:\s*(.+)', block)
                            if id_match:
                                rule_id = id_match.group(1).strip().lower()
                                title = title_match.group(1).strip() if title_match else 'Unknown'
                                md_rules.append({
                                    'id': rule_id,
                                    'title': title,
                                    'file': filepath,
                                    'block_index': i
                                })
                                
    # Compare rules
    unshared = []
    for mr in md_rules:
        if mr['id'] not in shared_uuids:
            unshared.append(mr)
            
    print(f"Total rules found in .md files: {len(md_rules)}")
    print(f"Total unshared rules: {len(unshared)}")
    
    # Write to a file
    output_path = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\unshared_rules.txt"
    with open(output_path, 'w', encoding='utf-8') as out:
        out.write("Unshared rules (Present in .md files, NOT in .txt files)\n")
        out.write("=======================================================\n\n")
        for idx, rule in enumerate(unshared, 1):
            out.write(f"{idx}. Title: {rule['title']}\n")
            out.write(f"   ID: {rule['id']}\n")
            out.write(f"   File: {rule['file']} (Block #{rule['block_index']})\n\n")
            
    print(f"Unshared rules list written to {output_path}")

if __name__ == '__main__':
    shared = get_shared_uuids()
    find_md_rules(shared)
