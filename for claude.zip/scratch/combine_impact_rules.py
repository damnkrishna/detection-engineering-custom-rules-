import re
import os

def combine_rules(files, out_path):
    combined_content = ""
    rule_count = 0
    for filename in files:
        filepath = os.path.join(r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\impact", filename)
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            continue
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        yaml_blocks = re.findall(r'```yaml\s*\n(.*?)\n```', content, re.DOTALL)
        combined_content += f"# ==========================================================================\n"
        combined_content += f"# SOURCE FILE: {filename}\n"
        combined_content += f"# ==========================================================================\n\n"
        for i, block in enumerate(yaml_blocks, 1):
            rule_count += 1
            combined_content += f"---\n"
            combined_content += f"# Rule {i} from {filename}\n"
            combined_content += block.strip() + "\n\n"
    with open(out_path, 'w', encoding='utf-8') as out:
        out.write(combined_content)
    print(f"Combined {rule_count} rules into {out_path}")

if __name__ == '__main__':
    files = [
        "AN0584-T1499-DET0208.md",
        "AN0602-T1486-DET0215.md",
        "AN0662-T1491-DET0238.md",
        "AN0702-T1565.002-DET0254.md",
        "AN0741-T1496-DET0267.md",
        "AN0827-T1561.002-DET0297.md",
        "AN0850-T1499.004-DET0304.md",
        "AN0882-T1561.001-DET0316.md",
        "AN0933-T1490-DET0329.md",
        "AN0969-T1498.001-DET0343.md"
    ]
    combine_rules(
        files,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\sprint_impact_batch1_combined.txt"
    )
