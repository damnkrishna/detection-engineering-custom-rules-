import pandas as pd
import openpyxl

file_path = 'important_files/detection_coverage_matrix_final.xlsx'
wb = openpyxl.load_workbook(file_path)
ws = wb.active

# Find header row
header_row_idx = 1
for r_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=5), start=1):
    vals = [cell.value for cell in row]
    if 'Name / Category' in vals:
        header_row_idx = r_idx
        break

headers = {cell.value: idx for idx, cell in enumerate(ws[header_row_idx])}
name_col = headers.get('Name / Category')
gap_type_col = headers.get('Gap Type')
procure_col = headers.get('Needs Procurement (Y/N)')
if procure_col is None:
    procure_col = headers.get('Need New Tool? (Y/N)')
config_col = headers.get('Needs Config Change (Y/N)')
if config_col is None:
    config_col = headers.get('Needs IT Setup? (Y/N)')

# Rename columns
ws.cell(row=header_row_idx, column=procure_col+1).value = 'Need New Tool? (Y/N)'
ws.cell(row=header_row_idx, column=config_col+1).value = 'Needs IT Setup? (Y/N)'

for row in ws.iter_rows(min_row=header_row_idx+1):
    if row[name_col].value is None:
        continue
    
    gap_type = str(row[gap_type_col].value)
    
    if gap_type == 'Tooling / Capability Gap':
        row[procure_col].value = 'Y'
        row[config_col].value = 'N'  
        
    elif gap_type == 'Missing Logs':
        row[procure_col].value = 'N'
        row[config_col].value = 'Y'
        
    elif gap_type == 'Missing Rule':
        row[procure_col].value = 'N'
        row[config_col].value = 'N'
        
    elif gap_type == 'Orchestration Gap (SOAR playbook needed)':
        row[procure_col].value = 'N' 
        row[config_col].value = 'Y' 
        
    elif gap_type == 'Covered':
        row[procure_col].value = 'N'
        row[config_col].value = 'N'

wb.save(file_path)

# Export to CSV (we need to skip rows above header)
df = pd.read_excel(file_path, skiprows=header_row_idx-1)
df.to_csv('important_files/detection_coverage_matrix_final.csv', index=False)
print("Update complete")
