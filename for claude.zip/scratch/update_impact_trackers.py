import openpyxl

def update_sprint_sheet():
    sprint_path = "ocsf_mapped_new_sprint.xlsx"
    wb = openpyxl.load_workbook(sprint_path)
    ws = wb.active
    
    # Rows 467 to 476 (1-based index)
    rows_to_update = list(range(467, 477))
    print("=== Updating ocsf_mapped_new_sprint.xlsx ===")
    for r_idx in rows_to_update:
        # Col 12 is Status (column L, 1-based index 12)
        cell_status = ws.cell(row=r_idx, column=12)
        cell_analytic = ws.cell(row=r_idx, column=1)
        print(f"Row {r_idx} ({cell_analytic.value}): Status was '{cell_status.value}' -> setting to 'Done'")
        cell_status.value = "Done"
        
    wb.save(sprint_path)
    print("Saved ocsf_mapped_new_sprint.xlsx successfully.\n")

def update_techniques_table():
    tech_path = "techniques_table.xlsx"
    wb = openpyxl.load_workbook(tech_path)
    
    ws_unv = wb["Uncovered Techniques"]
    ws_cov = wb["Covered Techniques"]
    
    # 1. Update existing Covered rows
    print("=== Updating Covered Techniques in techniques_table.xlsx ===")
    for row in ws_cov.iter_rows(min_row=2):
        parent_id = row[0].value
        if parent_id == "T1491":
            # Defacement
            row[3].value = "T1491, T1491.001"
            row[4].value = (row[4].value or 0) + 2
            row[5].value = str(row[5].value) + ", AN0662-T1491-DET0238.md"
            print("Updated T1491")
        elif parent_id == "T1496":
            # Resource Hijacking
            row[3].value = "T1496, T1496.002"
            row[4].value = (row[4].value or 0) + 2
            row[5].value = str(row[5].value) + ", AN0741-T1496-DET0267.md"
            print("Updated T1496")
        elif parent_id == "T1499":
            # Endpoint DoS
            row[3].value = "T1499, T1499.002, T1499.004"
            row[4].value = (row[4].value or 0) + 4
            row[5].value = str(row[5].value) + ", AN0584-T1499-DET0208.md, AN0850-T1499.004-DET0304.md"
            print("Updated T1499")
        elif parent_id == "T1561":
            # Disk Wipe
            row[3].value = "T1561, T1561.001, T1561.002"
            row[4].value = (row[4].value or 0) + 4
            row[5].value = str(row[5].value) + ", AN0827-T1561.002-DET0297.md, AN0882-T1561.001-DET0316.md"
            print("Updated T1561")
        elif parent_id == "T1565":
            # Data Manipulation
            row[3].value = "T1565, T1565.001, T1565.002"
            row[4].value = (row[4].value or 0) + 2
            row[5].value = str(row[5].value) + ", AN0702-T1565.002-DET0254.md"
            print("Updated T1565")

    # 2. Identify and move newly covered rows
    to_move_parents = ["T1486", "T1490", "T1498"]
    moved_data = {
        "T1486": {
            "name": "Data Encrypted for Impact",
            "tactics": "Impact",
            "subs": "T1486",
            "count": 2,
            "sources": "AN0602-T1486-DET0215.md"
        },
        "T1490": {
            "name": "Inhibit System Recovery",
            "tactics": "Impact",
            "subs": "T1490",
            "count": 2,
            "sources": "AN0933-T1490-DET0329.md"
        },
        "T1498": {
            "name": "Network Denial of Service",
            "tactics": "Impact",
            "subs": "T1498, T1498.001",
            "count": 2,
            "sources": "AN0969-T1498.001-DET0343.md"
        }
    }
    
    # We will delete from Uncovered list in reverse order to keep row indices correct
    rows_to_delete = []
    for idx, row in enumerate(ws_unv.iter_rows(values_only=True), start=1):
        parent_id = row[0]
        if parent_id in to_move_parents:
            rows_to_delete.append(idx)
            
    print(f"Deleting rows from Uncovered Techniques: {rows_to_delete}")
    for r_idx in sorted(rows_to_delete, reverse=True):
        ws_unv.delete_rows(r_idx)
        
    # Append to Covered sheet
    print("Appending new entries to Covered Techniques...")
    for parent_id in to_move_parents:
        data = moved_data[parent_id]
        ws_cov.append([
            parent_id,
            data["name"],
            data["tactics"],
            data["subs"],
            data["count"],
            data["sources"]
        ])
        print(f"Appended {parent_id}")
        
    wb.save(tech_path)
    print("Saved techniques_table.xlsx successfully.\n")

if __name__ == '__main__':
    update_sprint_sheet()
    update_techniques_table()
