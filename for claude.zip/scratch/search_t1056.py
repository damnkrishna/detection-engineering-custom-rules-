import openpyxl

def search_t1056():
    tech_path = "techniques_table.xlsx"
    wb = openpyxl.load_workbook(tech_path)
    for name in wb.sheetnames:
        sheet = wb[name]
        for idx, row in enumerate(sheet.iter_rows(values_only=True), 1):
            if any(str(cell).strip() == "T1056" for cell in row):
                print(f"Found T1056 in sheet '{name}' at row {idx}: {row}")

if __name__ == '__main__':
    search_t1056()
