import openpyxl

file_path = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\ocsf_mapped_new_sprint.xlsx"
wb = openpyxl.load_workbook(file_path)
ws = wb.active

updated_rows = []
for row in range(225, 235):
    # Set Status to Done
    ws.cell(row=row, column=12, value='Done')
    # Set updated or not to Yes
    ws.cell(row=row, column=14, value='Yes')
    updated_rows.append(row)

wb.save(file_path)
print(f"Updated rows in ocsf_mapped_new_sprint.xlsx: {updated_rows}")
