import pandas as pd
import openpyxl

file_path = 'important_files/detection_coverage_matrix_final.xlsx'
wb = openpyxl.load_workbook(file_path)
ws = wb.active

# headers are on row 2
headers = {cell.value: idx for idx, cell in enumerate(ws[2])}
name_col = headers.get('Name / Category')
gap_type_col = headers.get('Gap Type')
procure_col = headers.get('Needs Procurement (Y/N)')
if procure_col is None:
    # Handle if already renamed
    procure_col = headers.get('Need New Tool? (Y/N)')
    if procure_col is None:
        procure_col = headers.get('Needs New Purchase? (Y/N)')

config_col = headers.get('Needs Config Change (Y/N)')
if config_col is None:
    config_col = headers.get('Needs IT Setup? (Y/N)')

# Rename columns
ws[2][procure_col].value = 'Need New Tool? (Y/N)'
ws[2][config_col].value = 'Needs IT Setup? (Y/N)'

for row in ws.iter_rows(min_row=3):
    if row[name_col].value is None:
        continue
    
    gap_type = str(row[gap_type_col].value)
    
    if gap_type == 'Tooling / Capability Gap':
        row[procure_col].value = 'Y'
        row[config_col].value = 'N'  
        
    elif gap_type == 'Missing Logs':
        row[procure_col].value = 'N'
        row[config_col].value = 'Y'
        
    elif gap_type == 'Missing Rule':
        row[procure_col].value = 'N'
        row[config_col].value = 'N'
        
    elif gap_type == 'Orchestration Gap (SOAR playbook needed)':
        row[procure_col].value = 'N' 
        row[config_col].value = 'Y' 
        
    elif gap_type == 'Covered':
        row[procure_col].value = 'N'
        row[config_col].value = 'N'

wb.save(file_path)

# Export to CSV
df = pd.read_excel(file_path, skiprows=1)
df.to_csv('important_files/detection_coverage_matrix_final.csv', index=False)
print("Update complete")
