import json
import re

file_path = r'C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\credential-access\AN0105-T1555.003-DET0037.md'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix OCSF Rule to include selection_tools_original
ocsf_original = """    selection_tools_original:
        unmapped.OriginalFileName:
            - 'Cmd.Exe'
            - 'PowerShell.EXE'
            - 'pwsh.dll'
            - 'xcopy.exe'
            - 'robocopy.exe'
            - 'tar.exe'
            - '7z.exe'
"""

if 'selection_tools_original:' not in content and 'class: process_activity' in content:
    # Insert after selection_tools block
    content = content.replace("    selection_chrome_login:\n        process.cmd_line|contains|all:", ocsf_original + "    selection_chrome_login:\n        process.cmd_line|contains|all:")
    # Update OCSF condition
    content = content.replace("condition: selection_tools and (selection_chrome_login", "condition: (selection_tools or selection_tools_original) and (selection_chrome_login")

# Add new test cases to the documentation
new_tp_docs = """
* True Positive 6: Renamed Binary Evasion (Rule 1)
  * The Log: Process Creation with Image `C:\\Temp\\totally_not_cmd.exe` but `unmapped.OriginalFileName` is `Cmd.Exe`.
  * Expected Outcome: Matches `selection_tools_original` instead of `selection_tools_image`. MUST trigger an alert.

* True Positive 7: Rule 2 Path Isolation (Rule 2)
  * The Log: File Event reading `C:\\Users\\Target\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Preferences`.
  * Expected Outcome: Matches `selection_paths` but NOT `selection_files`, proving the OR logic works. MUST trigger an alert.

* True Positive 8: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"` instead of an integer `1`.
  * Expected Outcome: Tests if the engine's JSON parser crashes on type mismatches or coerces the type gracefully. MUST trigger an alert (if coercion succeeds) or log a parser error.

* True Positive 9: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the exact same timestamp.
  * Expected Outcome: Tests if the engine's deduplication window correctly suppresses or passes identical events.
"""
if '* True Positive 6:' not in content:
    content = content.replace("#### Benign / True Negatives", new_tp_docs + "\n#### Benign / True Negatives")

new_tn_docs = """
* Benign 3: Brave Browser Operation (Rule 2 Filter)
  * The Log: File Event with Image `brave.exe` reading the Brave `Login Data` file.
  * Expected Outcome: The `Image` explicitly matches the `filter_browsers` allowlist (`\\brave.exe`). MUST NOT trigger an alert.
"""
if '* Benign 3:' not in content:
    content = content.replace("---", new_tn_docs + "\n---", 1) # Only replace the first --- after Benign 2


# Now extract the JSON block
json_match = re.search(r'```json\n(.*?)\n```', content, re.DOTALL)
if json_match:
    json_str = json_match.group(1)
    events = json.loads(json_str)
    
    # Identify indices robustly
    tp01_idx = next(i for i, ev in enumerate(events) if ev['metadata']['test_case'] == 'TP-01')
    tp04_idx = next(i for i, ev in enumerate(events) if ev['metadata']['test_case'] == 'TP-04')
    tn01_idx = next(i for i, ev in enumerate(events) if ev['metadata']['test_case'] == 'TN-01')
    
    # 1. Add time to existing events
    base_time = 1718000000
    for i, ev in enumerate(events):
        if 'time' not in ev:
            ev['time'] = base_time + i * 10
        
    # Check if TP-06 already exists in json
    if not any(ev['metadata']['test_case'] == 'TP-06' for ev in events):
        # TP-06: Renamed Binary
        tp06 = json.loads(json.dumps(events[tp01_idx]))
        tp06['metadata']['test_case'] = 'TP-06'
        tp06['metadata']['description'] = 'Renamed Binary Evasion (Rule 1)'
        tp06['time'] = base_time + 60
        tp06['process']['file']['path'] = "C:\\Temp\\totally_not_cmd.exe"
        tp06['process']['file']['name'] = "totally_not_cmd.exe"
        tp06['unmapped']['OriginalFileName'] = "Cmd.Exe"
        events.append(tp06)
        
        # TP-07: Rule 2 Path Isolation
        tp07 = json.loads(json.dumps(events[tp04_idx])) # Based on TP-04
        tp07['metadata']['test_case'] = 'TP-07'
        tp07['metadata']['description'] = 'Rule 2 Path Isolation (Rule 2)'
        tp07['time'] = base_time + 70
        tp07['file']['path'] = "C:\\Users\\Target\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Preferences"
        tp07['file']['name'] = "Preferences"
        events.append(tp07)
        
        # TN-03: Brave Browser
        tn03 = json.loads(json.dumps(events[tn01_idx])) # Based on TN-01
        tn03['metadata']['test_case'] = 'TN-03'
        tn03['metadata']['description'] = 'Brave Browser Operation (Rule 2 Filter)'
        tn03['metadata']['expected_alert'] = False
        tn03['time'] = base_time + 80
        tn03['file']['path'] = "C:\\Users\\Target\\AppData\\Local\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Login Data"
        tn03['process']['file']['path'] = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
        tn03['process']['file']['name'] = "brave.exe"
        events.append(tn03)
        
        # TP-08: Type Validation Failure
        tp08 = json.loads(json.dumps(events[tp01_idx]))
        tp08['metadata']['test_case'] = 'TP-08'
        tp08['metadata']['description'] = 'Schema Type Validation Failure (Rule 1)'
        tp08['time'] = base_time + 90
        tp08['activity_id'] = "1" # String instead of int
        events.append(tp08)
        
        # TP-09: Duplicate Event
        tp09 = json.loads(json.dumps(events[tp01_idx]))
        tp09['metadata']['test_case'] = 'TP-09'
        tp09['metadata']['description'] = 'Exact Duplicate Event (Rule 1)'
        # exact same time as TP-01
        tp09['time'] = events[tp01_idx]['time']
        events.append(tp09)
        
        # Volume Stress Test (100 TP, 100 TN)
        # We will serialize these differently to save space in markdown
        volume_events = []
        vol_time = base_time + 1000
        for i in range(1, 51): # 50 TP
            vol = json.loads(json.dumps(events[tp01_idx]))
            vol['metadata']['test_case'] = f'VOL-TP-{i}'
            vol['metadata']['description'] = 'Volume Stress Test (TP)'
            vol['time'] = vol_time + i
            vol['process']['cmd_line'] = f"cmd.exe /c copy \"C:\\Users\\Target\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Login Data\" C:\\Temp\\loot_{i}.db"
            volume_events.append(vol)
            
        for i in range(1, 51): # 50 TN
            vol = json.loads(json.dumps(events[tn01_idx]))
            vol['metadata']['test_case'] = f'VOL-TN-{i}'
            vol['metadata']['description'] = 'Volume Stress Test (TN)'
            vol['metadata']['expected_alert'] = False
            vol['time'] = vol_time + 50 + i
            volume_events.append(vol)
            
        all_events = events + volume_events
        
        # To keep markdown clean, we output formatted JSON for the core 12 events,
        # and 1-line compact JSON for the 100 volume events.
        json_lines = ["[\n"]
        for i, ev in enumerate(all_events):
            if i < len(events):
                json_lines.append("  " + json.dumps(ev, indent=2).replace('\n', '\n  '))
            else:
                json_lines.append("  " + json.dumps(ev))
            if i < len(all_events) - 1:
                json_lines[-1] += ",\n"
            else:
                json_lines[-1] += "\n"
        json_lines.append("]")
        
        new_json_block = "".join(json_lines)
        
        # Replace the old json block
        content = content[:json_match.start()] + "```json\n" + new_json_block + "\n```" + content[json_match.end():]
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
            
        print("Successfully rewritten AN0105-T1555.003-DET0037.md")
else:
    print("Could not find JSON block")

