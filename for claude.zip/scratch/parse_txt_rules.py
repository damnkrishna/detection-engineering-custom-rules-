import os
import re
import yaml

def parse_txt_files():
    shared_rules = {} # id -> {title, an_id, source_file}
    
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
    print(f"Scanning files: {txt_files}")
    
    # Regex to find UUIDs and titles in text files
    # Or try loading YAML documents split by '---'
    for file in txt_files:
        filepath = file
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        # Try finding YAML document separators
        documents = content.split('---')
        for doc in documents:
            doc = doc.strip()
            if not doc:
                continue
            
            # Basic checks if it looks like a Sigma rule
            if 'id:' in doc and 'title:' in doc:
                try:
                    # Parse using safe_load or regex if safe_load fails due to text surrounding the yaml
                    parsed = yaml.safe_load(doc)
                    if isinstance(parsed, dict) and 'id' in parsed:
                        rule_id = str(parsed.get('id')).strip().lower()
                        title = parsed.get('title', 'Unknown')
                        
                        # Find AN ID via tags or title or description
                        an_id = None
                        tags = parsed.get('tags', [])
                        if isinstance(tags, list):
                            for tag in tags:
                                if tag.startswith('analytic.an'):
                                    an_id = tag.replace('analytic.an', 'AN').upper()
                                    break
                        if not an_id:
                            # Try finding ANxxxx in title or description or tags
                            match = re.search(r'AN\d{4}', str(title) + " " + str(parsed.get('description', '')))
                            if match:
                                an_id = match.group(0).upper()
                        
                        if rule_id not in shared_rules:
                            shared_rules[rule_id] = {
                                'title': title,
                                'an_id': an_id,
                                'files': {file}
                            }
                        else:
                            shared_rules[rule_id]['files'].add(file)
                except Exception:
                    # Regex fallback if safe_load fails
                    id_match = re.search(r'id:\s*([a-fA-F0-9\-]+)', doc)
                    title_match = re.search(r'title:\s*(.+)', doc)
                    if id_match:
                        rule_id = id_match.group(1).strip().lower()
                        title = title_match.group(1).strip() if title_match else 'Unknown'
                        an_match = re.search(r'AN\d{4}', doc)
                        an_id = an_match.group(0).upper() if an_match else None
                        
                        if rule_id not in shared_rules:
                            shared_rules[rule_id] = {
                                'title': title,
                                'an_id': an_id,
                                'files': {file}
                            }
                        else:
                            shared_rules[rule_id]['files'].add(file)

    # Let's write the results
    print(f"Found {len(shared_rules)} unique rules in .txt files.")
    
    # Sort and group by AN ID
    grouped = {}
    for rid, info in shared_rules.items():
        an = info['an_id'] or 'UNMAPPED'
        if an not in grouped:
            grouped[an] = []
        grouped[an].append({
            'id': rid,
            'title': info['title'],
            'files': sorted(list(info['files']))
        })
        
    # Write to a file
    output_path = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\shared_rules_inventory.txt"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as out:
        out.write("Shared Rules Inventory from .txt Files\n")
        out.write("======================================\n\n")
        for an in sorted(grouped.keys()):
            out.write(f"### {an}\n")
            for rule in grouped[an]:
                out.write(f"- Title: {rule['title']}\n")
                out.write(f"  ID: {rule['id']}\n")
                out.write(f"  Source Files: {', '.join(rule['files'])}\n")
            out.write("\n")
            
    print(f"Inventory written to {output_path}")

if __name__ == '__main__':
    parse_txt_files()
