import openpyxl

def analyze_scope():
    tech_path = "techniques_table.xlsx"
    rules_path = r"new work\rules_coverage_summary.xlsx"
    
    # 1. Analyze Uncovered Techniques
    uncovered_count = 0
    by_tactic = {}
    try:
        wb_tech = openpyxl.load_workbook(tech_path, data_only=True)
        sheet_uncovered = wb_tech["Uncovered Techniques"]
        rows = list(sheet_uncovered.iter_rows(values_only=True))
        headers = rows[0]
        # Columns: Parent ID, Technique Name, Tactics, Platform
        for r in rows[1:]:
            if any(r):
                uncovered_count += 1
                tactic_str = r[2]
                if tactic_str:
                    # Tactics can be comma-separated like "Credential Access, Discovery"
                    tactics = [t.strip() for t in tactic_str.split(',')]
                    for t in tactics:
                        by_tactic[t] = by_tactic.get(t, 0) + 1
    except Exception as e:
        print("Error reading techniques table:", e)
        
    # 2. Analyze Pending Correlation Rules
    pending_rules_count = 0
    pending_by_cat = {}
    try:
        wb_rules = openpyxl.load_workbook(rules_path, data_only=True)
        sheet_future = wb_rules["Future Rules"]
        rows_future = list(sheet_future.iter_rows(values_only=True))
        # Headers: Rule ID, Rule Name, Priority, Category, Description, Sensors, MITRE Tactics, MITRE Techniques, Total Stages, Proposed Logic, Status
        for r in rows_future[1:]:
            if any(r):
                status = r[10] # Status column index 10
                category = r[3] # Category column index 3
                if status == 'Not Done':
                    pending_rules_count += 1
                    pending_by_cat[category] = pending_by_cat.get(category, 0) + 1
    except Exception as e:
        print("Error reading rules coverage summary:", e)
        
    # Output analysis
    out_path = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\uncovered_and_pending_summary.txt"
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write("UNCOVERED MITRE ATT&CK TECHNIQUES\n")
        f.write("===================================\n")
        f.write(f"Total uncovered techniques left: {uncovered_count}\n\n")
        f.write("Uncovered Techniques by Tactic/Category:\n")
        for t in sorted(by_tactic.keys()):
            f.write(f"- {t}: {by_tactic[t]}\n")
            
        f.write("\n\nPENDING CORRELATION RULES TO WRITE (from rules_coverage_summary.xlsx)\n")
        f.write("======================================================================\n")
        f.write(f"Total pending rules left: {pending_rules_count}\n\n")
        f.write("Pending Rules by Category:\n")
        for c in sorted(pending_by_cat.keys()):
            f.write(f"- {c}: {pending_by_cat[c]}\n")
            
    print(f"Analysis successfully written to {out_path}")

if __name__ == '__main__':
    analyze_scope()
