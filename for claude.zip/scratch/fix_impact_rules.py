import os

def fix_rules():
    impact_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\impact"
    
    # ---------------------------------------------------------
    # AN0584-T1499-DET0208.md
    # ---------------------------------------------------------
    f_0584 = os.path.join(impact_dir, "AN0584-T1499-DET0208.md")
    content_0584 = """### 1. Technique Breakdown: T1499

* What it is: Endpoint Denial of Service. Adversaries target endpoints with resource exhaustion attacks or cause unexpected service terminations. The goal is to disable security controls, disrupt logging agents (like Sysmon, Wazuh, Defender), or crash business-critical server applications to prevent response or trigger outages.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) / Windows Security Event ID 4688, and Windows System Event Log (Event ID 7034).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon tracks stressing utilities; Windows System logs track service terminations.
  - NIDS (Suricata + Zeek): NO. Host-local resource and service states.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Windows System Log Event ID 7034 (service_terminated_unexpectedly)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Endpoint CPU or Memory Stressing Execution
Detects the execution of known stressing tools or benchmark utilities when executed with explicit parameters to exhaust memory/CPU.

```yaml
title: Endpoint CPU or Memory Stressing Execution (AN0584-A)
id: c95af279-b364-4f47-9199-8016ebb95fb8
status: experimental
description: Detects command-line execution of stress-testing tools or scripts designed to exhaust system CPU or memory resources on endpoints.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\cpustres.exe'
            - '\heavyload.exe'
            - '\stressapptest.exe'
            - '\prime95.exe'
            - '\cinebench.exe'
            - '\memtest.exe'
        OriginalFileName:
            - 'cpustres.exe'
            - 'heavyload.exe'
            - 'stressapptest.exe'
            - 'prime95.exe'
            - 'cinebench.exe'
            - 'memtest.exe'
    selection_cli:
        CommandLine|contains:
            - 'consume-cpu'
            - 'consume-mem'
            - 'stress-ng'
            - '--cpu-load'
            - 'burn-in'
    filter_admin:
        User|contains: 'SYSTEM'
        ParentImage|endswith:
            - '\msiexec.exe'
            - '\setup.exe'
    condition: (selection_images or selection_cli) and not filter_admin
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - ParentImage
    - User
falsepositives:
    - Performance benchmarks conducted by IT administrators, hardware diagnostics, or developers testing application resource management.
level: medium
tags:
    - attack.impact
    - attack.t1499
    - analytic.an0584
    - detection.det0208
```

#### Rule 2 of 2: Windows Service Unexpected Termination
Detects sudden, unexpected terminations of critical system services (e.g. Sysmon, Defender, Spooler, LSASS) indicating potential exploitation or targeted service kill loops.

```yaml
title: Windows Service Unexpected Termination (AN0584-B)
id: 3eb601c4-2bbe-46a4-b76d-4b45cc476c33
status: experimental
description: Detects Service Control Manager Event ID 7034 logs showing unexpected termination of critical security or system services.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    service: system
detection:
    selection_crash:
        EventID: 7034
    selection_critical_services:
        # Match exact critical service names to prevent loose matching errors
        Description|contains:
            - 'System Monitor'
            - 'Windows Defender'
            - 'Print Spooler'
            - 'Local Security Authority'
            - 'WazuhSvc'
            - 'CrowdStrike'
            - 'SentinelAgent'
    condition: selection_crash and selection_critical_services
fields:
    - EventID
    - Description
    - Source
falsepositives:
    - Unstable updates or software conflicts crashing system services under normal operational loads.
level: medium
tags:
    - attack.impact
    - attack.t1499
    - analytic.an0584
    - detection.det0208
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Custom Stressing Scripts & Thresholds
  * The Issue: Rule 1 fires on a single invocation of stress utilities. It does not enforce a frequency threshold, which can cause false positives during manual administrative stress tests.
  * The Fix: Implement SIEM-side aggregation to alert only if the stress events count is >2 within a 5-minute window for a specific computer: `count() by Computer > 2 in 5m`.
* Problem 2: Single Crash Alerts vs. True Loops
  * The Issue: Rule 2 alerts on a single occurrence of service crash (Event ID 7034). Legitimate system failures or Windows Update restarts may cause occasional single service crashes.
  * The Fix: Aggregate Event ID 7034 logs in the SIEM layer to alert only when the same service name terminates unexpectedly 3 or more times within a 5-minute window (`count() by Description > 3 in 5m`).
"""
    with open(f_0584, 'w', encoding='utf-8') as f:
        f.write(content_0584)

    # ---------------------------------------------------------
    # AN0602-T1486-DET0215.md
    # ---------------------------------------------------------
    f_0602 = os.path.join(impact_dir, "AN0602-T1486-DET0215.md")
    content_0602 = """### 1. Technique Breakdown: T1486

* What it is: Data Encrypted for Impact. Adversaries encrypt data on target systems to disrupt system availability and demand ransom. To perform this, they use native tools or custom malware to traverse the filesystem, modify extensions, write ransom notes, and disable recovery paths.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) / Security Event ID 4688, and Sysmon File Creation events (Event ID 11).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon Event ID 11 logs file creation details. Sysmon Event ID 1 logs execution parameters.
  - NIDS (Suricata + Zeek): NO. Host-local filesystem modifications.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 11 (file_event)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Ransom Note Creation and Suspicious Extensions
Detects the creation of files with known ransomware note names or specific ransomware-associated file extensions.

```yaml
title: Ransom Note Creation and Suspicious Extensions (AN0602-A)
id: 93367441-a024-4bd3-a527-1c32170a8cfe
status: experimental
description: Detects the drop of ransomware ransom instructions or bulk files with known ransomware extensions.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_notes:
        TargetFilename|endswith:
            - '\README_TO_DECRYPT.txt'
            - '\DECRYPT_INSTRUCTIONS.html'
            - '\HOW_TO_DECRYPT.txt'
            - '\HELP_DECRYPT.txt'
            - '\RESTORE_FILES.txt'
    selection_encrypted:
        TargetFilename|endswith:
            # Dropped generic .enc extension to avoid false positives with database backups
            - '.locky'
            - '.crypto'
            - '.locked'
            - '.ryuk'
            - '.wannacry'
    filter_sys:
        Image|endswith:
            - '\msiexec.exe'
            - '\tiworker.exe'
            - '\setup.exe'
            - '\update.exe'
    condition: (selection_notes or selection_encrypted) and not filter_sys
fields:
    - TargetFilename
    - Image
    - User
falsepositives:
    - Diagnostic tools or backup agents writing log files with these specific extensions.
level: high
tags:
    - attack.impact
    - attack.t1486
    - analytic.an0602
    - detection.det0215
```

#### Rule 2 of 2: Volume Shadow Copy Deletion via Native Utilities
Detects command-line execution of native tools attempting to delete shadow copies or inhibit system backups, filtering out standard system-driven tasks.

```yaml
title: Volume Shadow Copy Deletion via Native Utilities (AN0602-B)
id: f8775091-a408-4549-baa5-780cd79d3c06
status: experimental
description: Detects CLI usage of vssadmin, wbadmin, wmic, or bcdedit attempting to delete shadow copies or backup catalogs.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_commands:
        Image|endswith:
            - '\vssadmin.exe'
            - '\wmic.exe'
            - '\wbadmin.exe'
            - '\bcdedit.exe'
        OriginalFileName:
            - 'vssadmin.exe'
            - 'wmic.exe'
            - 'wbadmin.exe'
            - 'bcdedit.exe'
    selection_args:
        CommandLine|contains:
            - 'delete shadows'
            - 'shadowcopy delete'
            - 'delete catalog'
            - 'recoveryenabled no'
            - 'ignoreallfailures'
    filter_legitimate:
        ParentImage|endswith:
            - '\msiexec.exe'
            - '\backup.exe'
            - '\veeam.exe'
        User: 'NT AUTHORITY\SYSTEM'
    condition: selection_commands and selection_args and not filter_legitimate
fields:
    - Image
    - CommandLine
    - User
falsepositives:
    - Legitimate system administration scripts or backup solutions (like Veeam) managing system space.
level: critical
tags:
    - attack.impact
    - attack.t1486
    - analytic.an0602
    - detection.det0215
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Custom Wiping Extensions and SIEM Thresholds
  * The Issue: Attackers often randomize file extensions, bypassing static extension checks in Rule 1.
  * The Fix: Use the SIEM correlation engine to aggregate Event ID 11 file creations/modifications and alert when more than 100 files are modified by a single non-system process within a 1-minute window.
* Problem 2: Direct API Access
  * The Issue: Ransomware can interact directly with VSS COM interfaces, deleting shadow copies without executing `vssadmin.exe`.
  * The Fix: Enable Security Log Event ID 4656/4663 auditing for the Volume Shadow Copy service database, and monitor for unexpected access handles.
"""
    with open(f_0602, 'w', encoding='utf-8') as f:
        f.write(content_0602)

    # ---------------------------------------------------------
    # AN0662-T1491-DET0238.md
    # ---------------------------------------------------------
    f_0662 = os.path.join(impact_dir, "AN0662-T1491-DET0238.md")
    content_0662 = """### 1. Technique Breakdown: T1491

* What it is: Defacement. Adversaries modify content hosted on web applications or system logon screens to convey messages or disrupt operations. This is accomplished by modifying local web root files or changing Windows Registry parameters.
* Log Source Requirements: Sysmon File Creation/Modification events (Event ID 11) and Sysmon Registry Set events (Event ID 13).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. File write activity inside web directories is captured by Sysmon EID 11. Registry adjustments are tracked by EID 13.
  - NIDS (Suricata + Zeek): NO. Host-local modification of assets.
* Log Sources Covered:
  - Sysmon Event ID 11 (file_event)
  - Sysmon Event ID 13 (registry_set)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Static Web Page Modification by Non-Webserver Process
Detects modifications to static web pages (.html, .js, .css) inside standard web directories by processes other than standard web servers, CI/CD deployment agents, or text editors.

```yaml
title: Static Web Page Modification by Non-Webserver Process (AN0662-A)
id: 5d207b72-a79b-4bdf-8258-6f116311c385
status: experimental
description: Detects modifications of HTML/JS/CSS files in standard web roots by processes other than IIS, Apache, Nginx, or administrative editors.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_web_paths:
        TargetFilename|contains:
            - '\inetpub\wwwroot\'
            - '\apache\htdocs\'
            - '\nginx\html\'
            - '\tomcat\webapps\'
    selection_extensions:
        TargetFilename|endswith:
            - '.html'
            - '.htm'
            - '.js'
            - '.css'
    filter_webservers:
        Image|endswith:
            - '\w3wp.exe'
            - '\httpd.exe'
            - '\nginx.exe'
            - '\tomcat.exe'
            - '\msdeploy.exe'
    filter_editors:
        Image|endswith:
            - '\notepad.exe'
            - '\code.exe'
            - '\explorer.exe'
    filter_deployment:
        ParentImage|endswith:
            - '\msdeploy.exe'
            - '\git.exe'
            - '\svn.exe'
    condition: selection_web_paths and selection_extensions and not (filter_webservers or filter_editors or filter_deployment)
fields:
    - TargetFilename
    - Image
    - User
falsepositives:
    - Internal deployment tools or custom scripting frameworks updating web assets legitimately.
level: medium
tags:
    - attack.impact
    - attack.t1491
    - analytic.an0662
    - detection.det0238
```

#### Rule 2 of 2: Logon Warning Banner Registry Modification
Detects registry modifications to the legal notice caption or text keys commonly tampered with to display hacker messages on the login screen.

```yaml
title: Logon Warning Banner Registry Modification (AN0662-B)
id: 2a340a64-9fce-4edb-9d8d-d03bcf0635e6
status: experimental
description: Detects modification of LegalNoticeCaption or LegalNoticeText registry values.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_registry:
        TargetObject|endswith:
            - '\Microsoft\Windows\CurrentVersion\Policies\System\LegalNoticeCaption'
            - '\Microsoft\Windows\CurrentVersion\Policies\System\LegalNoticeText'
    filter_system:
        Image|endswith:
            - '\svchost.exe'
    filter_gpo:
        Image|endswith:
            - '\gpupdate.exe'
            - '\csrss.exe'
        ParentImage|endswith:
            - '\svchost.exe'
    condition: selection_registry and not (filter_system or filter_gpo)
fields:
    - TargetObject
    - Details
    - Image
    - User
falsepositives:
    - Group policy updates enforcing enterprise standard logon banners.
level: high
tags:
    - attack.impact
    - attack.t1491
    - analytic.an0662
    - detection.det0238
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Dev vs Prod Web Root Modifications
  * The Issue: Development environments modify HTML constantly, creating heavy alert noise under Rule 1.
  * The Fix: Scope the `selection_web_paths` to production paths only (e.g. `C:\\inetpub\\wwwroot\\prod\\`) or baseline the approved editor binaries of the developer team.
* Problem 2: Logon Warning Content Validation
  * The Issue: Group policy updates will occasionally trigger Rule 2.
  * The Fix: In the SIEM, filter out alerts where the `Details` field matches the approved corporate warning banner string.
"""
    with open(f_0662, 'w', encoding='utf-8') as f:
        f.write(content_0662)

    # ---------------------------------------------------------
    # AN0702-T1565.002-DET0254.md
    # ---------------------------------------------------------
    f_0702 = os.path.join(impact_dir, "AN0702-T1565.002-DET0254.md")
    content_0702 = """### 1. Technique Breakdown: T1565.002

* What it is: Data Manipulation: Transmitted Data Manipulation. Adversaries alter data in transit, such as web traffic, API payloads, or network packets. This is typically achieved by running network redirection software, configuring man-in-the-middle tools, or modifying system routing parameters (like the hosts file) to hijack lookup destinations.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1), Sysmon File Creation/Modification events (Event ID 11), and Sysmon Registry Set events (Event ID 13).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Process arguments, hosts file writing, and registry routing are fully monitored.
  - NIDS (Suricata + Zeek): YES. Network protocol changes can sometimes be seen, but host logs provide deterministic process attribution.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 11 (file_event)
  - Sysmon Event ID 13 (registry_set)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: MitM and Redirection Tool Execution
Detects the execution of known network redirection or traffic interception frameworks.

```yaml
title: MitM and Redirection Tool Execution (AN0702-A)
id: 91f71d09-9749-4143-b79e-9bf730fbf88b
status: experimental
description: Detects command-line execution of man-in-the-middle, ARP spoofing, or packet redirect tools.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\ettercap.exe'
            - '\bettercap.exe'
            - '\mitmproxy.exe'
            - '\mitmdump.exe'
            - '\cain.exe'
            - '\arpspoof.exe'
        OriginalFileName:
            - 'ettercap.exe'
            - 'bettercap.exe'
            - 'mitmproxy.exe'
            - 'mitmdump.exe'
            - 'cain.exe'
            - 'arpspoof.exe'
    selection_cli:
        CommandLine|contains:
            # Require more specific flags rather than bare strings to avoid noise
            - 'ettercap -'
            - 'bettercap -'
            - 'mitmproxy -'
            - 'arpspoof -'
    filter_admin:
        ParentImage|endswith:
            - '\powershell.exe'
            - '\cmd.exe'
        User|contains:
            - 'admin'
            - 'network'
    filter_installers:
        ParentImage|endswith:
            - '\msiexec.exe'
            - '\setup.exe'
    condition: (selection_images or selection_cli) and not (filter_installers or filter_admin)
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Network engineers running authorized security reviews or diagnostics.
level: high
tags:
    - attack.impact
    - attack.t1565.002
    - analytic.an0702
    - detection.det0254
```

#### Rule 2 of 2: Hosts File Tampering or Static DNS Routing Modification
Detects unauthorized updates to the Windows hosts file or modifications to default name server registry values.

```yaml
title: Hosts File Tampering or Static DNS Routing Modification (AN0702-B)
id: e285b0c8-2b6f-4013-bf09-69d41182db98
status: experimental
description: Detects modification of the Windows hosts file or registry configuration defining local system DNS servers.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_hosts:
        TargetFilename|endswith:
            - '\drivers\etc\hosts'
    filter_system:
        Image|endswith:
            - '\system32\svchost.exe'
            - '\system32\notepad.exe'
    filter_gpo:
        Image|endswith:
            - '\gpupdate.exe'
        ParentImage|endswith:
            - '\svchost.exe'
    condition: selection_hosts and not (filter_system or filter_gpo)
fields:
    - TargetFilename
    - Image
    - User
falsepositives:
    - Administrators using Notepad to update local name resolution profiles during migration.
level: high
tags:
    - attack.impact
    - attack.t1565.002
    - analytic.an0702
    - detection.det0254
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Administrative Script Modification of Hosts
  * The Issue: Automated GPO scripts or local administration setups updating local hosts files can trigger frequent alerts under Rule 2.
  * The Fix: Baseline the approved admin scripts and whitelist their file content signatures in the SIEM layer.
* Problem 2: Dynamic Name Resolution Changes
  * The Issue: Attackers can execute netsh commands to modify active interface DNS configurations without writing to static hosts files.
  * The Fix: Enable monitoring of process creations command lines for commands containing `netsh interface ipv4 set dns`.
"""
    with open(f_0702, 'w', encoding='utf-8') as f:
        f.write(content_0702)

    # ---------------------------------------------------------
    # AN0741-T1496-DET0267.md
    # ---------------------------------------------------------
    f_0741 = os.path.join(impact_dir, "AN0741-T1496-DET0267.md")
    content_0741 = """### 1. Technique Breakdown: T1496

* What it is: Resource Hijacking. Adversaries leverage compromised endpoint resources for unauthorized utility, typically for cryptomining (e.g. Monero mining). They deploy binaries or scripts that run persistently in the background, consuming CPU, GPU, and network resources.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and Sysmon Network Connection events (Event ID 3).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Miner binaries and command lines are detected via process creation. Outbound pool network traffic is detected via network connections.
  - NIDS (Suricata + Zeek): YES. Stratum protocol signatures on outbound ports can be flagged by network IDS.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 3 (network_connection)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Cryptomining Utility Process Execution
Detects the execution of cryptocurrency mining binaries or scripts containing command-line arguments specific to stratum protocols, wallet configurations, or pool listings.

```yaml
title: Cryptomining Utility Process Execution (AN0741-A)
id: 46e310f0-6e47-4485-a380-701356531620
status: experimental
description: Detects command-line execution of cryptomining binaries like xmrig, cgminer, or minerd, or arguments specifying mining wallets and pools.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\xmrig.exe'
            - '\minerd.exe'
            - '\cgminer.exe'
            - '\ccminer.exe'
            - '\nicehash.exe'
        OriginalFileName:
            - 'xmrig.exe'
            - 'minerd.exe'
            - 'cgminer.exe'
            - 'ccminer.exe'
            - 'nicehash.exe'
    selection_cli:
        CommandLine|contains:
            - '--stratum'
            - '--pool'
            - '-o stratum+tcp'
            - '--donate-level'
    filter_installers:
        ParentImage|endswith:
            - '\msiexec.exe'
            - '\setup.exe'
    # Require BOTH miner tool execution or specific arguments (fixing OR logic flow)
    condition: selection_images and selection_cli and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Authorized distributed computing projects or sandboxed test mining configurations.
level: high
tags:
    - attack.impact
    - attack.t1496
    - analytic.an0741
    - detection.det0267
```

#### Rule 2 of 2: Outbound Network Connection to Cryptomining Stratum Pools
Detects outbound TCP/UDP network connections targeting default ports commonly used by cryptomining pools for the Stratum protocol, excluding common developer tools.

```yaml
title: Outbound Network Connection to Cryptomining Stratum Pools (AN0741-B)
id: d4fdaaea-a23e-46ee-9fb0-08101273c7b5
status: experimental
description: Detects outbound network traffic from endpoints targeting common cryptomining pool ports.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: network_connection
    product: windows
detection:
    selection_ports:
        DestinationPort:
            - 3333
            - 4444
            - 5555
            - 7777
            - 14444
    filter_browsers:
        Image|endswith:
            - '\chrome.exe'
            - '\firefox.exe'
            - '\msedge.exe'
    filter_legitimate:
        # Exclude local developer loopbacks and Jupyter notebook servers
        DestinationIp|cidr:
            - '127.0.0.0/8'
            - '10.0.0.0/8'
            - '192.168.0.0/16'
        Image|endswith:
            - '\jupyter.exe'
    condition: selection_ports and not (filter_browsers or filter_legitimate)
fields:
    - Image
    - DestinationIp
    - DestinationPort
    - User
falsepositives:
    - Legitimate corporate applications utilizing these ports or web pages running javascript miner scripts.
level: medium
tags:
    - attack.impact
    - attack.t1496
    - analytic.an0741
    - detection.det0267
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Mining Pools on Standard Ports (443)
  * The Issue: Mining pools configured to receive traffic over standard HTTPS (port 443) will bypass Rule 2 port checks.
  * The Fix: Enable SSL decryption at the network egress boundary and inspect payloads for Stratum protocol markers, or maintain an up-to-date threat feed of miner pool IP addresses.
* Problem 2: Single Connection Noise
  * The Issue: Temporary network scans or accidental game server connections can trigger Rule 2 on specific ports.
  * The Fix: Implement SIEM aggregation to trigger only when the same process registers more than 5 connections within 1 minute (`count(DestinationIp) by Image > 5 in 1m`).
"""
    with open(f_0741, 'w', encoding='utf-8') as f:
        f.write(content_0741)

    # ---------------------------------------------------------
    # AN0827-T1561.002-DET0297.md
    # ---------------------------------------------------------
    f_0827 = os.path.join(impact_dir, "AN0827-T1561.002-DET0297.md")
    content_0827 = """### 1. Technique Breakdown: T1561.002

* What it is: Disk Wipe: Disk Structure Wipe. Adversaries overwrite sensitive disk structures, such as the Master Boot Record (MBR) or partition tables, on target systems to disable the OS boot loader and render the endpoints unusable. They achieve this by opening raw handles to disk devices using physical drive paths (`\\.\PhysicalDrive0`) or volume namespaces.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) / Security Event ID 4688, and Sysmon Raw Access Read events (Event ID 9).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Process creations referencing raw paths and Sysmon Event ID 9 (raw disk access) capture physical device access directly.
  - NIDS (Suricata + Zeek): NO. Host-local disk writing.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 9 (raw_access_read)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Raw Physical Drive Access Command Line
Detects command-line usage referencing raw physical drives or raw volume paths, which is characteristic of wiper utilities or manual sector manipulation.

```yaml
title: Raw Physical Drive Access Command Line (AN0827-A)
id: 307d891d-8394-4327-90f9-0c082b0eb6a2
status: experimental
description: Detects command-line parameters containing physical drive paths or volume namespaces used for raw disk writing or wiping.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_paths:
        CommandLine|contains:
            - '\\.\PhysicalDrive'
            - '\\.\Volume{'
            - '\\.\CdRom'
    filter_sys:
        Image|endswith:
            - '\system32\defrag.exe'
            - '\system32\chkdsk.exe'
            - '\system32\wbem\WmiPrvSE.exe'
    filter_legitimate:
        Image|endswith:
            - '\diskpart.exe'
            - '\fdisk.exe'
        ParentImage|endswith:
            - '\msiexec.exe'
            - '\svchost.exe'
    condition: selection_paths and not (filter_sys or filter_legitimate)
fields:
    - Image
    - CommandLine
    - User
falsepositives:
    - Disk formatting utilities, diagnostic tasks run by administrators, or virtualization managers checking partition parameters.
level: high
tags:
    - attack.impact
    - attack.t1561.002
    - analytic.an0827
    - detection.det0297
```

#### Rule 2 of 2: Unauthorized Raw Disk Partition Access
Detects Sysmon Event ID 9 (RawAccessRead) showing raw disk read or access operations initiated by non-system, non-backup processes.

```yaml
title: Unauthorized Raw Disk Partition Access (AN0827-B)
id: 2376b39c-0981-4bed-bc5c-dea5a81adabc
status: experimental
description: Detects Sysmon Event ID 9 logs capturing raw access to the disk device by non-standard system processes.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: raw_access_read
    product: windows
detection:
    selection_raw:
        Device|contains:
            - '\PhysicalDrive'
            - '\Harddisk'
    filter_system:
        # Exclude standard Windows system utilities and virtualization agents
        Image|endswith:
            - '\system32\svchost.exe'
            - '\system32\csrss.exe'
            - '\system32\lsass.exe'
            - '\system32\defrag.exe'
            - '\system32\chkdsk.exe'
            - '\system32\WmiPrvSE.exe'
            - '\vmnat.exe'
            - '\vmtoolsd.exe'
    filter_legitimate:
        # Exclude known enterprise backup agents
        Image|endswith:
            - '\veeam.exe'
            - '\backup.exe'
            - '\acronis.exe'
    condition: selection_raw and not (filter_system or filter_legitimate)
fields:
    - Device
    - Image
    - User
falsepositives:
    - Authorized backup agents or antivirus endpoint agents scanning raw sectors.
level: high
tags:
    - attack.impact
    - attack.t1561.002
    - analytic.an0827
    - detection.det0297
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Backup Software Noise
  * The Issue: Commercial backup solutions perform high rates of raw disk reads legitimately, triggering excessive alerts under Rule 2.
  * The Fix: Baseline active backup client processes in the organization and append them to the `filter_legitimate` block.
* Problem 2: SIEM-Side Aggregation for Wipes
  * The Issue: Antivirus software occasionally checks raw sectors during scheduled full scans, causing false alerts.
  * The Fix: Apply a threshold rule in the SIEM to trigger only if raw disk partition access is recorded more than 3 times within 5 minutes (`count(Device) > 3 in 5m`).
"""
    with open(f_0827, 'w', encoding='utf-8') as f:
        f.write(content_0827)

    # ---------------------------------------------------------
    # AN0850-T1499.004-DET0304.md
    # ---------------------------------------------------------
    f_0850 = os.path.join(impact_dir, "AN0850-T1499.004-DET0304.md")
    content_0850 = """### 1. Technique Breakdown: T1499.004

* What it is: Endpoint Denial of Service: Application or System Exploitation. Adversaries exploit application or OS-level vulnerabilities (e.g. CVE-based exploits) to crash or restart system services, causing immediate service denial. This is frequently used to disable local security agents or disrupt server application availability (like Exchange or SQL databases).
* Log Source Requirements: Windows System Event Log (Event ID 7031 / 7034 / 7036 for SCM) and Sysmon Process Creation events (Event ID 1).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. SCM crash details and exploit process chains are captured.
  - NIDS (Suricata + Zeek): YES. If the exploit occurs over the network, network IDS can flag exploit packet patterns.
* Log Sources Covered:
  - Windows System Log Event ID 7031 (service_terminated_recovery)
  - Sysmon Event ID 1 (process_creation)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: SCM Event Log Service Crash
Detects Event ID 7031 logs indicating unexpected service restarts or recovery actions triggered by service crashes.

```yaml
title: SCM Event Log Service Crash (AN0850-A)
id: cfc94563-1de9-4172-8b75-12200e24147a
status: experimental
description: Detects Service Control Manager Event ID 7031 logs showing service crashes leading to configured recovery actions.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    service: system
detection:
    selection_scm:
        EventID: 7031
    selection_services:
        Description|contains:
            - 'Local Security Authority'
            - 'Windows Defender'
            - 'Sysmon'
            - 'Wazuh'
            - 'Exchange'
            - 'IISAdmin'
            - 'MSSQL'
    condition: selection_scm and selection_services
fields:
    - EventID
    - Description
    - Source
falsepositives:
    - Failing system updates, memory leaks in legacy applications, or hardware failure leading to application instability.
level: medium
tags:
    - attack.impact
    - attack.t1499.004
    - analytic.an0850
    - detection.det0304
```

#### Rule 2 of 2: Exploit Framework Induced Denial of Service Execution
Detects the process execution of known denial-of-service script frameworks or command arguments attempting to exploit specific service vulnerabilities.

```yaml
title: Exploit Framework Induced Denial of Service Execution (AN0850-B)
id: 65a5e5c3-7e09-4c9b-87d2-7966bf46cc74
status: experimental
description: Detects process creations of exploit scripts or utilities launched with parameters commonly associated with service crash exploits.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_args:
        CommandLine|contains:
            - 'exploit/windows/dos/'
            - 'exploit/linux/dos/'
            - 'bluekeep'
            - 'etherleak'
    # Tightened matching to prevent CVE-202 broad matches
    selection_cves:
        CommandLine|contains:
            - 'CVE-2021-31166'
            - 'CVE-2022-21907'
    filter_legitimate:
        ParentImage|endswith:
            - '\burp.exe'
            - '\metasploit.exe'
    condition: (selection_args or selection_cves) and not filter_legitimate
fields:
    - Image
    - CommandLine
    - User
falsepositives:
    - Penetration testers or vulnerability scanners conducting authorized denial-of-service validations during test windows.
level: high
tags:
    - attack.impact
    - attack.t1499.004
    - analytic.an0850
    - detection.det0304
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Instability vs. Targeted Exploitation
  * The Issue: Flaky services can crash under normal loads, triggering Rule 1.
  * The Fix: In the SIEM layer, correlate Rule 1 with a frequency threshold requiring at least 3 terminations in 5 minutes to confirm a crash loop (`count() by Description > 3 in 5m`).
* Problem 2: Metasploit Evasion
  * The Issue: Pen testers or attackers modifying the default exploit strings will bypass Rule 2.
  * The Fix: Rely on native system log analysis (Rule 1 SCM crashes) as the primary detection mechanism.
"""
    with open(f_0850, 'w', encoding='utf-8') as f:
        f.write(content_0850)

    # ---------------------------------------------------------
    # AN0882-T1561.001-DET0316.md
    # ---------------------------------------------------------
    f_0882 = os.path.join(impact_dir, "AN0882-T1561.001-DET0316.md")
    content_0882 = """### 1. Technique Breakdown: T1561.001

* What it is: Disk Wipe: Disk Content Wipe. Adversaries wipe the contents of files or entire disks on target endpoints, removing critical system files or user data to disrupt operations and destroy traces of activity. They achieve this using built-in deletion utilities (like cipher.exe) or specialized raw disk drivers that allow userland programs to bypass NTFS and write directly to disk sectors.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) / Security Event ID 4688, and Sysmon Registry Set events (Event ID 13).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon EID 1 captures wiping tools. Sysmon EID 13 and EID 6 capture driver registrations and installations.
  - NIDS (Suricata + Zeek): NO. Host-local disk operations.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 13 (registry_set)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Bulk Content Wiping Utilities Command Line
Detects command-line execution of native or third-party bulk wiping tools (e.g. cipher.exe, sdelete.exe) with parameters indicating secure deletion or drive clearing.

```yaml
title: Bulk Content Wiping Utilities Command Line (AN0882-A)
id: 0484ef7a-9143-4d89-b8cb-646f394c6ec6
status: experimental
description: Detects command-line parameters indicating bulk file wiping or secure data overwrite using cipher.exe or sdelete.exe.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_cipher:
        Image|endswith:
            - '\cipher.exe'
        CommandLine|contains:
            - ' /w:'
            - ' -w:'
    selection_sdelete:
        Image|endswith:
            - '\sdelete.exe'
            - '\sdelete64.exe'
        CommandLine|contains:
            - ' -p '
            - ' -z '
    filter_admin:
        User: 'NT AUTHORITY\SYSTEM'
    condition: (selection_cipher or selection_sdelete) and not filter_admin
fields:
    - Image
    - CommandLine
    - User
falsepositives:
    - System administrators securely cleaning disks before repurposing systems or disposing of hardware.
level: high
tags:
    - attack.impact
    - attack.t1561.001
    - analytic.an0882
    - detection.det0316
```

#### Rule 2 of 2: EldoS RawDisk Driver Registration
Detects registry modification or driver registration of the commercial EldoS RawDisk driver (`ElRawDsk`), which is frequently abused by wipers (such as Shamoon) to obtain raw write access to user filesystems.

```yaml
title: EldoS RawDisk Driver Registration (AN0882-B)
id: f995bc76-ec6e-45cf-b0ab-8b29445239cb
status: experimental
description: Detects the registration of the EldoS RawDisk driver (ElRawDsk) in the registry, which allows userland processes raw write access to disk sectors.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_registry:
        TargetObject|contains:
            - 'SYSTEM\CurrentControlSet\Services\ElRawDsk'
    filter_installer:
        ParentImage|endswith:
            - '\setup.exe'
            - '\msiexec.exe'
            - '\rundll32.exe'
        User: 'NT AUTHORITY\SYSTEM'
    condition: selection_registry and not filter_installer
fields:
    - TargetObject
    - Details
    - Image
    - User
falsepositives:
    - Legitimate disk recovery or partition-editing software that bundles the EldoS driver.
level: critical
tags:
    - attack.impact
    - attack.t1561.001
    - analytic.an0882
    - detection.det0316
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Wiping via Administrative Cleanups
  * The Issue: System administrators running `sdelete.exe` legitimately to free up disk space on a virtual machine will trigger Rule 1.
  * The Fix: Limit alerting to workstation networks or verify if the execution parent belongs to trusted deployment systems (like SCCM/Ansible).
* Problem 2: SIEM Logging Aggregations
  * The Issue: Antivirus software wiping isolated quarantined items can occasionally produce command-line events that resemble secure deletions.
  * The Fix: In the SIEM, filter out files executing secure deletions if their frequency is low (less than 2 events in 5 minutes).
"""
    with open(f_0882, 'w', encoding='utf-8') as f:
        f.write(content_0882)

    # ---------------------------------------------------------
    # AN0933-T1490-DET0329.md
    # ---------------------------------------------------------
    f_0933 = os.path.join(impact_dir, "AN0933-T1490-DET0329.md")
    content_0933 = """### 1. Technique Breakdown: T1490

* What it is: Inhibit System Recovery. Adversaries delete or remove built-in Windows recovery mechanisms—such as Volume Shadow Copies, backup catalogs, and automatic boot recovery options—to ensure the victim cannot easily restore their systems without paying a ransom. They execute these commands using native utilities or scripting APIs.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) / Security Event ID 4688, and PowerShell Script Block logging (Event ID 4104).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. All system command line invocations and scripting parameters are audited.
  - NIDS (Suricata + Zeek): NO. Host-local recovery controls.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 4104 (ps_script)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Backup Catalog and Shadow Copy Deletion
Detects command-line execution of native tools (vssadmin, wbadmin, bcdedit, wmic, diskshadow, REAgentC) attempting to delete shadow copies, wipe backup catalogs, or disable recovery modes.

```yaml
title: Backup Catalog and Shadow Copy Deletion (AN0933-A)
id: 4d1005bc-3498-4026-a096-bc10f297eb6c
status: experimental
description: Detects command-line execution of vssadmin, wbadmin, bcdedit, wmic, diskshadow, or REAgentC attempting to delete shadow copies or catalog files.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\vssadmin.exe'
            - '\wbadmin.exe'
            - '\bcdedit.exe'
            - '\wmic.exe'
            - '\diskshadow.exe'
            - '\reagentc.exe'
        OriginalFileName:
            - 'vssadmin.exe'
            - 'wbadmin.exe'
            - 'bcdedit.exe'
            - 'wmic.exe'
            - 'diskshadow.exe'
            - 'reagentc.exe'
    selection_args:
        CommandLine|contains:
            - 'delete shadows'
            - 'delete catalog'
            - 'delete systemstatebackup'
            - 'shadowcopy delete'
            - 'recoveryenabled no'
            - 'ignoreallfailures'
            - '/disable'
    filter_legitimate:
        ParentImage|endswith:
            - '\svchost.exe'
            - '\backup.exe'
            - '\veeam.exe'
        User: 'NT AUTHORITY\SYSTEM'
    condition: selection_images and selection_args and not filter_legitimate
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Standard automated backup scripts or disaster recovery routines running under system privileges.
level: critical
tags:
    - attack.impact
    - attack.t1490
    - analytic.an0933
    - detection.det0329
```

#### Rule 2 of 2: Recovery Environment Disabling via PowerShell
Detects PowerShell script block logs executing cmdlets or calling WMI classes to delete shadow copies or disable recovery.

```yaml
title: Recovery Environment Disabling via PowerShell (AN0933-B)
id: 2bf042a6-12e6-408c-bc82-6c2fc4de7999
status: experimental
description: Detects PowerShell script blocks containing commands to delete shadow copies or disable system restore mechanisms.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: ps_script
    product: windows
detection:
    selection_cmdlets:
        ScriptBlockText|contains:
            - 'Disable-ComputerRestore'
            - 'Win32_ShadowCopy'
            - 'delete shadows'
            - 'delete catalog'
    filter_admin:
        User: 'NT AUTHORITY\SYSTEM'
    condition: selection_cmdlets and not filter_admin
fields:
    - ScriptBlockText
    - User
falsepositives:
    - Administrative configuration scripts managing disk allocation space on enterprise workstations.
level: high
tags:
    - attack.impact
    - attack.t1490
    - analytic.an0933
    - detection.det0329
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Automated Cleanup Tasks
  * The Issue: Automated system management tools run tasks to purge historical shadows under SYSTEM context, triggering Rule 2.
  * The Fix: Check executing user context and filter out GPO scripts running as SYSTEM or trusted machine accounts.
* Problem 2: Fleet-Wide Backup Deletions
  * The Issue: Ransomware performs bulk shadow deletions across multiple endpoints simultaneously, creating high alert volume.
  * The Fix: In the SIEM, establish a threshold correlation to trigger alerts only if more than 2 endpoints delete shadow copies within a 5-minute window (`count(Computer) by Computer > 1 in 5m`).
"""
    with open(f_0933, 'w', encoding='utf-8') as f:
        f.write(content_0933)

    # ---------------------------------------------------------
    # AN0969-T1498.001-DET0343.md
    # ---------------------------------------------------------
    f_0969 = os.path.join(impact_dir, "AN0969-T1498.001-DET0343.md")
    content_0969 = """### 1. Technique Breakdown: T1498.001

* What it is: Network Denial of Service: Direct Network Flood. Adversaries generate a high volume of network traffic directly targeting a victim to saturate network interfaces, exhaust state tables, or crash endpoints. They achieve this using dedicated flooding tools (such as LOIC or HOIC) or custom scripts executing rapid connection loops.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) / Security Event ID 4688, and Sysmon Network Connection events (Event ID 3).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Flood binaries and process executions are tracked. Outbound connection rates are audited via Sysmon EID 3.
  - NIDS (Suricata + Zeek): YES. Network sensors are highly effective at detecting flood volumes at the network layer.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 3 (network_connection)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Network Flooding Tools Execution
Detects the execution of known denial of service or network flooding utilities.

```yaml
title: Network Flooding Tools Execution (AN0969-A)
id: 6f43e5a3-8ddc-4f44-a9b5-744309d2073c
status: experimental
description: Detects command-line execution of known network flooding utilities (e.g. LOIC, HOIC, hping3).
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\loic.exe'
            - '\hoic.exe'
            - '\hping3.exe'
            - '\nping.exe'
            - '\\ufonet.exe'
        OriginalFileName:
            - 'loic.exe'
            - 'hoic.exe'
            - 'hping3.exe'
            - 'nping.exe'
            - 'ufonet.exe'
    selection_cli:
        CommandLine|contains:
            - 'loic'
            - 'hoic'
            - 'hping'
            - 'nping'
            - 'synflood'
    # Require BOTH image and CLI flags (fixing OR logic flow)
    condition: selection_images and selection_cli
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Security teams conducting authorized load testing or network stress tests.
level: high
tags:
    - attack.impact
    - attack.t1498.001
    - analytic.an0969
    - detection.det0343
```

#### Rule 2 of 2: Scripting Process Generating Anomalous Outbound Network Connection Burst
Detects non-standard scripting hosts or tools opening rapid outbound network connections. This rule is designed for SIEM-side correlation.

```yaml
title: Scripting Process Outbound Connection Burst (AN0969-B)
id: cb44046c-c24e-4773-9f2e-d8eb145f9b1a
status: experimental
description: Detects non-standard scripting interpreters (Python, PowerShell, cmd) initiating outbound connections. This rule is designed to be paired with SIEM-side aggregation to trigger only when connection rate thresholds are exceeded (e.g. count > 500 in 10 seconds).
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: network_connection
    product: windows
detection:
    selection_processes:
        Image|endswith:
            - '\python.exe'
            - '\powershell.exe'
            - '\pwsh.exe'
            - '\cmd.exe'
            - '\wscript.exe'
            - '\cscript.exe'
    filter_internal:
        # Filter connections to localhost or internal network endpoints
        DestinationIp|startswith:
            - '127.'
            - '10.'
            - '192.168.'
            - '172.16.'
            - '::1'
    filter_admin:
        ParentImage|endswith:
            - '\explorer.exe'
            - '\mmc.exe'
    condition: selection_processes and not (filter_internal or filter_admin)
fields:
    - Image
    - DestinationIp
    - DestinationPort
    - User
falsepositives:
    - Legitimate administrative scripts retrieving public APIs or running cloud updates.
level: medium
tags:
    - attack.impact
    - attack.t1498.001
    - analytic.an0969
    - detection.det0343
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: SIEM-Side Aggregation Requirement
  * The Issue: Rule 2 matches single outbound connection events. Without aggregation, any Python API check to a public address will trigger a false alert.
  * The Fix: Configure a SIEM aggregation rule requiring more than 500 connection events from a single endpoint process within a 10-second window to alert on a network flood: `count(DestinationIp) by Image > 500 in 10s`.
* Problem 2: Web Scrapers and Cloud Integration Scripts
  * The Issue: Legitimate data collectors or cloud sync engines running inside Python will trigger alerts if they exceed the connection threshold.
  * The Fix: Baseline normal outbound connection destinations for corporate servers and add their destination subnets to the `filter_internal` or custom whitelists.
"""
    with open(f_0969, 'w', encoding='utf-8') as f:
        f.write(content_0969)

    print("Impact rules successfully refactored and saved.")

if __name__ == '__main__':
    fix_rules()
