import os

execution_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\execution"
output_file = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\sprint_execution_batch1_combined.txt"

files = [
    "AN0942-T1059.010-DET0332.md",
    "AN0962-T1204.004-DET0340.md",
    "AN1031-T1047-DET0364.md",
    "AN1185-T1569.002-DET0421.md",
    "AN1252-T1059.001-DET0455.md",
    "AN1314-T1204-DET0478.md",
    "AN1357-T1559-DET0493.md",
    "AN1393-T1559.002-DET0504.md",
    "AN1428-T1059-DET0516.md",
    "AN1465-T1106-DET0529.md"
]

with open(output_file, 'w', encoding='utf-8') as outfile:
    for idx, fname in enumerate(files, 1):
        path = os.path.join(execution_dir, fname)
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as infile:
                content = infile.read()
            outfile.write(f"=== RULE {idx}: {fname} ===\n\n")
            outfile.write(content)
            outfile.write("\n\n" + "="*50 + "\n\n")

print(f"Combined execution rules into {output_file}")
