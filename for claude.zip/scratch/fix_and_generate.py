import uuid
import os

def generate_fixed_rules():
    # 1. AN0543
    an0543_content = f"""### 1. Technique Breakdown: T1556.006
* What it is: Modify Authentication Process: Multi-Factor Authentication. Adversaries modify MFA configurations or policies to bypass second-factor challenges. This includes modifying registry settings that govern Windows Hello PIN usage, disabling credential providers, or using administrative commands to clear or modify user MFA requirements in Active Directory / Azure AD.
* Log Source Requirements: Sysmon Registry Set events (Event ID 13) and PowerShell Script Block logging (Event ID 4104).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon logs registry modifications and PowerShell script block executions.
  - NIDS (Suricata + Zeek): NO. Host-local system changes and cloud provider administration APIs.
* Log Sources Covered:
  - Sysmon Event ID 13 (registry_set)
  - Sysmon Event ID 4104 (ps_script)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: MFA Registry Configuration Tampering
Detects registry modifications attempting to weaken or disable Windows Hello PIN or credential providers that enforce multi-factor authentication.

```yaml
title: MFA Registry Configuration Tampering (AN0543-A)
id: {uuid.uuid4()}
status: experimental
description: Detects registry modifications attempting to disable Windows Hello PIN or credential providers that enforce MFA.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_hello:
        TargetObject|contains:
            - '\\Microsoft\\Windows\\System\\PINLogin'
            - '\\Microsoft\\Windows\\System\\AllowDomainPINLogon'
        Details: 'DWORD (0x00000000)'
    selection_cred_providers:
        TargetObject|contains:
            - '\\Microsoft\\Windows\\CurrentVersion\\Authentication\\Credential Providers\\'
        TargetObject|endswith:
            - '\\Disabled'
        Details: 'DWORD (0x00000001)'
    condition: selection_hello or selection_cred_providers
fields:
    - TargetObject
    - Details
    - User
falsepositives:
    - Administrative provisioning or decommissioning of Windows Hello Hello for Business.
level: medium
tags:
    - attack.defense-impairment
    - attack.t1556.006
    - analytic.an0543
    - detection.det0190
```

#### Rule 2 of 2: MFA Administrative Tampering via PowerShell
Detects PowerShell commands attempting to clear or modify user MFA requirements.

```yaml
title: MFA Administrative Tampering via PowerShell (AN0543-B)
id: {uuid.uuid4()}
status: experimental
description: Detects PowerShell script blocks clearing or weakening user MFA configurations in AD or Azure AD.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    category: ps_script
detection:
    selection_cmdlets:
        ScriptBlockText|contains:
            - 'Set-MsolUser'
            - 'Update-MgUser'
            - 'Set-AzureADUser'
    selection_mfa_params:
        ScriptBlockText|contains:
            - 'StrongAuthenticationRequirements'
            - 'StrongAuthenticationMethods'
            - 'StrongAuthenticationPhoneAppDetails'
    selection_disable_keywords:
        ScriptBlockText|contains:
            - 'StrongAuthenticationRequirements = $null'
            - 'StrongAuthenticationRequirements = @()'
            - 'StrongAuthenticationRequirements.Clear()'
            - 'StrongAuthenticationRequirements = clear'
            - 'StrongAuthenticationRequirements = Remove'
            - 'StrongAuthenticationMethods = $null'
            - 'StrongAuthenticationMethods = @()'
            - 'StrongAuthenticationMethods.Clear()'
    condition: selection_cmdlets and selection_mfa_params and selection_disable_keywords
fields:
    - ScriptBlockText
    - User
falsepositives:
    - Legitimate administration scripts resetting user MFA methods upon request.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.006
    - analytic.an0543
    - detection.det0190
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Administrative Bulk Resets
  * The Issue: Large organizations occasionally run scripts to reset MFA methods during support operations, causing false positives.
  * The Fix: Exclude script execution paths or administrative accounts executing the resets using a dedicated `filter_accounts` block in the PowerShell rule.
* Problem 2: Registry Changes via Group Policy Objects
  * The Issue: Benign GPO updates will trigger the registry rule.
  * The Fix: Filter out system processes (`services.exe`, `svchost.exe`) executing the registry writes, leaving only interactive command-lines or unknown processes.
"""

    # 2. AN0757
    an0757_content = f"""### 1. Technique Breakdown: T1556.001
* What it is: Modify Authentication Process: Domain Controller Authentication. Adversaries patch domain controller authentication processes (specifically LSASS) to inject a "Skeleton Key," allowing them to authenticate as any user using a master password while legitimate authentication processes continue working normally.
* Log Source Requirements: Sysmon Process Access logs (Event ID 10), Sysmon Image Load logs (Event ID 7), and Sysmon Registry Set logs (Event ID 13).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon provides visibility into LSASS memory access, image loads, and registry changes on Domain Controllers.
  - NIDS (Suricata + Zeek): NO. Host-local system manipulation.
* Log Sources Covered:
  - Sysmon Event ID 10 (process_access)
  - Sysmon Event ID 7 (image_load)
  - Sysmon Event ID 13 (registry_set)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 3: LSASS Process Access on Domain Controller
Detects suspicious process access to `lsass.exe` with high-privilege access masks on Domain Controllers.

```yaml
title: LSASS Process Access on Domain Controller (AN0757-A)
id: {uuid.uuid4()}
status: experimental
description: Detects process access to lsass.exe on Domain Controllers, indicating potential memory dumping or patching.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_access
    product: windows
detection:
    selection_target:
        TargetImage|endswith: '\\lsass.exe'
    selection_access:
        # Requesting high access rights including VirtualMemoryWrite or VirtualMemoryOperation
        GrantedAccess:
            - '0x1F3FFF'
            - '0x1F0FFF'
            - '0x1010'
            - '0x1410'
            - '0x1438'
    filter_legitimate:
        SourceImage|endswith:
            - '\\services.exe'
            - '\\wininit.exe'
            - '\\csrss.exe'
            - '\\MsMpEng.exe'
            - '\\winlogon.exe'
    condition: selection_target and selection_access and not filter_legitimate
fields:
    - SourceImage
    - TargetImage
    - GrantedAccess
    - User
falsepositives:
    - Normal system initialization or troubleshooting by domain administrators using authorized diagnostic tools.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.001
    - analytic.an0757
    - detection.det0271
```

#### Rule 2 of 3: Unsigned or Non-Standard Module Load in LSASS
Detects loading of DLLs from non-system directories or unsigned modules into the LSASS process space.

```yaml
title: LSASS Suspicious Image Load (AN0757-B)
id: {uuid.uuid4()}
status: experimental
description: Detects non-standard DLLs loaded into the LSASS process space on Domain Controllers.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: image_load
    product: windows
detection:
    selection_target:
        Image|endswith: '\\lsass.exe'
    selection_load:
        ImageLoaded: '*'
    filter_legitimate_paths:
        ImageLoaded|startswith:
            - 'C:\\Windows\\System32\\'
            - 'C:\\Windows\\SysWOW64\\'
            - 'C:\\Program Files\\'
            - 'C:\\Program Files (x86)\\'
    condition: selection_target and selection_load and not filter_legitimate_paths
fields:
    - Image
    - ImageLoaded
    - User
falsepositives:
    - Custom multi-factor authentication provider DLLs or smart-card reader DLLs registered in System32.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.001
    - analytic.an0757
    - detection.det0271
```

#### Rule 3 of 3: Registry Tampering of LSA Security Packages
Detects modifications to LSA Security Packages to load malicious Security Support Providers (SSPs).

```yaml
title: LSA Security Packages Registry Modification (AN0757-C)
id: {uuid.uuid4()}
status: experimental
description: Detects registry modifications to the Security Packages list to register custom SSPs.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_packages:
        TargetObject|contains:
            - 'SYSTEM\\CurrentControlSet\\Control\\Lsa\\Security Packages'
            - 'SYSTEM\\CurrentControlSet\\Control\\Lsa\\Authentication Packages'
    filter_clean_baselines:
        # Match only exact standard baseline lists
        Details:
            - 'kerberos msv1_0 schannel wdigest tspkg pku2u credssp'
            - 'kerberos msv1_0 schannel wdigest tspkg pku2u'
            - 'kerberos msv1_0 schannel wdigest tspkg credssp'
    condition: selection_packages and not filter_clean_baselines
fields:
    - TargetObject
    - Details
    - User
falsepositives:
    - Installation of approved enterprise multi-factor authentication modules.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.001
    - analytic.an0757
    - detection.det0271
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Third-Party Authentication DLLs
  * The Issue: Domain Controllers loading valid third-party password filters or multi-factor authentication DLLs will trigger Rule 2.
  * The Fix: Baseline all approved DLL hashes or file names loaded by `lsass.exe` on DCs and add them to the `filter_legitimate_paths` whitelist.
* Problem 2: Administrative Security Package Enhancements
  * The Issue: Authorized additions of new Security Support Providers (SSPs) will trigger Rule 3.
  * The Fix: Validate SSP registry modifications against change management records.
"""

    # 3. AN0814
    an0814_content = f"""### 1. Technique Breakdown: T1556.007
* What it is: Modify Authentication Process: Hybrid Identity. Adversaries tamper with hybrid identity services (such as Azure AD Connect or AD FS) to bypass authentication mechanisms or steal credentials. This includes injecting malicious DLLs into hybrid identity sync agent directories or modifying hybrid configuration registries.
* Log Source Requirements: Sysmon Registry Set events (Event ID 13), Sysmon Image Load events (Event ID 7), and Sysmon File Creation events (Event ID 11).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon provides full coverage of file writes, registry modifications, and DLL loads in hybrid agent processes.
  - NIDS (Suricata + Zeek): NO. Host-local system file/registry modifications.
* Log Sources Covered:
  - Sysmon Event ID 13 (registry_set)
  - Sysmon Event ID 11 (file_event)
  - Sysmon Event ID 7 (image_load)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Hybrid Identity Registry Configuration Tampering
Detects registry modifications to Azure AD Connect or Active Directory Federation Services (AD FS) settings.

```yaml
title: Hybrid Identity Service Registry Tampering (AN0814-A)
id: {uuid.uuid4()}
status: experimental
description: Detects registry modifications targeting Azure AD Connect or AD FS service configurations.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_registry:
        TargetObject|contains:
            - 'SOFTWARE\\Microsoft\\Microsoft Azure AD Connection Tool\\'
            - 'SOFTWARE\\Microsoft\\ADFS\\'
            - 'SYSTEM\\CurrentControlSet\\Services\\AdFederationSvc\\'
    filter_legitimate:
        Image|endswith:
            - '\\AzureADConnect.exe'
            - '\\miiserver.exe'
    condition: selection_registry and not filter_legitimate
fields:
    - TargetObject
    - Details
    - User
falsepositives:
    - Standard administrator updates or reconfiguration of Azure AD Connect Sync Service.
level: medium
tags:
    - attack.defense-impairment
    - attack.t1556.007
    - analytic.an0814
    - detection.det0293
```

#### Rule 2 of 2: Hybrid Identity Agent DLL Tampering
Detects suspicious file writes or DLL loading within the installation directories of Azure AD Connect agent services.

```yaml
title: Hybrid Identity Agent DLL Modification (AN0814-B)
id: {uuid.uuid4()}
status: experimental
description: Detects file creation of DLLs or suspicious image loads within Azure AD Connect Sync folders.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_paths:
        TargetFilename|contains:
            - 'C:\\Program Files\\Microsoft Azure AD Connection Tool\\'
            - 'C:\\Program Files\\Microsoft Azure AD Connect Authentication Agent\\'
    selection_filetypes:
        TargetFilename|endswith:
            - '.dll'
            - '.exe'
    filter_installers:
        Image|endswith:
            - '\\trustedinstaller.exe'
            - '\\msiexec.exe'
            - '\\tiworker.exe'
            - '\\AzureADConnect.exe'
            - '\\AzureADConnectUpdater.exe'
    condition: selection_paths and selection_filetypes and not filter_installers
fields:
    - TargetFilename
    - User
falsepositives:
    - Authorized software updates to Azure AD Connect or authentication agent versions.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.007
    - analytic.an0814
    - detection.det0293
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Automated Agent Updates
  * The Issue: The Azure AD Connect agent has an auto-update feature that frequently writes and registers new binaries, causing false positives in Rule 2.
  * The Fix: Exclude the Microsoft-signed auto-updater process (e.g. `AzureADConnectUpdater.exe`) as a valid parent process or installer tool using `filter_installers`.
* Problem 2: Legitimate AD FS Customizations
  * The Issue: AD FS administrators modifying theme settings or MFA provider mappings may update specific registry keys, triggering Rule 1.
  * The Fix: Baseline administrative accounts used to configure ADFS and exclude them if they map to official change windows.
"""

    # 4. AN1303
    an1303_content = f"""### 1. Technique Breakdown: T1556.002
* What it is: Modify Authentication Process: Password Filter DLL. Password filters are DLLs loaded by LSASS during boot or password changes. Adversaries register custom password filter DLLs to harvest plain-text credentials as users change their passwords.
* Log Source Requirements: Sysmon Registry Set events (Event ID 13) and Sysmon File Creation events (Event ID 11).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon provides full coverage of LSASS Notification Package registry modifications and DLL files written to system directories.
  - NIDS (Suricata + Zeek): NO. Host-local system manipulation.
* Log Sources Covered:
  - Sysmon Event ID 13 (registry_set)
  - Sysmon Event ID 11 (file_event)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Password Filter Registry Registration
Detects registry modifications adding a Notification Package DLL in Lsa configurations.

```yaml
title: LSA Password Filter DLL Registration (AN1303-A)
id: {uuid.uuid4()}
status: experimental
description: Detects registry modifications to the Notification Packages key used to load password filters in LSASS.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_lsa:
        TargetObject|endswith: 'SYSTEM\\CurrentControlSet\\Control\\Lsa\\Notification Packages'
    filter_clean_baselines:
        # Match only exact standard baseline lists
        Details:
            - 'scecli rassfm kdcsvc'
            - 'scecli rassfm'
            - 'scecli'
    condition: selection_lsa and not filter_clean_baselines
fields:
    - TargetObject
    - Details
    - User
falsepositives:
    - Installation of legitimate enterprise password enforcement agents (e.g., AD self-service reset tools).
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.002
    - analytic.an1303
    - detection.det0472
```

#### Rule 2 of 2: Password Filter File Creation
Detects the write of `.dll` files in system folders, which is typical before LSA registration.

```yaml
title: LSA Password Filter DLL File Write (AN1303-B)
id: {uuid.uuid4()}
status: experimental
description: Detects file creation of DLLs inside System32, filtering out trusted installers.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_paths:
        TargetFilename|contains:
            - 'C:\\Windows\\System32\\'
            - 'C:\\Windows\\SysWOW64\\'
    selection_dll:
        TargetFilename|endswith: '.dll'
    filter_trusted_installers:
        # Exclude trusted installer or system components
        Image|endswith:
            - '\\trustedinstaller.exe'
            - '\\msiexec.exe'
            - '\\tiworker.exe'
    condition: selection_paths and selection_dll and not filter_trusted_installers
fields:
    - TargetFilename
    - Image
    - User
falsepositives:
    - Windows updates or official software updates placing system DLLs.
level: medium
tags:
    - attack.defense-impairment
    - attack.t1556.002
    - analytic.an1303
    - detection.det0472
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Software Deployment and Updates
  * The Issue: Domain controllers deploying legitimate security tool updates (like password managers or MFA filters) will trigger Rule 1.
  * The Fix: Exclude specific certified filter names in the `filter_clean_baselines` section.
* Problem 2: System File Verification Noise
  * The Issue: Normal patch management will write DLL files to System32 and trigger Rule 2.
  * The Fix: Always require `filter_trusted_installers` to exclude system patching processes (e.g. `trustedinstaller.exe`, `tiworker.exe`).
"""

    # 5. AN1598
    an1598_content = f"""### 1. Technique Breakdown: T1556.008
* What it is: Modify Authentication Process: Network Provider DLL. Adversaries register malicious Network Provider DLLs in the registry (e.g., NPFS/RDP providers) to harvest plain-text credentials during user logons. When a user logs in, MPR (Multiple Provider Router) queries all registered network providers, loading their corresponding DLLs and passing the credentials to them.
* Log Source Requirements: Sysmon Registry Set events (Event ID 13) and Sysmon File Creation events (Event ID 11).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon tracks registry path setting and order changes for Network Providers and file events in System32.
  - NIDS (Suricata + Zeek): NO. Host-local configuration changes.
* Log Sources Covered:
  - Sysmon Event ID 13 (registry_set)
  - Sysmon Event ID 11 (file_event)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Network Provider Registry Tampering
Detects registry modifications adding or changing Network Provider ordering or DLL paths.

```yaml
title: Network Provider DLL Registry Modification (AN1598-A)
id: {uuid.uuid4()}
status: experimental
description: Detects registry modifications to the ProviderOrder or ProviderPath keys under NetworkProvider services.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_provider_path:
        TargetObject|contains:
            - 'System\\CurrentControlSet\\Services\\'
        TargetObject|endswith:
            - '\\NetworkProvider\\ProviderPath'
    selection_provider_order:
        TargetObject|endswith:
            - 'System\\CurrentControlSet\\Control\\NetworkProvider\\Order\\ProviderOrder'
    filter_standard_order:
        TargetObject|endswith: 'System\\CurrentControlSet\\Control\\NetworkProvider\\Order\\ProviderOrder'
        Details:
            - 'LanmanWorkstation,RDPNP,webclient'
            - 'LanmanWorkstation,RDPNP'
    filter_standard_paths:
        TargetObject|endswith: 'NetworkProvider\\ProviderPath'
        Details:
            - 'C:\\Windows\\System32\\ntlanman.dll'
            - 'C:\\Windows\\System32\\rdpnp.dll'
            - 'C:\\Windows\\System32\\davclnt.dll'
    condition: (selection_provider_path and not filter_standard_paths) or (selection_provider_order and not filter_standard_order)
fields:
    - TargetObject
    - Details
    - User
falsepositives:
    - Installation of legitimate network providers (e.g. third-party VPN clients, cloud storage mounts, or virtualization tools like VMware/VirtualBox).
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.008
    - analytic.an1598
    - detection.det0580
```

#### Rule 2 of 2: Network Provider DLL File Write
Detects the write of `.dll` files in system directories by unauthorized processes, which is required prior to DLL registration.

```yaml
title: Network Provider DLL File Creation (AN1598-B)
id: {uuid.uuid4()}
status: experimental
description: Detects file creation of DLLs in System32 by non-installer processes.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_paths:
        TargetFilename|contains:
            - 'C:\\Windows\\System32\\'
            - 'C:\\Windows\\SysWOW64\\'
    selection_dll:
        TargetFilename|endswith: '.dll'
    filter_installers:
        Image|endswith:
            - '\\trustedinstaller.exe'
            - '\\msiexec.exe'
            - '\\tiworker.exe'
    condition: selection_paths and selection_dll and not filter_installers
fields:
    - TargetFilename
    - Image
    - User
falsepositives:
    - Legitimate administrators updating network mounts or client software.
level: medium
tags:
    - attack.defense-impairment
    - attack.t1556.008
    - analytic.an1598
    - detection.det0580
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: VPN and Virtualization Software Installs
  * The Issue: Custom network adapters (like Cisco AnyConnect, VMware, or VirtualBox) register their own Network Providers during install, causing false positive alerts.
  * The Fix: Baseline these tools and whitelist their specific DLL filenames or paths in the registry filter block (`filter_standard_paths`).
* Problem 2: Registry Modifying Tools
  * The Issue: Third-party utility scripts modifying network configurations will trigger Rule 1.
  * The Fix: Ensure the user context and parent process are audited.
"""

    # 6. AN1621
    an1621_content = f"""### 1. Technique Breakdown: T1556.005
* What it is: Modify Authentication Process: Reversible Encryption. Adversaries enable the "Store password using reversible encryption" setting (e.g. `UF_ENCRYPTED_TEXT_PASSWORD_ALLOWED` in `userAccountControl`) for user accounts in Active Directory. This allows passwords to be stored as weakly encrypted ciphertexts, which can easily be decrypted to recover the user's plaintext password.
* Log Source Requirements: Windows Security Event logs (Event ID 4738 - User Account Changed, or Event ID 5136 - Directory Service Object Modified).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): NO. These are Active Directory changes audited via Windows Security Event Logs.
  - NIDS (Suricata + Zeek): NO. Encrypted AD LDAP or RPC traffic.
* Log Sources Covered:
  - Windows Security Event ID 4738 (service: security)
  - Windows Security Event ID 5136 (service: security)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Reversible Encryption Enabled via User Account Changes
Detects Windows Security Event ID 4738 showing that reversible password encryption was enabled on a user account.

```yaml
title: Reversible Encryption Enabled on User Account (AN1621-A)
id: {uuid.uuid4()}
status: experimental
description: Detects Windows Security Event ID 4738 indicating the "Store password using reversible encryption" option was enabled on an account.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    service: security
detection:
    selection_event:
        EventID: 4738
    selection_uac_flags:
        # Check standard combined UserAccountControl values that have the reversible encryption bit (128 / 0x80) enabled
        UserAccountControl:
            - '640'
            - '672'
            - '66176'
            - '66208'
            - '2176'
            - '4224'
            - '8320'
            - '0x280'
            - '0x2A0'
            - '0x10280'
            - '0x102A0'
            - '0x880'
            - '0x1080'
            - '0x2080'
    condition: selection_event and selection_uac_flags
fields:
    - TargetUserName
    - SubjectUserName
    - UserAccountControl
    - SubjectDomainName
falsepositives:
    - Administrative configuration for legacy protocols (like IIS Digest Authentication) that require reversible encryption.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.005
    - analytic.an1621
    - detection.det0589
```

#### Rule 2 of 2: Reversible Encryption Enabled via Directory Services Modification
Detects Active Directory directory service modification logs (Event ID 5136) indicating a change in `userAccountControl` to store passwords reversibly.

```yaml
title: Reversible Encryption Enabled via Active Directory Attribute modification (AN1621-B)
id: {uuid.uuid4()}
status: experimental
description: Detects Active Directory attribute modification (Event ID 5136) where userAccountControl has reversible encryption enabled.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    service: security
detection:
    selection_event:
        EventID: 5136
    selection_attribute:
        AttributeLDAPDisplayName: 'userAccountControl'
    selection_uac_flags:
        # Check standard combined UserAccountControl values that have the reversible encryption bit (128 / 0x80) enabled
        AttributeValue:
            - '640'
            - '672'
            - '66176'
            - '66208'
            - '2176'
            - '4224'
            - '8320'
            - '0x280'
            - '0x2A0'
            - '0x10280'
            - '0x102A0'
            - '0x880'
            - '0x1080'
            - '0x2080'
    condition: selection_event and selection_attribute and selection_uac_flags
fields:
    - ObjectDN
    - AttributeLDAPDisplayName
    - AttributeValue
    - SubjectUserName
falsepositives:
    - Approved change management actions configuring legacy accounts.
level: high
tags:
    - attack.defense-impairment
    - attack.t1556.005
    - analytic.an1621
    - detection.det0589
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Legacy Application Service Accounts
  * The Issue: Some legacy enterprise applications (e.g. older versions of SAP or custom database connectors) require reversible encryption on their service accounts.
  * The Fix: Exclude specific legacy user account naming patterns (e.g. `svc-legacy-*`) from the alert logic.
* Problem 2: Mass Provisioning Scripts
  * The Issue: Automated user creation scripts setting user properties in bulk may trigger false positives if the template default is modified.
  * The Fix: Verify the source IP and executing administrative user context.
"""

    # 7. AN1259
    an1259_content = f"""### 1. Technique Breakdown: T1484.002
* What it is: Domain or Tenant Policy Modification: Trust Modification. Adversaries modify Active Directory domain trust configurations to add new domain trusts or alter existing federations. This is often used for lateral movement or persistence, enabling trust from an attacker-controlled external domain.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and Windows Security Event logs (Event ID 4662 - Active Directory Object Operation, or Event ID 5136 - Directory Service Object Modified).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Process logs capture the use of utility binaries (netdom, nltest, powershell) to query or modify trust.
  - NIDS (Suricata + Zeek): NO. Mapped protocol actions are local host operations.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Windows Security Event ID 4662 (service: security)
  - Windows Security Event ID 5136 (service: security)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: CLI Domain Trust Modification Command
Detects process execution of utilities like `netdom.exe` or `nltest.exe` trying to configure or inspect trusts, or PowerShell Active Directory trust cmdlets.

```yaml
title: CLI Domain Trust Modification Command (AN1259-A)
id: {uuid.uuid4()}
status: experimental
description: Detects process executions attempting to modify or query Active Directory domain trust relationships.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_netdom:
        Image|endswith: '\\netdom.exe'
    selection_netdom_orig:
        OriginalFileName: 'netdom.exe'
    selection_nltest:
        Image|endswith: '\\nltest.exe'
    selection_nltest_orig:
        OriginalFileName: 'nltest.exe'
    selection_args:
        CommandLine|contains:
            - 'trust'
            - '/domain_trusts'
            - '/all_trusts'
    selection_powershell:
        CommandLine|contains:
            - 'Get-ADTrust'
            - 'New-ADTrust'
            - 'Set-ADTrust'
            - 'Remove-ADTrust'
    condition: ((selection_netdom or selection_netdom_orig or selection_nltest or selection_nltest_orig) and selection_args) or selection_powershell
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Active Directory administrators conducting routine domain trust validations or additions during enterprise mergers.
level: high
tags:
    - attack.defense-impairment
    - attack.t1484.002
    - analytic.an1259
    - detection.det0458
```

#### Rule 2 of 2: Active Directory TrustedDomain Object Modification
Detects Active Directory directory service operation logs (Event ID 4662 or 5136) targeting objects of the `trustedDomain` schema class.

```yaml
title: Active Directory Trust Object Modification (AN1259-B)
id: {uuid.uuid4()}
status: experimental
description: Detects modifications to Active Directory trustedDomain objects, which represent domain trust relationships.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    service: security
detection:
    selection_4662:
        EventID: 4662
        ObjectType|contains: '19195a5b-6da0-11d0-afd3-00c04fd930c9'
        ObjectDN|contains: 'CN=System'
    selection_5136:
        EventID: 5136
        ObjectClass|contains: 'trustedDomain'
        ObjectDN|contains: 'CN=System'
    condition: selection_4662 or selection_5136
fields:
    - EventID
    - ObjectDN
    - SubjectUserName
    - ObjectType
falsepositives:
    - Official domain consolidation or active directory trusts established by administrators.
level: high
tags:
    - attack.defense-impairment
    - attack.t1484.002
    - analytic.an1259
    - detection.det0458
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Administrative Trust Inspections
  * The Issue: Scripted health checks executing `nltest /domain_trusts` regularly to monitor trusts will generate false positive alerts.
  * The Fix: Whitelist the specific diagnostic service account running the monitoring scripts in `filter_accounts`.
* Problem 2: Object Access Auditing Noise
  * The Issue: Incomplete AD auditing configuration might prevent Event ID 4662 from capturing modifications.
  * The Fix: Ensure the SACL (System Access Control List) on the `CN=System` container in Active Directory is configured to audit write actions on `trustedDomain` objects.
"""

    contents_map = {
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN0543-T1556.006-DET0190.md": an0543_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN0757-T1556.001-DET0271.md": an0757_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN0814-T1556.007-DET0293.md": an0814_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN1303-T1556.002-DET0472.md": an1303_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN1598-T1556.008-DET0580.md": an1598_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN1621-T1556.005-DET0589.md": an1621_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment\AN1259-T1484.002-DET0458.md": an1259_content
    }
    
    for filepath, content in contents_map.items():
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content.strip() + "\n")
        print(f"Rewritten {filepath} with escapes and random UUIDs.")

if __name__ == '__main__':
    generate_fixed_rules()
