import pandas as pd
import openpyxl
import json

file_path = 'important_files/detection_coverage_matrix_final.xlsx'
wb = openpyxl.load_workbook(file_path)
ws = wb.active

headers = {cell.value: idx for idx, cell in enumerate(ws[2])}
name_col = headers.get('Name / Category')
status_col = headers.get('Coverage Status')
details_col = headers.get('Coverage Details')
gap_type_col = headers.get('Gap Type')
can_build_col = headers.get('Can we build it?')
tooling_col = headers.get('Extra Tooling / Log Source Needed')

for row in ws.iter_rows(min_row=3):
    if row[name_col].value is None:
        continue
    
    name = str(row[name_col].value)
    
    if name == 'Live response & remote remediation':
        row[status_col].value = 'Covered – SOAR-dependent'
        row[gap_type_col].value = 'Orchestration Gap (SOAR playbook needed)'
        row[details_col].value = "A SIEM is a passive log analytics tool; it cannot perform active 'live response' or 'remote remediation' on endpoints (like killing processes or isolating machines). This capability physically requires an EDR agent. Assuming a SOAR platform is deployed, the SIEM detects/correlates the condition, and a SOAR playbook executes live response actions via EDR API. (Conditional on integration being built and tested)."
        row[can_build_col].value = 'Yes, via SOAR playbook calling EDR API.'
        row[tooling_col].value = 'SOAR playbook: live-response via EDR API'
        
    if name == 'MFA & conditional access enforcement':
        details = str(row[details_col].value)
        row[details_col].value = details.replace('SOAR playbook + tool', 'SOAR playbook + IAM/IdP (e.g., Entra ID/Okta) API')

wb.save(file_path)

# Also update CSV
df = pd.read_excel(file_path, skiprows=1)
df.to_csv('important_files/detection_coverage_matrix_final.csv', index=False)

# Find non-standard integrations
non_standard_rows = []
allowed_tools = ['edr', 'firewall', 'iam', 'ad', 'itsm', 'entra', 'okta', 'identity']

for idx, r in df.iterrows():
    details = str(r.get('Coverage Details', '')).lower()
    tooling = str(r.get('Extra Tooling / Log Source Needed', '')).lower()
    name = str(r.get('Name / Category', ''))
    
    if 'soar' in details or 'soar' in tooling:
        is_allowed = False
        if any(tool in details for tool in allowed_tools) or any(tool in tooling for tool in allowed_tools):
            is_allowed = True
            
        # Check if they also mention non-standard ones
        non_standard = []
        if 'tip ' in details or 'tip api' in tooling or ' tip' in tooling:
            non_standard.append('TIP')
        if 'dns ' in details or 'dns api' in tooling or 'secure dns' in tooling:
            non_standard.append('Secure DNS')
        if 'email gateway' in details or 'email gateway' in tooling or 'seg' in tooling:
            non_standard.append('Email Gateway')
        if 'swg' in details or 'swg' in tooling or 'secure web gateway' in details:
            non_standard.append('SWG')
        if 'ztna' in details or 'ztna' in tooling:
            non_standard.append('ZTNA Platform')
        if 'endpoint dlp' in details or 'endpoint dlp' in tooling:
            non_standard.append('Endpoint DLP')
        if 'ngfw' in tooling or 'ngfw' in details:
            non_standard.append('NGFW')
            
        if non_standard:
            non_standard_rows.append({'name': name, 'integrations': ', '.join(non_standard)})

with open('scratch/non_standard_soar.json', 'w') as f:
    json.dump(non_standard_rows, f, indent=2)
