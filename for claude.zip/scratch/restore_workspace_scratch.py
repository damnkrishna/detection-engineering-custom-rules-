import os
import shutil

ide_scratch = r"C:\Users\Sunil\.gemini\antigravity-ide\brain\deb73e25-fba5-46fb-90a3-b8793435d696\scratch"
workspace_scratch = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch"

# Create target dir if it doesn't exist
os.makedirs(workspace_scratch, exist_ok=True)

# Copy all .py files
copied_files = []
for item in os.listdir(ide_scratch):
    if item.endswith('.py'):
        src = os.path.join(ide_scratch, item)
        dst = os.path.join(workspace_scratch, item)
        shutil.copy2(src, dst)
        copied_files.append(item)

print(f"Restored {len(copied_files)} python files to {workspace_scratch}")
