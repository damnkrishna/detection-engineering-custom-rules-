import openpyxl

def get_defense_impairment():
    path = "ocsf_mapped_new_sprint.xlsx"
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.active
        rows = list(sheet.iter_rows(values_only=True))
        
        pending_defense = []
        for idx, r in enumerate(rows[1:], 1):
            if any(r):
                status = r[11]
                tactic = r[3]
                if status == 'Not-Yet Done' and tactic and 'defense-impairment' in tactic.lower():
                    pending_defense.append({
                        'row': idx + 1,
                        'analytic': r[0],
                        'technique': r[4],
                        'tech_name': r[5],
                        'strategy': r[6],
                        'desc': r[10]
                    })
                    
        print(f"Found {len(pending_defense)} pending defense-impairment rules:")
        for idx, item in enumerate(pending_defense, 1):
            print(f"{idx}. Analytic ID: {item['analytic']}")
            print(f"   Technique: {item['technique']} ({item['tech_name']})")
            print(f"   Strategy: {item['strategy']}")
            print(f"   Description: {item['desc']}")
            print(f"   Row in spreadsheet: {item['row']}\n")
            
    except Exception as e:
        print("Error:", e)

if __name__ == '__main__':
    get_defense_impairment()
