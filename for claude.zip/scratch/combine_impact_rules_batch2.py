import os

def combine_rules():
    impact_dir = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\impact"
    output_file = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\sprint_impact_batch2_combined.txt"
    
    files = [
        "AN1008-T1667-DET0355.md",
        "AN1012-T1499.001-DET0356.md",
        "AN1097-T1565.003-DET0391.md",
        "AN1140-T1498.002-DET0408.md",
        "AN1165-T1499.003-DET0415.md",
        "AN1361-T1657-DET0495.md",
        "AN1434-T1498-DET0518.md",
        "AN1489-T1496.001-DET0540.md",
        "AN1538-T1529-DET0559.md",
        "AN1622-T1491.002-DET0590.md"
    ]
    
    combined_content = ""
    for fname in files:
        f = os.path.join(impact_dir, fname)
        with open(f, 'r', encoding='utf-8') as fh:
            content = fh.read()
        
        combined_content += f"# File: {fname}\n\n"
        combined_content += content
        combined_content += "\n\n" + "="*80 + "\n\n"
        
    with open(output_file, 'w', encoding='utf-8') as out:
        out.write(combined_content)
        
    print(f"Combined Batch 2 rules into {output_file}")

if __name__ == '__main__':
    combine_rules()
