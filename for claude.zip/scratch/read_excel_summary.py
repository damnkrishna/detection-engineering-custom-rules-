import openpyxl

def inspect_excel():
    path = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\new work\rules_coverage_summary.xlsx"
    out_path = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\scratch\excel_summary_contents.txt"
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(f"Sheets in rules_coverage_summary.xlsx: {wb.sheetnames}\n")
            for name in wb.sheetnames:
                sheet = wb[name]
                f.write(f"\n--- Sheet: {name} ---\n")
                for row in list(sheet.iter_rows(values_only=True)):
                    if any(row):
                        f.write(str(row) + "\n")
        print(f"Excel contents successfully dumped to {out_path}")
    except Exception as e:
        print("Error reading excel:", e)

if __name__ == '__main__':
    inspect_excel()
