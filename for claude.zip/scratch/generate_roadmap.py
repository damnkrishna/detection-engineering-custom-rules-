import openpyxl
from collections import defaultdict

file_path = r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\ocsf_mapped_new_sprint.xlsx"
wb = openpyxl.load_workbook(file_path)
ws = wb.active

stats = defaultdict(lambda: {'Done': 0, 'Pending': 0})

for row in range(2, ws.max_row + 1):
    tactic = ws.cell(row=row, column=4).value # Column 4: Tactic
    status = ws.cell(row=row, column=12).value # Column 12: Status
    
    if tactic:
        tactic_str = str(tactic).strip()
        status_str = str(status).strip().lower() if status else 'not-yet done'
        
        if status_str == 'done':
            stats[tactic_str]['Done'] += 1
        else:
            stats[tactic_str]['Pending'] += 1

print("Tactic | Done | Pending | Total")
print("---|---|---|---")
for tactic, counts in sorted(stats.items(), key=lambda x: x[0]):
    total = counts['Done'] + counts['Pending']
    print(f"{tactic} | {counts['Done']} | {counts['Pending']} | {total}")
