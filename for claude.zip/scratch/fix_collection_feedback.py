import uuid
import os

def generate_fixed_collection():
    # 1. AN0243
    an0243_content = f"""### 1. Technique Breakdown: T1056.001
* What it is: Input Capture: Keylogging. Adversaries use keylogging software or APIs to record user keystrokes, aiming to harvest passwords, credentials, and sensitive inputs. Once installed, these tools run in the background, writing logs locally or beaconing them out.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and Sysmon Registry Set events (Event ID 13).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Sysmon provides visibility into process creations, command-line execution, and registry modifications.
  - NIDS (Suricata + Zeek): NO. Host-local capture mechanism.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 13 (registry_set)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Keylogger Utility Process Execution
Detects the execution of known command-line keyloggers or scripts with parameters commonly used to capture inputs.

```yaml
title: Keylogger Utility Process Execution (AN0243-A)
id: {uuid.uuid4()}
status: experimental
description: Detects the execution of command-line keylogging binaries or tools.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\\keylogger.exe'
            - '\\klg.exe'
            - '\\logkeys.exe'
            - '\\ardamax.exe'
            - '\\refog.exe'
        OriginalFileName:
            - 'keylogger.exe'
            - 'klg.exe'
            - 'logkeys.exe'
            - 'ardamax.exe'
            - 'refog.exe'
    selection_cli:
        CommandLine|contains:
            - 'keylog'
            - 'keystroke'
            - 'hookkey'
            - 'logkey'
    filter_installers:
        ParentImage|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_images or selection_cli) and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - ParentImage
    - User
falsepositives:
    - Administrative diagnostics or keyboard remapping utilities installed by users.
level: medium
tags:
    - attack.collection
    - attack.t1056.001
    - analytic.an0243
    - detection.det0089
```

#### Rule 2 of 2: Keyboard Layout Registry Tampering
Detects modifications to keyboard layout configuration registry keys (e.g. Scancode Map) used to intercept and map keys globally, filtering standard system processes.

```yaml
title: Keyboard Layout Registry Tampering (AN0243-B)
id: {uuid.uuid4()}
status: experimental
description: Detects registry modifications to Scancode Map or Keyboard Layout Order.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: registry_set
    product: windows
detection:
    selection_registry:
        TargetObject|contains:
            - 'SYSTEM\\CurrentControlSet\\Control\\Keyboard Layout'
        TargetObject|endswith:
            - '\\Scancode Map'
            - '\\Layout Display Name'
    filter_system:
        Image|endswith:
            - '\\ctfmon.exe'
            - '\\explorer.exe'
            - '\\svchost.exe'
    condition: selection_registry and not filter_system
fields:
    - TargetObject
    - Details
    - User
falsepositives:
    - Legitimate user customizations or language pack installations remapping specific keys.
level: high
tags:
    - attack.collection
    - attack.t1056.001
    - analytic.an0243
    - detection.det0089
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Administrative Keyboard Layout Changes
  * The Issue: Administrators configuring domain-wide language or keyboard settings (e.g. Colemak/Dvorak mappings) will write to Keyboard Layout registry keys, triggering Rule 2.
  * The Fix: Baseline standard keyboard layouts in use across the enterprise and add their exact hex configurations (e.g., standard layout DLL names or hex codes) to a registry details whitelist.
* Problem 2: Native Accessibility Features
  * The Issue: Virtual keyboard or accessibility software may execute hooks or write layout changes under system user contexts.
  * The Fix: Exclude processes signed by Microsoft (e.g. `osk.exe` or `utilman.exe`) as valid executing images.
"""

    # 2. AN0282
    an0282_content = f"""### 1. Technique Breakdown: T1056
* What it is: Input Capture. Adversaries use input capture techniques to intercept user inputs before they reach their destination. This includes keyboard capture, API hooking, and accessing virtual terminal interfaces to steal credentials.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and Sysmon Image Load events (Event ID 7).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Process command lines and image loading are audited natively.
  - NIDS (Suricata + Zeek): NO. Host-local system operations.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 7 (image_load)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Input Sniffing Process Execution
Detects the execution of known input capturing or credential sniffing tools.

```yaml
title: Input Sniffing Process Execution (AN0282-A)
id: {uuid.uuid4()}
status: experimental
description: Detects process execution of tools like SniffPass or custom password capture binaries.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\\sniffpass.exe'
            - '\\pipedup.exe'
            - '\\winpst.exe'
        OriginalFileName:
            - 'sniffpass.exe'
            - 'pipedup.exe'
            - 'winpst.exe'
    selection_cli:
        CommandLine|contains:
            - 'sniffpass'
            - 'credsniff'
            - 'inputcapture'
    filter_installers:
        ParentImage|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_images or selection_cli) and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Legitimate penetration testing activities or authorized system troubleshooting utilities.
level: high
tags:
    - attack.collection
    - attack.t1056
    - analytic.an0282
    - detection.det0102
```

#### Rule 2 of 2: Suspicious Module Load in Interactive User Processes
Detects loading of DLLs from non-system, user-writable directories (Temp, AppData, etc.) into interactive processes like browsers or explorer, which is a common mechanism for injecting input-hooking DLLs.

```yaml
title: Suspicious Module Load in Interactive User Processes (AN0282-B)
id: {uuid.uuid4()}
status: experimental
description: Detects loading of DLLs from user-writable directories into interactive user shells and web browsers.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: image_load
    product: windows
detection:
    selection_target:
        Image|endswith:
            - '\\explorer.exe'
            - '\\chrome.exe'
            - '\\firefox.exe'
            - '\\msedge.exe'
            - '\\mstsc.exe'
    selection_load:
        ImageLoaded|contains:
            - '\\Temp\\'
            - '\\Users\\Public\\'
            - '\\AppData\\'
            - '\\ProgramData\\'
    condition: selection_target and selection_load
fields:
    - Image
    - ImageLoaded
    - User
falsepositives:
    - Browser updates running inside AppData or legitimate web browser extensions that utilize local native host helper executables.
level: medium
tags:
    - attack.collection
    - attack.t1056
    - analytic.an0282
    - detection.det0102
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: AppData Browser/Application Updates
  * The Issue: Web browsers running automatic updates out of AppData folders will load their own DLLs and trigger Rule 2.
  * The Fix: Exclude specific certified updater binaries or filter based on corporate software distribution paths.
* Problem 2: Native App Execution in AppData
  * The Issue: Some corporate applications deploy binaries directly to user AppData directories.
  * The Fix: Baseline approved business applications and filter their loaded modules.
"""

    # 3. AN0389
    an0389_content = f"""### 1. Technique Breakdown: T1056.004
* What it is: Input Capture: Credential API Hooking. Adversaries hook credential APIs (such as those within LSASS, LogonUI, or custom credential providers) to intercept and collect plain-text user passwords as they are entered during logon or password change procedures.
* Log Source Requirements: Sysmon Process Access logs (Event ID 10) and Sysmon Image Load logs (Event ID 7).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Memory injection access flags and DLL loads inside LSASS/LogonUI are natively audited.
  - NIDS (Suricata + Zeek): NO. Host-local system manipulation.
* Log Sources Covered:
  - Sysmon Event ID 10 (process_access)
  - Sysmon Event ID 7 (image_load)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: Logon Process Access
Detects suspicious process access to `logonui.exe` or `lsass.exe` with high-privilege access masks (such as VirtualMemoryWrite or ProcessVMOperation) indicative of memory patching.

```yaml
title: Logon Process Memory Access (AN0389-A)
id: {uuid.uuid4()}
status: experimental
description: Detects process access to logonui.exe or lsass.exe indicating credential harvesting or hooking.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_access
    product: windows
detection:
    selection_targets:
        TargetImage|endswith:
            - '\\logonui.exe'
            - '\\lsass.exe'
    selection_access:
        # Require exact match on high access masks that allow VM write/modify operations
        GrantedAccess:
            - '0x1F3FFF'
            - '0x1F0FFF'
            - '0x1010'
            - '0x1410'
            - '0x1438'
    filter_system:
        SourceImage|endswith:
            - '\\services.exe'
            - '\\wininit.exe'
            - '\\csrss.exe'
            - '\\winlogon.exe'
            - '\\MsMpEng.exe'
    condition: selection_targets and selection_access and not filter_system
fields:
    - SourceImage
    - TargetImage
    - GrantedAccess
    - User
falsepositives:
    - Normal administrative diagnostic and troubleshooting sessions.
level: high
tags:
    - attack.collection
    - attack.t1056.004
    - analytic.an0389
    - detection.det0139
```

#### Rule 2 of 2: Logon UI Suspicious DLL Load
Detects loading of DLLs into the `logonui.exe` process space from non-standard locations (such as Temp or AppData).

```yaml
title: Logon UI Suspicious DLL Load (AN0389-B)
id: {uuid.uuid4()}
status: experimental
description: Detects DLLs loaded into logonui.exe from non-standard locations (such as Temp or AppData).
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: image_load
    product: windows
detection:
    selection_target:
        Image|endswith: '\\logonui.exe'
    filter_standard_paths:
        ImageLoaded|startswith:
            - 'C:\\Windows\\System32\\'
            - 'C:\\Windows\\SysWOW64\\'
            - 'C:\\Program Files\\'
            - 'C:\\Program Files (x86)\\'
    condition: selection_target and not filter_standard_paths
fields:
    - Image
    - ImageLoaded
    - User
falsepositives:
    - Third-party credential providers or customized smart-card reader software installed in non-standard enterprise configurations.
level: high
tags:
    - attack.collection
    - attack.t1056.004
    - analytic.an0389
    - detection.det0139
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Custom Credential Providers
  * The Issue: Organizations using custom multi-factor authentication (MFA) client providers (such as Duo or Okta Credential Provider) load their custom DLLs into `logonui.exe`, triggering Rule 2.
  * The Fix: Baseline the specific DLL path and name used by the approved MFA provider and add it to the `filter_standard_paths` whitelist.
* Problem 2: EDR Agent Self-Protection
  * The Issue: EDR/AV security agents access `lsass.exe` or `logonui.exe` memory spaces to analyze behaviors, triggering Rule 1.
  * The Fix: Whitelist standard security executable paths (e.g. `MsMpEng.exe` or specific EDR executable patterns) in `filter_system`.
"""

    # 4. AN1321
    an1321_content = f"""### 1. Technique Breakdown: T1056.003
* What it is: Input Capture: Web Portal Capture. Adversaries modify or deploy malicious login pages on legitimate web servers (e.g., IIS, Apache, Tomcat) to harvest user credentials. When users attempt to log in, the modified portal captures and logs their usernames and passwords in cleartext before passing them to the actual authentication service.
* Log Source Requirements: Sysmon File Creation events (Event ID 11).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. File write activity inside web server root folders is audited natively.
  - NIDS (Suricata + Zeek): NO. Mapped protocols are host-local filesystem changes.
* Log Sources Covered:
  - Sysmon Event ID 11 (file_event)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 1: Web Server Root Folder File Modification
Detects the creation or modification of scripting or HTML pages inside standard web server root directories, filtering legitimate deployment accounts and processes.

```yaml
title: Web Server Root Folder File Creation (AN1321)
id: {uuid.uuid4()}
status: experimental
description: Detects the creation of web page files in standard web root paths, which may indicate deployment of credential harvesting portals or web shells.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: file_event
    product: windows
detection:
    selection_web_roots:
        TargetFilename|contains:
            - '\\inetpub\\wwwroot\\'
            - '\\apache\\htdocs\\'
            - '\\nginx\\html\\'
            - '\\tomcat\\webapps\\'
    selection_extensions:
        TargetFilename|endswith:
            - '.php'
            - '.aspx'
            - '.asp'
            - '.jsp'
            - '.html'
            - '.htm'
    filter_installers:
        Image|endswith:
            - '\\trustedinstaller.exe'
            - '\\msiexec.exe'
            - '\\tiworker.exe'
    filter_deployment:
        User:
            - 'NT AUTHORITY\\SYSTEM'
            - 'NT AUTHORITY\\NETWORK SERVICE'
        Image|endswith:
            - '\\w3wp.exe'
            - '\\msdeploy.exe'
            - '\\deployagent.exe'
    condition: selection_web_roots and selection_extensions and not (filter_installers or filter_deployment)
fields:
    - TargetFilename
    - Image
    - User
falsepositives:
    - Standard deployment of web applications, portal content updates, or authorized web server administration.
level: medium
tags:
    - attack.collection
    - attack.t1056.003
    - analytic.an1321
    - detection.det0480
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Continuous Integration / Continuous Deployment (CI/CD) Pipeline Noise
  * The Issue: Automated deploy runners (like Jenkins, GitLab runner, or Azure DevOps agent) constantly write build artifacts to the web directories, causing high false positive rates.
  * The Fix: Exclude the executing binary path or service account associated with approved deployment pipelines in `filter_deployment`.
* Problem 2: Non-Standard Web Roots
  * The Issue: Custom applications hosting web portals out of custom folders (like `C:\\App\\web\\`) will bypass standard path detections.
  * The Fix: Baseline system web server configuration directories and add custom web root paths to the `selection_web_roots` list.
"""

    # 5. AN1440
    an1440_content = f"""### 1. Technique Breakdown: T1056.002
* What it is: Input Capture: GUI Input Capture. Adversaries prompt users for credentials by deploying spoofed GUI dialogs or windows. This is often accomplished via scripting hosts (like PowerShell or VB) using native Windows APIs (such as `Get-Credential` or `InputBox`) to trick users into typing their passwords.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and PowerShell Script Block logging (Event ID 4104).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Script blocks and command-line execution parameters are captured natively.
  - NIDS (Suricata + Zeek): NO. Host-local script executions.
* Log Sources Covered:
  - Sysmon Event ID 4104 (ps_script)
  - Sysmon Event ID 1 (process_creation)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: GUI Input Capture via PowerShell Script Block
Detects PowerShell script block logs executing commands that display popup dialogs or prompt for credentials, requiring presence of deceptive/spoofing text to avoid admin noise.

```yaml
title: GUI Input Capture via PowerShell Script Block (AN1440-A)
id: {uuid.uuid4()}
status: experimental
description: Detects PowerShell script block logging containing API calls or cmdlets that prompt users for credentials via GUI popups with suspicious context.
author: Krishna Gupta
date: 2026-06-30
logsource:
    product: windows
    category: ps_script
detection:
    selection_cmdlets:
        ScriptBlockText|contains:
            - 'Get-Credential'
            - 'PromptForCredential'
            - 'CredUIPromptForCredentials'
    selection_visualbasic:
        ScriptBlockText|contains:
            - '[Microsoft.VisualBasic.Interaction]::InputBox'
            - 'Interaction.InputBox'
    selection_spoof_context:
        ScriptBlockText|contains:
            - 'Password'
            - 'Outlook'
            - 'Office365'
            - 'Microsoft'
            - 'Security Update'
            - 'Verify'
            - 'Login'
    condition: (selection_cmdlets or selection_visualbasic) and selection_spoof_context
fields:
    - ScriptBlockText
    - User
falsepositives:
    - Authorized administrative scripts requesting user or service account credentials for execution context changes.
level: medium
tags:
    - attack.collection
    - attack.t1056.002
    - analytic.an1440
    - detection.det0521
```

#### Rule 2 of 2: GUI Input Capture Command Line
Detects command-line execution containing terms indicating credential prompt dialogues or Visual Basic input boxes, narrowed to scripts running from suspicious locations or with spoofing keywords.

```yaml
title: GUI Input Capture Command Line (AN1440-B)
id: {uuid.uuid4()}
status: experimental
description: Detects command-line parameters indicating spoofed credential windows or input dialog boxes combined with suspicious paths or keywords.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_cli:
        CommandLine|contains:
            - 'Get-Credential'
            - 'PromptForCredential'
            - 'InputBox'
    selection_suspicious_paths:
        CommandLine|contains:
            - '\\Temp\\'
            - '\\AppData\\'
            - '\\Users\\Public\\'
    selection_spoof_keywords:
        CommandLine|contains:
            - 'Password'
            - 'Outlook'
            - 'Microsoft'
            - 'Security'
            - 'Verify'
            - 'Login'
    condition: selection_cli and (selection_suspicious_paths or selection_spoof_keywords)
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Administrators running administrative scripts interactively.
level: medium
tags:
    - attack.collection
    - attack.t1056.002
    - analytic.an1440
    - detection.det0521
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Admin Credential Prompts
  * The Issue: Scripted installers or automation tasks that prompt admins for elevated service credentials will trigger alerts.
  * The Fix: Exclude approved script names running from secure folders (e.g. `C:\\Windows\\System32\\GroupPolicy\\`) or signed administrative scripts using `filter_scripts`.
* Problem 2: Obfuscation Evasion
  * The Issue: Attackers can encode or obfuscate the `Get-Credential` command string in PowerShell script blocks.
  * The Fix: Enable script block logging and use system-level AMSI (Antimalware Scan Interface) integrations to analyze decrypted script payloads.
"""

    # 6. AN0823
    an0823_content = f"""### 1. Technique Breakdown: T1557
* What it is: Adversary-in-the-Middle. Adversaries position themselves between two or more networked devices to capture, modify, or inject traffic. This is typically used to harvest credentials or session tokens passing over the network.
* Log Source Requirements: Sysmon Process Creation logs (Event ID 1) and Sysmon Network Connection logs (Event ID 3).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Process command lines and outbound/inbound network socket bindings are audited.
  - NIDS (Suricata + Zeek): YES. Can detect network-level AiTM redirects.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 3 (network_connection)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: AiTM Tool Execution
Detects the execution of binaries or tools commonly used to perform Adversary-in-the-Middle interception.

```yaml
title: AiTM Interception Tool Execution (AN0823-A)
id: {uuid.uuid4()}
status: experimental
description: Detects command-line execution of tools like Bettercap, Ettercap, or mitmproxy.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\\bettercap.exe'
            - '\\ettercap.exe'
            - '\\mitmproxy.exe'
            - '\\mitmdump.exe'
            - '\\burpsuite.exe'
        OriginalFileName:
            - 'bettercap.exe'
            - 'ettercap.exe'
            - 'mitmproxy.exe'
            - 'mitmdump.exe'
            - 'burpsuite.exe'
    selection_cli:
        CommandLine|contains:
            - 'bettercap'
            - 'ettercap'
            - 'mitmproxy'
            - 'arp.spoof'
            - 'dns.spoof'
    filter_installers:
        ParentImage|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_images or selection_cli) and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Authorized network diagnostics or application security penetration testing.
level: high
tags:
    - attack.collection
    - attack.t1557
    - analytic.an0823
    - detection.det0296
```

#### Rule 2 of 2: AiTM Non-Standard Proxy Network Connection
Detects network connections binding to local proxy ports (e.g. 8080, 8443) initiated by scripting interpreters or command interpreters, suggesting a local interceptor proxy is running.

```yaml
title: Scripting Process Binding to Local Proxy Ports (AN0823-B)
id: {uuid.uuid4()}
status: experimental
description: Detects Python, PowerShell, or Go scripting processes opening listening sockets or connecting to non-standard HTTP proxy ports.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: network_connection
    product: windows
detection:
    selection_processes:
        Image|endswith:
            - '\\python.exe'
            - '\\powershell.exe'
            - '\\pwsh.exe'
            - '\\wscript.exe'
            - '\\cscript.exe'
            - '\\cmd.exe'
    selection_ports:
        DestinationPort:
            - 8080
            - 8000
            - 8443
            - 9090
    selection_local:
        DestinationIp:
            - '127.0.0.1'
            - '::1'
    condition: selection_processes and selection_ports and selection_local
fields:
    - Image
    - DestinationIp
    - DestinationPort
    - User
falsepositives:
    - Software developers running local debug web servers or development APIs.
level: medium
tags:
    - attack.collection
    - attack.t1557
    - analytic.an0823
    - detection.det0296
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Developer Workstations Noise
  * The Issue: Software engineers running local web developments or using tools like Burp Suite or mitmproxy to debug API integrations will trigger false positives on Rule 2.
  * The Fix: Exclude specific developer workstation subnets or active developer user groups from the alerting criteria using a `filter_developer_hosts` block.
* Problem 2: Obfuscated Scripting Interpreters
  * The Issue: Scripting binaries can be copied to non-standard names (e.g. `py.exe` renamed to `helper.exe`), bypassing the `Image|endswith` filter.
  * The Fix: Enable Sysmon Event ID 1 to track process parentage and combine with hash baselines.
"""

    # 7. AN1091
    an1091_content = f"""### 1. Technique Breakdown: T1557.002
* What it is: Adversary-in-the-Middle: ARP Cache Poisoning. Adversaries send malicious ARP packets onto a local network to associate their MAC address with the IP address of another host (typically the default gateway). This redirects network traffic destined for that host through the attacker's system.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Captures command-line arguments of tools modifying routing tables or sending raw packets.
  - NIDS (Suricata + Zeek): YES. Specialized NIDS rules can flag duplicate IP-to-MAC assignments or high-rate gratuitous ARP traffic.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: ARP Spoofing Interception Tool Execution
Detects the execution of specialized tools (like Cain & Abel, Ettercap, Arpspoof) used to run ARP poisoning attacks.

```yaml
title: ARP Spoofing Tool Execution (AN1091-A)
id: {uuid.uuid4()}
status: experimental
description: Detects command-line execution of tools designed to send malicious ARP replies or configure ARP cache redirection.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\\arpspoof.exe'
            - '\\dsniff.exe'
            - '\\cain.exe'
            - '\\ettercap.exe'
        OriginalFileName:
            - 'arpspoof.exe'
            - 'dsniff.exe'
            - 'cain.exe'
            - 'ettercap.exe'
    selection_cli:
        CommandLine|contains:
            - 'arpspoof'
            - 'arp.spoof'
            - 'arp.mitm'
    filter_installers:
        ParentImage|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_images or selection_cli) and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Network administrator diagnostics or authorized vulnerability scans.
level: high
tags:
    - attack.collection
    - attack.t1557.002
    - analytic.an1091
    - detection.det0387
```

#### Rule 2 of 2: Native ARP Table Static Modification
Detects the use of the native Windows `arp.exe` command to configure static ARP mappings, which can be used to hijack gateway routes.

```yaml
title: Native ARP Table Static Modification (AN1091-B)
id: {uuid.uuid4()}
status: experimental
description: Detects static modification of the local ARP cache table via native command-line parameters.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_image:
        Image|endswith: '\\arp.exe'
        OriginalFileName: 'arp.exe'
    selection_args:
        CommandLine|contains:
            - ' -s '
            - ' /s '
    condition: selection_image and selection_args
fields:
    - Image
    - CommandLine
    - User
falsepositives:
    - Administrators configuring static mappings for legacy networking equipment or high-availability load balancers.
level: medium
tags:
    - attack.collection
    - attack.t1557.002
    - analytic.an1091
    - detection.det0387
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Automated Cluster Setup Scripts
  * The Issue: Failover cluster or network load-balancing configuration scripts may define static ARP entries for virtual IPs, triggering false positive alerts on Rule 2.
  * The Fix: Exclude administrative setup service accounts running static route scripts.
* Problem 2: ARP Poisoning via Raw Sockets
  * The Issue: Attackers can execute custom python scripts (e.g. Scapy) or compiled Go binaries that write raw frames directly to network sockets without executing native utilities.
  * The Fix: Rely on network-level IDS (Suricata/Zeek) analysis to inspect packet streams for excessive gratuitous ARP responses.
"""

    # 8. AN1274
    an1274_content = f"""### 1. Technique Breakdown: T1557.001
* What it is: Adversary-in-the-Middle: LLMNR/NBT-NS Poisoning and SMB Relay. Adversaries exploit local name resolution protocols (like LLMNR and NBT-NS) to intercept host lookup requests, respond with their own IP, and capture NTLM credential hashes. They can either crack these hashes offline or relay them to other network resources (SMB Relay) to gain unauthorized access.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and Sysmon Network Connection events (Event ID 3).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Tool launches (e.g. Responder, Inveigh) and processes binding to UDP port 5355/137 or forwarding TCP 445 are visible.
  - NIDS (Suricata + Zeek): YES. Can detect anomalous LLMNR/NBT-NS responses returning non-existent host mappings.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 3 (network_connection)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: LLMNR/NBT-NS Poisoning Tool Execution
Detects process execution of LLMNR/NBT-NS spoofing and SMB relay utilities (like Responder, Inveigh, or Impacket).

```yaml
title: LLMNR/NBT-NS Spoofing Tool Execution (AN1274-A)
id: {uuid.uuid4()}
status: experimental
description: Detects command-line execution of Responder, Inveigh, or impacket-ntlmrelayx.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\\Responder.exe'
            - '\\Inveigh.exe'
            - '\\ntlmrelayx.exe'
        OriginalFileName:
            - 'Responder.exe'
            - 'Inveigh.exe'
            - 'ntlmrelayx.exe'
    selection_cli:
        CommandLine|contains:
            - 'responder'
            - 'inveigh'
            - 'ntlmrelayx'
            - ' -smbrelay'
            - ' -llmnr'
    filter_installers:
        ParentImage|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_images or selection_cli) and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Internal penetration testing exercises or authorized network auditing.
level: high
tags:
    - attack.collection
    - attack.t1557.001
    - analytic.an1274
    - detection.det0462
```

#### Rule 2 of 2: LLMNR/NBT-NS Protocol Port Binding
Detects scripting interpreter binaries binding to standard LLMNR (UDP 5355) or NBT-NS (UDP 137) ports to listen for lookup requests.

```yaml
title: Scripting Process Binding to LLMNR or NetBIOS Ports (AN1274-B)
id: {uuid.uuid4()}
status: experimental
description: Detects Python, PowerShell, or command interpreters binding to LLMNR (UDP 5355) or NetBIOS Name Service (UDP 137) ports.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: network_connection
    product: windows
detection:
    selection_processes:
        Image|endswith:
            - '\\python.exe'
            - '\\powershell.exe'
            - '\\pwsh.exe'
            - '\\cmd.exe'
    selection_ports:
        SourcePort:
            - 5355  # LLMNR UDP
            - 137   # NBT-NS UDP
    condition: selection_processes and selection_ports
fields:
    - Image
    - SourcePort
    - DestinationIp
    - User
falsepositives:
    - Legitimate system administration tools or network diagnostic scripts configured to resolve hostnames.
level: high
tags:
    - attack.collection
    - attack.t1557.001
    - analytic.an1274
    - detection.det0462
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Administrative Host Resolution Diagnostics
  * The Issue: Admins executing custom network mapping scripts written in PowerShell or Python may temporarily listen or bind to UDP 137/5355, causing false alerts.
  * The Fix: Baseline administrative service accounts and hosts that perform legitimate network discovery.
* Problem 2: Port Binding Privileges
  * The Issue: Binding to low ports (like 137 or 445) requires elevated privileges, meaning an attacker running in a low-privilege context cannot succeed.
  * The Fix: Combine this logic with detection of local privilege escalation indicators.
"""

    # 9. AN1290
    an1290_content = f"""### 1. Technique Breakdown: T1557.003
* What it is: Adversary-in-the-Middle: DHCP Spoofing. Adversaries configure a rogue DHCP server on a local network to respond to DHCP discover requests. By offering network configuration details (such as default gateway and DNS servers) that point to the attacker's system, they redirect host traffic to capture credentials or conduct further interception.
* Log Source Requirements: Sysmon Process Creation events (Event ID 1) and Sysmon Network Connection events (Event ID 3).
* Coverage Check:
  - HIDS (Sysmon + Windows Defender): YES. Tool execution (like Yersinia) and unofficial processes binding to UDP port 67/68 are monitored.
  - NIDS (Suricata + Zeek): YES. Network logs reveal multiple active DHCP servers or high volumes of DHCP discover packets.
* Log Sources Covered:
  - Sysmon Event ID 1 (process_creation)
  - Sysmon Event ID 3 (network_connection)
* Log Sources Missing / Unused:
  - None.

---

### 2. Custom Sigma Rule

#### Rule 1 of 2: DHCP Starvation or Spoofing Tool Execution
Detects the execution of binaries or tools designed to send malicious DHCP requests or act as rogue DHCP servers.

```yaml
title: DHCP Spoofing Tool Execution (AN1290-A)
id: {uuid.uuid4()}
status: experimental
description: Detects command-line execution of DHCP starvation or spoofing tools like Yersinia.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: process_creation
    product: windows
detection:
    selection_images:
        Image|endswith:
            - '\\yersinia.exe'
            - '\\dhcpstarv.exe'
        OriginalFileName:
            - 'yersinia.exe'
            - 'dhcpstarv.exe'
    selection_cli:
        CommandLine|contains:
            - 'yersinia'
            - 'dhcpstarv'
            - 'dhcp.spoof'
    filter_installers:
        ParentImage|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_images or selection_cli) and not filter_installers
fields:
    - Image
    - OriginalFileName
    - CommandLine
    - User
falsepositives:
    - Network engineering diagnostics or vulnerability scans.
level: high
tags:
    - attack.collection
    - attack.t1557.003
    - analytic.an1290
    - detection.det0468
```

#### Rule 2 of 2: Unofficial DHCP Port Binding
Detects scripting interpreter processes binding to UDP port 67 (DHCP Server port) to capture or spoof DHCP discovery offers.

```yaml
title: Unofficial DHCP Server Port Binding (AN1290-B)
id: {uuid.uuid4()}
status: experimental
description: Detects non-system scripting processes binding to the DHCP server port (UDP 67).
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: network_connection
    product: windows
detection:
    selection_processes:
        Image|endswith:
            - '\\python.exe'
            - '\\powershell.exe'
            - '\\pwsh.exe'
            - '\\cmd.exe'
    selection_ports:
        SourcePort:
            - 67
    filter_dhcp_service:
        # Filter standard Microsoft DHCP Server service
        Image|endswith: '\\tcpsvcs.exe'
    condition: selection_processes and selection_ports and not filter_dhcp_service
fields:
    - Image
    - SourcePort
    - DestinationIp
    - User
falsepositives:
    - Authorized developer scripts hosting virtual local DHCP services for sandbox environments.
level: high
tags:
    - attack.collection
    - attack.t1557.003
    - analytic.an1290
    - detection.det0468
```

---

### 3. Blind Spots & Tuning (The "Problems")

* Problem 1: Virtualization Environments (Hyper-V / VMware)
  * The Issue: Virtual switches and host integration services (like `vmnat.exe` or VirtualBox services) may bind to UDP 67/68 to assign IPs to guest machines, generating false alerts.
  * The Fix: Exclude approved virtualization processes (e.g. `vmware-natd.exe` or `vmnat.exe`) from the `filter_dhcp_service` whitelist.
* Problem 2: Linux DHCP Daemons
  * The Issue: This rule covers Windows logs; Linux DHCP modifications or spoofing on cross-platform networks will require equivalent Linux auditing configurations (e.g. Auditd/Sysmon for Linux).
  * The Fix: Implement native network IDS (Suricata) rules to flag unauthorized DHCP servers at the network boundary.
"""

    # Dictionary of file paths and new contents
    contents_map = {
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0243-T1056.001-DET0089.md": an0243_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0282-T1056-DET0102.md": an0282_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0389-T1056.004-DET0139.md": an0389_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1321-T1056.003-DET0480.md": an1321_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1440-T1056.002-DET0521.md": an1440_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN0823-T1557-DET0296.md": an0823_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1091-T1557.002-DET0387.md": an1091_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1274-T1557.001-DET0462.md": an1274_content,
        r"c:\Users\Sunil\OneDrive\Desktop\coorelation-rules\collection\AN1290-T1557.003-DET0468.md": an1290_content
    }
    
    for filepath, content in contents_map.items():
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content.strip() + "\n")
        print(f"Rewritten {filepath} with fixes and random UUIDs.")

if __name__ == '__main__':
    generate_fixed_collection()
