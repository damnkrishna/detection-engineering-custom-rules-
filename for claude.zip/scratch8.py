import os
import re

directory = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\exfiltration"

for filename in os.listdir(directory):
    if not filename.endswith(".md"):
        continue

    filepath = os.path.join(directory, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    if filename == "AN0596-T1030-DET0213.md":
        # Format the undetectable rule correctly
        # Replace the "Not applicable." lines with the standard texts
        content = content.replace("### 3. Blind Spots & Tuning", "### 3. Blind Spots & Tuning (The \"Problems\")")
        content = content.replace("### 4. Test Cases", "### 4. Test Cases (Engine Pipeline Verification)")
        content = content.replace("### 5. Telemetry", "### 5. Raw Telemetry Dataset (OCSF JSON)")
        
        # Replace the first "Not applicable." after Test Cases with the standard note
        test_case_note = "*Note: This technique bypasses threshold alerts by dividing staged archives into chunked volumes, which is inherently undetectable by standard endpoint telemetry since payload sizes are not recorded. OCSF normalized rules, test cases, and telemetry are intentionally omitted to preserve pipeline integrity.*"
        
        # Replace "Not applicable." in Test Cases
        if "### 4. Test Cases (Engine Pipeline Verification)\n\nNot applicable." in content:
            content = content.replace("### 4. Test Cases (Engine Pipeline Verification)\n\nNot applicable.", f"### 4. Test Cases (Engine Pipeline Verification)\n\n{test_case_note}")
            
        # Replace "Not applicable." in Telemetry
        telemetry_note = "*Note: Intentionally omitted for undetectable external techniques.*"
        if "### 5. Raw Telemetry Dataset (OCSF JSON)\n\nNot applicable." in content:
             content = content.replace("### 5. Raw Telemetry Dataset (OCSF JSON)\n\nNot applicable.", f"### 5. Raw Telemetry Dataset (OCSF JSON)\n\n{telemetry_note}")

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Processed Undetectable File: {filename}")
        continue

    # Process detectable files
    modified = content
    
    # Replace headers sequentially from bottom up to avoid numbering collisions
    modified = modified.replace("### 5. Telemetry", "### 6. Raw Telemetry Dataset (OCSF JSON)")
    modified = modified.replace("### 4. Test Cases (Engine Pipeline Verification)", "### 5. Test Cases (Engine Pipeline Verification)")
    modified = modified.replace("### 3. Blind Spots", "### 4. Blind Spots")
    modified = modified.replace("### OCSF Normalized", "### 3. OCSF Normalized Rule")

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(modified)
    print(f"Processed Detectable File: {filename}")

print("Done processing exfiltration directory.")
