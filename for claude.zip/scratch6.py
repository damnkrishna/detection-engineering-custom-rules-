import os
import re
import json

directory = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\reconnaissance"

detectable_files = [
    "AN2067-T1592-DET0924.md",
    "AN2069-T1594-DET0926.md",
    "AN2070-T1595-DET0927.md",
    "AN2073-T1598-DET0930.md",
    "AN2075-T1682-DET0932.md"
]

undetectable_files = [
    "AN2064-T1589-DET0921.md",
    "AN2065-T1590-DET0922.md",
    "AN2066-T1591-DET0923.md",
    "AN2068-T1593-DET0925.md",
    "AN2071-T1596-DET0928.md",
    "AN2072-T1597-DET0929.md",
    "AN2074-T1681-DET0931.md"
]

injections = {
    "AN2067-T1592-DET0924.md": {
        "rule_uid": "5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Host Information Gathering (OCSF-Normalized)
id: 5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0
status: experimental
description: Detects the execution of host information gathering commands (like systeminfo, dxdiag, gpresult) within a short time window. Mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\systeminfo.exe'
            - '\\dxdiag.exe'
            - '\\gpresult.exe'
            - '\\wmic.exe'
            - '\\net.exe'
            - '\\ipconfig.exe'
            - '\\netstat.exe'
            - '\\nltest.exe'
            - '\\whoami.exe'
    condition: selection_images
fields:
    - process.file.path
    - actor.user.name
level: low
tags:
    - attack.reconnaissance
    - attack.t1592
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",
        "tests": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: systeminfo Execution (Rule 1)
  * The Log: Process Activity with process file path `C:\\Windows\\System32\\systeminfo.exe`.
  * Expected Outcome: Matches `selection_images`. MUST trigger an alert.

* True Positive 2: Malformed JSON Robustness Test (Rule 1)
  * The Log: Process Activity simulating TP-01 but intentionally omitting the `unmapped` object entirely.
  * Expected Outcome: Engine parser should degrade gracefully and still trigger the alert. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"` instead of an integer `1`.
  * Expected Outcome: Tests if the engine's JSON parser crashes on type mismatches or coerces the type gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the exact same timestamp.
  * Expected Outcome: Tests if the engine's deduplication window correctly suppresses identical events.

#### Benign / True Negatives
* Benign 1: Irrelevant Process Execution (Rule 1)
  * The Log: Process Activity matching `notepad.exe`.
  * Expected Outcome: Does not match `selection_images`. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Irrelevant Process Execution (Rule 1)", "expected_alert": false, "rule_uid": "5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\Windows\\System32\\notepad.exe", "name": "notepad.exe"}}, "actor": {"user": {"name": "User"}}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "systeminfo Execution (Rule 1)", "expected_alert": true, "rule_uid": "5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\Windows\\System32\\systeminfo.exe", "name": "systeminfo.exe"}}, "actor": {"user": {"name": "User"}}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Malformed JSON Robustness Test (Rule 1)", "expected_alert": true, "rule_uid": "5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\Windows\\System32\\systeminfo.exe", "name": "systeminfo.exe"}}, "actor": {"user": {"name": "User"}}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure (Rule 1)", "expected_alert": true, "rule_uid": "5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\Windows\\System32\\systeminfo.exe", "name": "systeminfo.exe"}}, "actor": {"user": {"name": "User"}}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event (Rule 1)", "expected_alert": true, "rule_uid": "5a8a1b24-9b2f-4c8d-8d4e-b5c6d7e8f9a0"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\Windows\\System32\\systeminfo.exe", "name": "systeminfo.exe"}}, "actor": {"user": {"name": "User"}}, "time": 1718000100}
```
"""
    },
    "AN2069-T1594-DET0926.md": {
        "rule_uid": "f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Search for Public-Facing Vulnerabilities (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e
status: experimental
description: Detects anomalous bursts of web requests targeting directory discovery paths. Mapped to OCSF http_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: http_activity
detection:
    selection_web_paths:
        http_request.url.path|contains:
            - '/wp-admin'
            - '/.git/'
            - '/.env'
            - '/phpinfo.php'
            - '/actuator/'
            - '/server-status'
            - '/admin/'
            - '/backup/'
    selection_response_codes:
        http_response.code:
            - 403
            - 404
            - 401
    condition: selection_web_paths and selection_response_codes
fields:
    - src_endpoint.ip
    - http_request.url.path
    - http_response.code
level: medium
tags:
    - attack.reconnaissance
    - attack.t1594
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",
        "tests": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Directory Discovery Attempt (Rule 1)
  * The Log: HTTP Activity targeting path `/.env` and returning `404`.
  * Expected Outcome: Matches `selection_web_paths` and `selection_response_codes`. MUST trigger an alert.

* True Positive 2: Malformed JSON Robustness Test (Rule 1)
  * The Log: HTTP Activity simulating TP-01 but intentionally omitting the `unmapped` object entirely.
  * Expected Outcome: Engine parser should degrade gracefully and still trigger the alert. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"` instead of an integer `1`.
  * Expected Outcome: Tests if the engine's JSON parser crashes on type mismatches or coerces the type gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the exact same timestamp.
  * Expected Outcome: Tests if the engine's deduplication window correctly suppresses identical events.

#### Benign / True Negatives
* Benign 1: Successful Legitimate Path (Rule 1)
  * The Log: HTTP Activity targeting path `/wp-admin` but returning `200`.
  * Expected Outcome: Does not match `selection_response_codes`. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Successful Legitimate Path (Rule 1)", "expected_alert": false, "rule_uid": "f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"path": "/wp-admin"}}, "http_response": {"code": 200}, "src_endpoint": {"ip": "1.1.1.1"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Directory Discovery Attempt (Rule 1)", "expected_alert": true, "rule_uid": "f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"path": "/.env"}}, "http_response": {"code": 404}, "src_endpoint": {"ip": "2.2.2.2"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Malformed JSON Robustness Test (Rule 1)", "expected_alert": true, "rule_uid": "f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"path": "/.env"}}, "http_response": {"code": 404}, "src_endpoint": {"ip": "2.2.2.2"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure (Rule 1)", "expected_alert": true, "rule_uid": "f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": "1", "activity_name": "Traffic", "http_request": {"url": {"path": "/.env"}}, "http_response": {"code": 404}, "src_endpoint": {"ip": "2.2.2.2"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event (Rule 1)", "expected_alert": true, "rule_uid": "f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c6e"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"path": "/.env"}}, "http_response": {"code": 404}, "src_endpoint": {"ip": "2.2.2.2"}, "time": 1718000100}
```
"""
    },
    "AN2070-T1595-DET0927.md": {
        "rule_uid": "b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Active Scanning - External Port Sweep (OCSF-Normalized)
id: b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d
status: experimental
description: Detects basic connection sweeps and port scans against external assets originating from single or multiple internal IPs. Mapped to OCSF network_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: network_activity
detection:
    selection_network:
        dst_endpoint.ip|cidr:
            - '192.168.0.0/16'
            - '10.0.0.0/8'
            - '172.16.0.0/12'
    selection_action:
        status:
            - 'Denied'
            - 'Rejected'
            - 'Blocked'
            - 'Dropped'
    condition: selection_network and selection_action
fields:
    - src_endpoint.ip
    - dst_endpoint.ip
    - dst_endpoint.port
    - status
level: medium
tags:
    - attack.reconnaissance
    - attack.t1595
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",
        "tests": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Denied Network Sweep (Rule 1)
  * The Log: Network Activity to destination `10.0.0.1` with status `Denied`.
  * Expected Outcome: Matches `selection_network` and `selection_action`. MUST trigger an alert.

* True Positive 2: Malformed JSON Robustness Test (Rule 1)
  * The Log: Network Activity simulating TP-01 but intentionally omitting the `unmapped` object entirely.
  * Expected Outcome: Engine parser should degrade gracefully and still trigger the alert. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"` instead of an integer `1`.
  * Expected Outcome: Tests if the engine's JSON parser crashes on type mismatches or coerces the type gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the exact same timestamp.
  * Expected Outcome: Tests if the engine's deduplication window correctly suppresses identical events.

#### Benign / True Negatives
* Benign 1: Allowed Network Connection (Rule 1)
  * The Log: Network Activity to destination `10.0.0.1` with status `Allowed`.
  * Expected Outcome: Does not match `selection_action`. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Allowed Network Connection (Rule 1)", "expected_alert": false, "rule_uid": "b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 4, "class_uid": 4001, "class_name": "Network Activity", "activity_id": 1, "activity_name": "Traffic", "dst_endpoint": {"ip": "10.0.0.1"}, "status": "Allowed", "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Denied Network Sweep (Rule 1)", "expected_alert": true, "rule_uid": "b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 4, "class_uid": 4001, "class_name": "Network Activity", "activity_id": 1, "activity_name": "Traffic", "dst_endpoint": {"ip": "10.0.0.1"}, "status": "Denied", "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Malformed JSON Robustness Test (Rule 1)", "expected_alert": true, "rule_uid": "b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 4, "class_uid": 4001, "class_name": "Network Activity", "activity_id": 1, "activity_name": "Traffic", "dst_endpoint": {"ip": "10.0.0.1"}, "status": "Denied", "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure (Rule 1)", "expected_alert": true, "rule_uid": "b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 4, "class_uid": 4001, "class_name": "Network Activity", "activity_id": "1", "activity_name": "Traffic", "dst_endpoint": {"ip": "10.0.0.1"}, "status": "Denied", "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event (Rule 1)", "expected_alert": true, "rule_uid": "b1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 4, "class_uid": 4001, "class_name": "Network Activity", "activity_id": 1, "activity_name": "Traffic", "dst_endpoint": {"ip": "10.0.0.1"}, "status": "Denied", "time": 1718000100}
```
"""
    },
    "AN2073-T1598-DET0930.md": {
        "rule_uid": "d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Phishing for Information - Internal Targeting (OCSF-Normalized)
id: d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f
status: experimental
description: Detects inbound external emails asking for system configurations, org charts, or network infrastructure details. Mapped to OCSF email_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: email_activity
detection:
    selection_phish:
        email.subject|contains:
            - 'vpn config'
            - 'antivirus config'
            - 'firewall rules'
            - 'employee directory'
            - 'org chart'
            - 'infrastructure details'
            - 'network topology'
            - 'it system query'
    selection_internal:
        unmapped.sender_type: 'internal'
    filter_training:
        email.subject|contains:
            - '[PHISHING TEST]'
            - 'Awareness Training'
        email.sender|endswith:
            - '@phishing-training-platform.com'
    condition: selection_phish and selection_internal and not filter_training
fields:
    - email.sender
    - email.recipient
    - email.subject
level: high
tags:
    - attack.reconnaissance
    - attack.t1598
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",
        "tests": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Information Phishing Email (Rule 1)
  * The Log: Email Activity with subject containing `vpn config` and sender type `internal`.
  * Expected Outcome: Matches `selection_phish` and `selection_internal`. MUST trigger an alert.

* True Positive 2: Malformed JSON Robustness Test (Rule 1)
  * The Log: Email Activity simulating TP-01 but intentionally omitting the `unmapped` object entirely.
  * Expected Outcome: Engine parser should degrade gracefully and still trigger the alert. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"` instead of an integer `1`.
  * Expected Outcome: Tests if the engine's JSON parser crashes on type mismatches or coerces the type gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the exact same timestamp.
  * Expected Outcome: Tests if the engine's deduplication window correctly suppresses identical events.

#### Benign / True Negatives
* Benign 1: Security Training Email (Rule 1)
  * The Log: Email Activity matching TP-01 but subject contains `[PHISHING TEST]`.
  * Expected Outcome: Matches `filter_training`. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Security Training Email (Rule 1)", "expected_alert": false, "rule_uid": "d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f"}, "category_uid": 3, "class_uid": 3004, "class_name": "Email Activity", "activity_id": 1, "activity_name": "Receive", "email": {"subject": "vpn config [PHISHING TEST]", "sender": "test@internal.com"}, "unmapped": {"sender_type": "internal"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Information Phishing Email (Rule 1)", "expected_alert": true, "rule_uid": "d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f"}, "category_uid": 3, "class_uid": 3004, "class_name": "Email Activity", "activity_id": 1, "activity_name": "Receive", "email": {"subject": "Need vpn config ASAP", "sender": "test@internal.com"}, "unmapped": {"sender_type": "internal"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Malformed JSON Robustness Test (Rule 1)", "expected_alert": true, "rule_uid": "d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f"}, "category_uid": 3, "class_uid": 3004, "class_name": "Email Activity", "activity_id": 1, "activity_name": "Receive", "email": {"subject": "Need vpn config ASAP", "sender": "test@internal.com"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure (Rule 1)", "expected_alert": true, "rule_uid": "d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f"}, "category_uid": 3, "class_uid": 3004, "class_name": "Email Activity", "activity_id": "1", "activity_name": "Receive", "email": {"subject": "Need vpn config ASAP", "sender": "test@internal.com"}, "unmapped": {"sender_type": "internal"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event (Rule 1)", "expected_alert": true, "rule_uid": "d1d2e3f4-f5a6-4b7d-9e9f-0a1b2c3d4e5f"}, "category_uid": 3, "class_uid": 3004, "class_name": "Email Activity", "activity_id": 1, "activity_name": "Receive", "email": {"subject": "Need vpn config ASAP", "sender": "test@internal.com"}, "unmapped": {"sender_type": "internal"}, "time": 1718000100}
```
"""
    },
    "AN2075-T1682-DET0932.md": {
        "rule_uid": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Outbound Data Upload to Public GenAI Services (OCSF-Normalized)
id: a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d
status: experimental
description: Detects outbound POST requests with payloads exceeding 10KB to known public generative AI platforms. Mapped to OCSF http_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: http_activity
detection:
    selection_ai_domains:
        http_request.url.hostname|contains:
            - 'openai.com'
            - 'chatgpt.com'
            - 'claude.ai'
            - 'gemini.google.com'
            - 'cohere.com'
            - 'poe.com'
    selection_method:
        http_request.http_method: 'POST'
    selection_bytes:
        http_request.length|gte: 10000
    filter_legitimate:
        src_endpoint.ip|cidr:
            - '10.100.200.0/24'
        actor.user.name:
            - 'svc-internal-copilot'
    condition: selection_ai_domains and selection_method and selection_bytes and not filter_legitimate
fields:
    - src_endpoint.ip
    - http_request.url.hostname
    - actor.user.name
    - http_request.length
    - http_request.http_method
level: medium
tags:
    - attack.reconnaissance
    - attack.t1682
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",
        "tests": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Large Data Upload to AI (Rule 1)
  * The Log: HTTP POST Request to `chatgpt.com` with `15000` bytes sent.
  * Expected Outcome: Matches `selection_ai_domains`, `selection_method`, and `selection_bytes`. MUST trigger an alert.

* True Positive 2: Malformed JSON Robustness Test (Rule 1)
  * The Log: HTTP Activity simulating TP-01 but intentionally omitting the `unmapped` object entirely.
  * Expected Outcome: Engine parser should degrade gracefully and still trigger the alert. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"` instead of an integer `1`.
  * Expected Outcome: Tests if the engine's JSON parser crashes on type mismatches or coerces the type gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the exact same timestamp.
  * Expected Outcome: Tests if the engine's deduplication window correctly suppresses identical events.

#### Benign / True Negatives
* Benign 1: Small POST Request (Rule 1)
  * The Log: HTTP Activity matching TP-01 but `http_request.length` is `5000`.
  * Expected Outcome: Does not match `selection_bytes`. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Small POST Request (Rule 1)", "expected_alert": false, "rule_uid": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"hostname": "chatgpt.com"}, "http_method": "POST", "length": 5000}, "src_endpoint": {"ip": "1.2.3.4"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Large Data Upload to AI (Rule 1)", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"hostname": "chatgpt.com"}, "http_method": "POST", "length": 15000}, "src_endpoint": {"ip": "1.2.3.4"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Malformed JSON Robustness Test (Rule 1)", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"hostname": "chatgpt.com"}, "http_method": "POST", "length": 15000}, "src_endpoint": {"ip": "1.2.3.4"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure (Rule 1)", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": "1", "activity_name": "Traffic", "http_request": {"url": {"hostname": "chatgpt.com"}, "http_method": "POST", "length": 15000}, "src_endpoint": {"ip": "1.2.3.4"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event (Rule 1)", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"}, "category_uid": 6, "class_uid": 4002, "class_name": "HTTP Activity", "activity_id": 1, "activity_name": "Traffic", "http_request": {"url": {"hostname": "chatgpt.com"}, "http_method": "POST", "length": 15000}, "src_endpoint": {"ip": "1.2.3.4"}, "time": 1718000100}
```
"""
    }
}

for fn in detectable_files:
    fp = os.path.join(directory, fn)
    with open(fp, 'r', encoding='utf-8') as f:
        content = f.read()

    if "### 3. OCSF Normalized Rule" not in content:
        content = content.replace('### 3. Blind Spots & Tuning (The "Problems")', injections[fn]['ocsf'])
        
        # Note: the files didn't have Test Cases or Telemetry, so we append them at the end.
        content += "\n\n" + injections[fn]['tests']
        
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Processed Detectable File: {fn}")

for fn in undetectable_files:
    fp = os.path.join(directory, fn)
    with open(fp, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if "### 4. Test Cases" not in content:
        note = "\n\n---\n\n### 4. Test Cases (Engine Pipeline Verification)\n\n*Note: This rule describes passive/external adversary behavior (OSINT). As no logs are generated within the corporate boundary, OCSF normalized rules, test cases, and telemetry are intentionally omitted to preserve pipeline integrity.*\n\n---\n\n### 5. Raw Telemetry Dataset (OCSF JSON)\n\n*Note: Intentionally omitted for undetectable external techniques.*\n"
        content += note
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Processed Undetectable File: {fn}")

print("Done processing reconnaissance directory.")
