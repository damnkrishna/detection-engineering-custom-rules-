import os

directory = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\persistence"

injections = {
    "AN2112-T1037-DET0969.md": """
### 3. OCSF Normalized Rule
```yaml
title: User Logon Initialization Script Registry Modification (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c90
status: experimental
description: "Detects modifications to Windows registry keys that configure user logon or initialization scripts (such as UserInitMprLoopbackScript or Userinit parameters), which can be abused by adversaries to achieve persistent execution during user logon."
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: registry_key_activity
detection:
    selection_registry_paths:
        registry.key|contains:
            - '\\Environment\\UserInitMprLoopbackScript'
            - '\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\Userinit'
            - '\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\VMApplet'
    filter_legitimate_userinit:
        registry.value: 'C:\\Windows\\system32\\userinit.exe,'
    condition: selection_registry_paths and not filter_legitimate_userinit
fields:
    - registry.key
    - registry.value
    - actor.user.name
    - unmapped.process_image
level: high
tags:
    - attack.persistence
    - attack.t1037
```
""",
    "AN2114-T1098-DET0971.md": """
### 3. OCSF Normalized Rule
```yaml
title: Privileged Account or Group Membership Manipulation (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5d95
status: experimental
description: "Detects the addition of users to administrative or privileged groups (Domain Admins, Enterprise Admins, Schema Admins, Local Administrators) or critical modifications to account properties (such as enabling Password Not Required or altering logon permissions) in Windows Security logs."
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: account_change
detection:
    selection_group_adds:
        activity_id:
            - 4728
            - 4732
            - 4756
        group.name:
            - 'Administrators'
            - 'Domain Admins'
            - 'Enterprise Admins'
            - 'Schema Admins'
            - 'Account Operators'
            - 'Backup Operators'
    selection_account_changes:
        activity_id: 4738
        unmapped.user_account_control|contains:
            - 'Password Not Required'
            - "Don't Require Preauth"
            - 'Trusted For Delegation'
            - 'Trusted To Authenticate For Delegation'
    filter_machine_accounts:
        actor.user.name|endswith: '$'
    condition: (selection_group_adds or selection_account_changes) and not filter_machine_accounts
fields:
    - activity_id
    - group.name
    - user.name
    - actor.user.name
    - unmapped.user_account_control
level: high
tags:
    - attack.persistence
    - attack.t1098
```
""",
    "AN2121-T1542-DET0978.md": """
### 3. OCSF Normalized Rule
```yaml
title: System Firmware or BIOS Flash Utility Execution (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c82
status: experimental
description: "Detects the execution of known bios flash utilities, motherboard firmware tools (e.g. flashrom, HpBiosUpdate, WinFlash, ASUS WinFlash), or command lines modifying UEFI settings, indicating potential pre-OS boot persistent modification."
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\flashrom.exe'
            - '\\winflash.exe'
            - '\\HpBiosUpdate.exe'
            - '\\fwupd.exe'
    selection_ofn:
        process.file.name:
            - 'flashrom.exe'
            - 'WinFlash.exe'
            - 'HpBiosUpdate.exe'
            - 'fwupd.exe'
    selection_cli:
        process.cmd_line|contains:
            - 'bios'
            - 'firmware'
            - 'uefi'
    filter_installer:
        unmapped.parent_image|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    filter_vendor:
        unmapped.parent_image|endswith:
            - '\\HPSupportSolutionsFramework.exe'
            - '\\AsusSystemControl.exe'
    condition: (selection_images or selection_ofn) and selection_cli and not (filter_installer or filter_vendor)
fields:
    - process.file.path
    - process.file.name
    - process.cmd_line
    - actor.user.name
    - unmapped.parent_image
level: high
tags:
    - attack.persistence
    - attack.t1542
```
"""
}

for filename, block in injections.items():
    filepath = os.path.join(directory, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    if "### OCSF Normalized Rule" not in content and "### 3. OCSF Normalized Rule" not in content:
        # Inject before Blind Spots
        content = content.replace("### 3. Blind Spots", block + "\n---\n\n### 4. Blind Spots")
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Injected {filename}")
