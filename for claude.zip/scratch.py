import os

rules_dir = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\discovery"

append_data = {
    "AN0016-T1482-DET0007.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Nltest Domain Trust Enumeration (Rule 1)
  * The Log: Process Activity where `nltest.exe` is executed with `/domain_trusts`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: PowerShell Domain Trust Enumeration (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes `Get-ADTrust`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Authorized Domain Controller Health Check
  * The Log: Process Activity where `nltest.exe` is executed with `/server:DC1`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Authorized Domain Controller Health Check", "expected_alert": false, "rule_uid": "3d153687-ea2c-4828-ac64-2935d5b45f61"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /server:DC1"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Nltest Domain Trust Enumeration", "expected_alert": true, "rule_uid": "3d153687-ea2c-4828-ac64-2935d5b45f61"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /domain_trusts"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "PowerShell Domain Trust Enumeration", "expected_alert": true, "rule_uid": "3d153687-ea2c-4828-ac64-2935d5b45f61"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-ADTrust"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "3d153687-ea2c-4828-ac64-2935d5b45f61"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /domain_trusts"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "3d153687-ea2c-4828-ac64-2935d5b45f61"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /domain_trusts"}, "time": 1718000100}
```
""",
    
    "AN0037-T1217-DET0013.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: CommandLine Copying Browser Profile Data (Rule 2)
  * The Log: Process Activity where `xcopy.exe` copies `Login Data` from the Chrome directory.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: Non-Browser Process Accessing Browser DB (Rule 1)
  * The Log: File Activity where `malware.exe` accesses `Cookies` inside the Chrome directory.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 2)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 2)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Browser Accessing Its Own Files
  * The Log: File Activity where `chrome.exe` accesses `Login Data`.
  * Expected Outcome: Legitimate process. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Browser Accessing Its Own Files", "expected_alert": false, "rule_uid": "9509315a-1c36-45ed-924e-490db67b3716"}, "category_uid": 1, "class_uid": 1001, "class_name": "File Activity", "activity_id": 1, "activity_name": "Open", "file": {"path": "C:\\\\Users\\\\user\\\\AppData\\\\Local\\\\Google\\\\Chrome\\\\User Data\\\\Default\\\\Login Data", "name": "Login Data"}, "process": {"file": {"path": "C:\\\\Program Files\\\\Google\\\\Chrome\\\\Application\\\\chrome.exe", "name": "chrome.exe"}}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "CommandLine Copying Browser Profile Data", "expected_alert": true, "rule_uid": "d87fdf13-ec32-4e2b-9ca9-adfc0157cf88"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\xcopy.exe", "name": "xcopy.exe"}, "cmd_line": "xcopy \\"C:\\\\Users\\\\user\\\\AppData\\\\Local\\\\Google\\\\Chrome\\\\User Data\\\\Default\\\\Login Data\\" C:\\\\Temp\\\\"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Non-Browser Process Accessing Browser DB", "expected_alert": true, "rule_uid": "9509315a-1c36-45ed-924e-490db67b3716"}, "category_uid": 1, "class_uid": 1001, "class_name": "File Activity", "activity_id": 1, "activity_name": "Open", "file": {"path": "C:\\\\Users\\\\user\\\\AppData\\\\Local\\\\Google\\\\Chrome\\\\User Data\\\\Default\\\\Cookies", "name": "Cookies"}, "process": {"file": {"path": "C:\\\\Temp\\\\malware.exe", "name": "malware.exe"}}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "d87fdf13-ec32-4e2b-9ca9-adfc0157cf88"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\xcopy.exe", "name": "xcopy.exe"}, "cmd_line": "xcopy \\"C:\\\\Users\\\\user\\\\AppData\\\\Local\\\\Google\\\\Chrome\\\\User Data\\\\Default\\\\Login Data\\" C:\\\\Temp\\\\"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "d87fdf13-ec32-4e2b-9ca9-adfc0157cf88"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\xcopy.exe", "name": "xcopy.exe"}, "cmd_line": "xcopy \\"C:\\\\Users\\\\user\\\\AppData\\\\Local\\\\Google\\\\Chrome\\\\User Data\\\\Default\\\\Login Data\\" C:\\\\Temp\\\\"}, "time": 1718000100}
```
""",

    "AN0048-T1518.001-DET0016.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: WMIC Antivirus Discovery (Rule 1)
  * The Log: Process Activity where `wmic.exe` executes `product where name like '%AntiVirus%'`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: PowerShell Defender Discovery (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes `Get-MpComputerStatus`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal System Utility Execution
  * The Log: Process Activity where `wmic.exe` executes `process list`.
  * Expected Outcome: Does not match security product discovery flags. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal System Utility Execution", "expected_alert": false, "rule_uid": "335045c9-a938-4b62-b143-907fec6d30fd"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe process list"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "WMIC Antivirus Discovery", "expected_alert": true, "rule_uid": "335045c9-a938-4b62-b143-907fec6d30fd"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe /namespace:\\\\\\\\root\\\\securitycenter2 path AntiVirusProduct get *"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "PowerShell Defender Discovery", "expected_alert": true, "rule_uid": "335045c9-a938-4b62-b143-907fec6d30fd"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-MpComputerStatus"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "335045c9-a938-4b62-b143-907fec6d30fd"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe /namespace:\\\\\\\\root\\\\securitycenter2 path AntiVirusProduct get *"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "335045c9-a938-4b62-b143-907fec6d30fd"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe /namespace:\\\\\\\\root\\\\securitycenter2 path AntiVirusProduct get *"}, "time": 1718000100}
```
""",

    "AN0095-T1057-DET0034.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Tasklist Execution (Rule 1)
  * The Log: Process Activity where `tasklist.exe` is executed.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: WMIC Process Discovery (Rule 1)
  * The Log: Process Activity where `wmic.exe` executes `process list`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal System Utility Execution
  * The Log: Process Activity where `wmic.exe` executes `cpu get name`.
  * Expected Outcome: Does not match process discovery flags. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal System Utility Execution", "expected_alert": false, "rule_uid": "42ac3a50-9a37-4862-a1e8-6aec1b8b786f"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe cpu get name"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Tasklist Execution", "expected_alert": true, "rule_uid": "42ac3a50-9a37-4862-a1e8-6aec1b8b786f"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\tasklist.exe", "name": "tasklist.exe"}, "cmd_line": "tasklist.exe /v"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "WMIC Process Discovery", "expected_alert": true, "rule_uid": "42ac3a50-9a37-4862-a1e8-6aec1b8b786f"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe process list brief"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "42ac3a50-9a37-4862-a1e8-6aec1b8b786f"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\tasklist.exe", "name": "tasklist.exe"}, "cmd_line": "tasklist.exe /v"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "42ac3a50-9a37-4862-a1e8-6aec1b8b786f"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\tasklist.exe", "name": "tasklist.exe"}, "cmd_line": "tasklist.exe /v"}, "time": 1718000100}
```
""",

    "AN0240-T1518.002-DET0088.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: PowerShell Backup Discovery (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes a query for `Veeam`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: SC Query Backup Discovery (Rule 1)
  * The Log: Process Activity where `sc.exe` queries `WBENGINE`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal SC Query
  * The Log: Process Activity where `sc.exe` queries `eventlog`.
  * Expected Outcome: Does not match backup product flags. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal SC Query", "expected_alert": false, "rule_uid": "55e1a399-cba0-444a-99f8-a9545d607475"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc.exe query eventlog"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "PowerShell Backup Discovery", "expected_alert": true, "rule_uid": "55e1a399-cba0-444a-99f8-a9545d607475"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Service *Veeam*"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "SC Query Backup Discovery", "expected_alert": true, "rule_uid": "55e1a399-cba0-444a-99f8-a9545d607475"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc.exe query WBENGINE"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "55e1a399-cba0-444a-99f8-a9545d607475"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Service *Veeam*"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "55e1a399-cba0-444a-99f8-a9545d607475"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Service *Veeam*"}, "time": 1718000100}
```
""",
    
    "AN0254-T1033-DET0093.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Whoami Execution (Rule 1)
  * The Log: Process Activity where `whoami.exe` is executed.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: PowerShell Get-LocalUser (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes `Get-LocalUser`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal System Utility Execution
  * The Log: Process Activity where `net.exe` executes `start service`.
  * Expected Outcome: Does not match user discovery flags. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal System Utility Execution", "expected_alert": false, "rule_uid": "c6fff3c0-354a-42c2-962d-bbfd96eb62e6"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Whoami Execution", "expected_alert": true, "rule_uid": "c6fff3c0-354a-42c2-962d-bbfd96eb62e6"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\whoami.exe", "name": "whoami.exe"}, "cmd_line": "whoami.exe /all"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "PowerShell Get-LocalUser", "expected_alert": true, "rule_uid": "c6fff3c0-354a-42c2-962d-bbfd96eb62e6"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-LocalUser"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "c6fff3c0-354a-42c2-962d-bbfd96eb62e6"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\whoami.exe", "name": "whoami.exe"}, "cmd_line": "whoami.exe /all"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "c6fff3c0-354a-42c2-962d-bbfd96eb62e6"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\whoami.exe", "name": "whoami.exe"}, "cmd_line": "whoami.exe /all"}, "time": 1718000100}
```
""",

    "AN0271-T1010-DET0097.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: PowerShell Window Enumeration (Rule 2)
  * The Log: Process Activity where `powershell.exe` executes a command containing `EnumWindows`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: CScript Window Enumeration (Rule 2)
  * The Log: Process Activity where `cscript.exe` executes a script containing `GetForegroundWindow`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 2)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 2)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal PowerShell Execution
  * The Log: Process Activity where `powershell.exe` executes `Get-Process`.
  * Expected Outcome: Does not match window enumeration keywords. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal PowerShell Execution", "expected_alert": false, "rule_uid": "b47fdf13-ec32-4e2b-9ca9-adfc0157cf89"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Process"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "PowerShell Window Enumeration", "expected_alert": true, "rule_uid": "b47fdf13-ec32-4e2b-9ca9-adfc0157cf89"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command \\"[DllImport('user32.dll')] public static extern bool EnumWindows(int a, int b);\\""}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "CScript Window Enumeration", "expected_alert": true, "rule_uid": "b47fdf13-ec32-4e2b-9ca9-adfc0157cf89"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\cscript.exe", "name": "cscript.exe"}, "cmd_line": "cscript.exe script.vbs GetForegroundWindow"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "b47fdf13-ec32-4e2b-9ca9-adfc0157cf89"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command \\"[DllImport('user32.dll')] public static extern bool EnumWindows(int a, int b);\\""}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "b47fdf13-ec32-4e2b-9ca9-adfc0157cf89"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command \\"[DllImport('user32.dll')] public static extern bool EnumWindows(int a, int b);\\""}, "time": 1718000100}
```
""",

    "AN0455-T1201-DET0161.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Net Accounts Command (Rule 1)
  * The Log: Process Activity where `net.exe` is executed with `accounts`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: Secedit Export Command (Rule 1)
  * The Log: Process Activity where `secedit.exe` is executed with `/export`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 3: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 4: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start wuauserv`.
  * Expected Outcome: Does not match policy discovery flags. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "a5745601-f38f-45f4-b908-edf1345decb1"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Net Accounts Command", "expected_alert": true, "rule_uid": "a5745601-f38f-45f4-b908-edf1345decb1"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe accounts"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Secedit Export Command", "expected_alert": true, "rule_uid": "a5745601-f38f-45f4-b908-edf1345decb1"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\secedit.exe", "name": "secedit.exe"}, "cmd_line": "secedit.exe /export /cfg C:\\\\temp\\\\sec.inf"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "a5745601-f38f-45f4-b908-edf1345decb1"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe accounts"}, "time": 1718000120}
{"metadata": {"test_case": "TP-04", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "a5745601-f38f-45f4-b908-edf1345decb1"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe accounts"}, "time": 1718000100}
```
""",

    "AN2076-T1007-DET0933.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: SC Query Command (Rule 1)
  * The Log: Process Activity where `sc.exe` is executed with `query`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal SC Command
  * The Log: Process Activity where `sc.exe` executes `start wuauserv`.
  * Expected Outcome: Does not match discovery query flag. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal SC Command", "expected_alert": false, "rule_uid": "cdef9001-a189-4db8-bb9a-7c9802cf0040"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "SC Query Command", "expected_alert": true, "rule_uid": "cdef9001-a189-4db8-bb9a-7c9802cf0040"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc.exe query type= service"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "cdef9001-a189-4db8-bb9a-7c9802cf0040"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc.exe query type= service"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "cdef9001-a189-4db8-bb9a-7c9802cf0040"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc.exe query type= service"}, "time": 1718000100}
```
""",

    "AN2077-T1012-DET0934.md": """
### 4. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Reg Query LSA (Rule 1)
  * The Log: Process Activity where `reg.exe` is executed with `query` on `LSA`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.

* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is passed as a string `"1"`.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.

* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Reg Query
  * The Log: Process Activity where `reg.exe` executes a query on a harmless key.
  * Expected Outcome: Does not match sensitive hives. MUST NOT trigger an alert.

---

### 5. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Reg Query", "expected_alert": false, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0041"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg.exe query HKLM\\\\SOFTWARE\\\\Microsoft\\\\Windows"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Reg Query LSA", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0041"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg.exe query HKLM\\\\SYSTEM\\\\CurrentControlSet\\\\Control\\\\LSA"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0041"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg.exe query HKLM\\\\SYSTEM\\\\CurrentControlSet\\\\Control\\\\LSA"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0041"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg.exe query HKLM\\\\SYSTEM\\\\CurrentControlSet\\\\Control\\\\LSA"}, "time": 1718000100}
```
"""
}

for filename, content in append_data.items():
    filepath = os.path.join(rules_dir, filename)
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(content)

print(f"Appended test cases to {len(append_data)} files successfully.")
