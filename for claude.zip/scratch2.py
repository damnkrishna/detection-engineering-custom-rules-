import os
import re

rules_dir = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\discovery"

updates = {
    "AN2078-T1016-DET0935.md": {
        "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0042",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: System Network Configuration Enumeration (OCSF-Normalized)
id: cbdf2001-a189-4db8-bb9a-7c9802cf0042
status: experimental
description: Detects execution of ipconfig, arp, route, or nbtstat to gather network information, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\ipconfig.exe'
            - '\\arp.exe'
            - '\\route.exe'
            - '\\nbtstat.exe'
    selection_cli:
        process.cmd_line|contains:
            - '/all'
            - '-a'
            - 'print'
            - '-n'
    condition: selection_images and selection_cli
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1016
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: IPConfig All (Rule 1)
  * The Log: Process Activity where `ipconfig.exe` executes with `/all`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal IPConfig
  * The Log: Process Activity where `ipconfig.exe` executes without args.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal IPConfig", "expected_alert": false, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0042"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\ipconfig.exe", "name": "ipconfig.exe"}, "cmd_line": "ipconfig.exe"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "IPConfig All", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0042"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\ipconfig.exe", "name": "ipconfig.exe"}, "cmd_line": "ipconfig.exe /all"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0042"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\ipconfig.exe", "name": "ipconfig.exe"}, "cmd_line": "ipconfig.exe /all"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0042"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\ipconfig.exe", "name": "ipconfig.exe"}, "cmd_line": "ipconfig.exe /all"}, "time": 1718000100}
```
"""
    },
    
    "AN2079-T1018-DET0936.md": {
        "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0043",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Remote System Discovery via Native Tools (OCSF-Normalized)
id: f023d881-819a-44f2-9ca0-80ef522f0043
status: experimental
description: Detects command-line utilities querying the domain for computer objects or domain controllers, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\nltest.exe'
            - '\\net.exe'
            - '\\net1.exe'
    selection_cli:
        process.cmd_line|contains:
            - '/dclist:'
            - '/domain_trusts'
            - ' view'
    condition: selection_images and selection_cli
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1018
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: NLTest DCList (Rule 1)
  * The Log: Process Activity where `nltest.exe` executes with `/dclist:`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start wuauserv`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0043"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "NLTest DCList", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0043"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /dclist:corp.local"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0043"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /dclist:corp.local"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0043"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\nltest.exe", "name": "nltest.exe"}, "cmd_line": "nltest.exe /dclist:corp.local"}, "time": 1718000100}
```
"""
    },
    
    "AN2080-T1046-DET0937.md": {
        "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0044",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Local Network Service Port Discovery (OCSF-Normalized)
id: cbdf2001-a189-4db8-bb9a-7c9802cf0044
status: experimental
description: Detects command-line execution of netstat to enumerate active listening ports, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_image:
        process.file.path|endswith:
            - '\\netstat.exe'
    selection_cli:
        process.cmd_line|contains:
            - '-an'
            - '-ano'
            - '-anbo'
            - '-na'
    condition: selection_image and selection_cli
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1046
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Netstat Execution (Rule 1)
  * The Log: Process Activity where `netstat.exe` executes with `-ano`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Netstat
  * The Log: Process Activity where `netstat.exe` executes without args.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Netstat", "expected_alert": false, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0044"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\netstat.exe", "name": "netstat.exe"}, "cmd_line": "netstat.exe"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Netstat Execution", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0044"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\netstat.exe", "name": "netstat.exe"}, "cmd_line": "netstat.exe -ano"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0044"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\netstat.exe", "name": "netstat.exe"}, "cmd_line": "netstat.exe -ano"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0044"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\netstat.exe", "name": "netstat.exe"}, "cmd_line": "netstat.exe -ano"}, "time": 1718000100}
```
"""
    },
    
    "AN2081-T1049-DET0938.md": {
        "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0045",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: SMB Share and Session Discovery (OCSF-Normalized)
id: f023d881-819a-44f2-9ca0-80ef522f0045
status: experimental
description: Detects the use of net.exe to enumerate active SMB connections or open sessions, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_image:
        process.file.path|endswith:
            - '\\net.exe'
            - '\\net1.exe'
    selection_cli:
        process.cmd_line|contains:
            - ' use'
            - ' session'
    condition: selection_image and selection_cli
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1049
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Net Use Command (Rule 1)
  * The Log: Process Activity where `net.exe` executes with `use`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0045"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Net Use Command", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0045"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe use"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0045"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe use"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0045"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe use"}, "time": 1718000100}
```
"""
    },
    
    "AN2082-T1069-DET0939.md": {
        "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0046",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Local and Domain Group Discovery (OCSF-Normalized)
id: cbdf2001-a189-4db8-bb9a-7c9802cf0046
status: experimental
description: Detects command-line utilities querying local or domain administrative groups, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\net.exe'
            - '\\net1.exe'
            - '\\dsquery.exe'
    selection_cli:
        process.cmd_line|contains:
            - ' localgroup'
            - ' group '
    selection_targets:
        process.cmd_line|contains:
            - 'administrators'
            - 'domain admins'
            - 'enterprise admins'
    condition: selection_images and selection_cli and selection_targets
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1069
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Net Localgroup Administrators (Rule 1)
  * The Log: Process Activity where `net.exe` executes `localgroup administrators`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0046"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Net Localgroup Administrators", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0046"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe localgroup administrators"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0046"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe localgroup administrators"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0046"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe localgroup administrators"}, "time": 1718000100}
```
"""
    },
    
    "AN2083-T1082-DET0940.md": {
        "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0047",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: System and Hardware Information Enumeration (OCSF-Normalized)
id: f023d881-819a-44f2-9ca0-80ef522f0047
status: experimental
description: Detects command-line utilities extracting detailed system, patch, and OS information, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_sysinfo:
        process.file.path|endswith:
            - '\\systeminfo.exe'
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_args:
        process.cmd_line|contains:
            - ' qfe '
            - ' os get '
            - ' logicaldisk '
            - ' computersystem '
    condition: selection_sysinfo or (selection_wmic and selection_wmic_args)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1082
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: SystemInfo Execution (Rule 1)
  * The Log: Process Activity where `systeminfo.exe` is executed.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal WMIC Execution
  * The Log: Process Activity where `wmic.exe` executes `process list`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal WMIC Execution", "expected_alert": false, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0047"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wbem\\\\wmic.exe", "name": "wmic.exe"}, "cmd_line": "wmic.exe process list"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "SystemInfo Execution", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0047"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\systeminfo.exe", "name": "systeminfo.exe"}, "cmd_line": "systeminfo.exe"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0047"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\systeminfo.exe", "name": "systeminfo.exe"}, "cmd_line": "systeminfo.exe"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0047"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\systeminfo.exe", "name": "systeminfo.exe"}, "cmd_line": "systeminfo.exe"}, "time": 1718000100}
```
"""
    },
    
    "AN2084-T1083-DET0941.md": {
        "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0048",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Recursive Directory Enumeration (OCSF-Normalized)
id: cbdf2001-a189-4db8-bb9a-7c9802cf0048
status: experimental
description: Detects command-line operations performing recursive directory listings, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_cmd:
        process.file.path|endswith:
            - '\\cmd.exe'
    selection_cmd_args:
        process.cmd_line|contains:
            - 'dir /s'
            - 'tree /F'
    selection_tree:
        process.file.path|endswith:
            - '\\tree.com'
    condition: (selection_cmd and selection_cmd_args) or selection_tree
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1083
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Dir /s Execution (Rule 1)
  * The Log: Process Activity where `cmd.exe` executes `dir /s`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Cmd Execution
  * The Log: Process Activity where `cmd.exe` executes `/c echo hello`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Cmd Execution", "expected_alert": false, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0048"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\cmd.exe", "name": "cmd.exe"}, "cmd_line": "cmd.exe /c echo hello"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Dir /s Execution", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0048"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\cmd.exe", "name": "cmd.exe"}, "cmd_line": "cmd.exe /c dir /s C:\\\\"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0048"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\cmd.exe", "name": "cmd.exe"}, "cmd_line": "cmd.exe /c dir /s C:\\\\"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0048"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\cmd.exe", "name": "cmd.exe"}, "cmd_line": "cmd.exe /c dir /s C:\\\\"}, "time": 1718000100}
```
"""
    },
    
    "AN2085-T1087-DET0942.md": {
        "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0049",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Local and Domain Account Enumeration (OCSF-Normalized)
id: f023d881-819a-44f2-9ca0-80ef522f0049
status: experimental
description: Detects command-line execution of net user, net accounts, or dsquery user to enumerate accounts, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\net.exe'
            - '\\net1.exe'
            - '\\dsquery.exe'
    selection_cli:
        process.cmd_line|contains:
            - ' user '
            - ' users '
            - ' accounts '
    condition: selection_images and selection_cli
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1087
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Net User Execution (Rule 1)
  * The Log: Process Activity where `net.exe` executes `net user`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start wuauserv`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0049"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Net User Execution", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0049"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net user admin"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0049"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net user admin"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "f023d881-819a-44f2-9ca0-80ef522f0049"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net user admin"}, "time": 1718000100}
```
"""
    },
    
    "AN2086-T1120-DET0943.md": {
        "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0050",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Peripheral Device Discovery via PowerShell or WMI (OCSF-Normalized)
id: cbdf2001-a189-4db8-bb9a-7c9802cf0050
status: experimental
description: Detects command-line execution or PowerShell script blocks querying Win32_PnPEntity, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-06-30
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_cli:
        process.cmd_line|contains:
            - 'path win32_pnpentity'
    selection_powershell:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_cli:
        process.cmd_line|contains:
            - 'Get-PnpDevice'
            - 'Win32_PnPEntity'
    condition: (selection_wmic and selection_wmic_cli) or (selection_powershell and selection_ps_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1120
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: PowerShell PnpDevice (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes `Get-PnpDevice`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal PowerShell Execution
  * The Log: Process Activity where `powershell.exe` executes `Get-Process`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal PowerShell Execution", "expected_alert": false, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0050"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Process"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "PowerShell PnpDevice", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0050"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-PnpDevice"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0050"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-PnpDevice"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "cbdf2001-a189-4db8-bb9a-7c9802cf0050"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-PnpDevice"}, "time": 1718000100}
```
"""
    },
    
    "AN2087-T1135-DET0944.md": {
        "rule_uid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Network Share Enumeration via Native Tools (OCSF-Normalized)
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
status: experimental
description: Detects execution of net.exe or net1.exe to list network shares on local or remote systems, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\net.exe'
            - '\\net1.exe'
    selection_cli:
        process.cmd_line|re:
            - '(?i)\\bnet(1)?\\s+(share|view)\\b'
    filter_logon:
        unmapped.parent_cmd_line|contains: '\\NETLOGON\\'
    condition: selection_images and selection_cli and not filter_logon
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
    - unmapped.parent_cmd_line
level: medium
tags:
    - attack.discovery
    - attack.t1135
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Net Share Command (Rule 1)
  * The Log: Process Activity where `net.exe` executes `net share`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start wuauserv`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Net Share Command", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net share"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net share"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net share"}, "time": 1718000100}
```
"""
    }
}

for filename, data in updates.items():
    filepath = os.path.join(rules_dir, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    
    # We use a lambda to avoid backslash escaping issues in the replacement string
    def replace_fn(match):
        return data['ocsf'] + '\n---\n\n### 4. Blind Spots & Tuning (The "Problems")\n'
    
    new_content = re.sub(
        r'### 3\.\s*Blind Spots.*?\n', 
        replace_fn, 
        content, 
        flags=re.IGNORECASE
    )
    
    new_content = new_content + "\n---\n\n" + data['test_cases']
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(new_content)

print(f"Updated {len(updates)} files with OCSF and Test Cases.")
