import os
import re

rules_dir = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\discovery"

updates = {
    "AN2088-T1614-DET0945.md": {
        "rule_uid": "b2c3d4e5-f6a7-8901-bcde-f01234567891",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: System Locale and Keyboard Layout Discovery (OCSF-Normalized)
id: b2c3d4e5-f6a7-8901-bcde-f01234567891
status: experimental
description: Detects command-line queries of Windows locale, keyboard layout, or timezone registry keys used to determine system geographic location, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_reg:
        process.file.path|endswith:
            - '\\reg.exe'
    selection_reg_cli:
        process.cmd_line|contains:
            - 'International'
            - 'Keyboard Layout'
            - 'TimeZoneInformation'
    selection_ps:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_cli:
        process.cmd_line|contains:
            - 'Get-Culture'
            - 'Get-WinSystemLocale'
            - 'CurrentCulture'
            - 'TimeZone'
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_cli:
        process.cmd_line|contains:
            - 'os get locale'
    condition: (selection_reg and selection_reg_cli) or (selection_ps and selection_ps_cli) or (selection_wmic and selection_wmic_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1614
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Powershell Get-Culture (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes `Get-Culture`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Powershell
  * The Log: Process Activity where `powershell.exe` executes `Get-Process`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Powershell", "expected_alert": false, "rule_uid": "b2c3d4e5-f6a7-8901-bcde-f01234567891"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Process"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Powershell Get-Culture", "expected_alert": true, "rule_uid": "b2c3d4e5-f6a7-8901-bcde-f01234567891"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-Culture"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "b2c3d4e5-f6a7-8901-bcde-f01234567891"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-Culture"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "b2c3d4e5-f6a7-8901-bcde-f01234567891"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-Culture"}, "time": 1718000100}
```
"""
    },
    
    "AN2089-T1124-DET0946.md": {
        "rule_uid": "c3d4e5f6-a7b8-9012-cdef-012345678902",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: System Time and Timezone Discovery (OCSF-Normalized)
id: c3d4e5f6-a7b8-9012-cdef-012345678902
status: experimental
description: Detects command-line queries for system time or timezone information, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_net:
        process.file.path|endswith:
            - '\\net.exe'
            - '\\net1.exe'
    selection_net_cli:
        process.cmd_line|re:
            - '(?i)\\bnet(1)?\\s+time\\b'
    filter_ntp:
        unmapped.parent_file_path|endswith: '\\w32tm.exe'
    selection_w32tm:
        process.file.path|endswith:
            - '\\w32tm.exe'
    selection_w32tm_cli:
        process.cmd_line|contains:
            - '/query'
            - '/tz'
    condition: ((selection_net and selection_net_cli) or (selection_w32tm and selection_w32tm_cli)) and not filter_ntp
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1124
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Net Time Command (Rule 1)
  * The Log: Process Activity where `net.exe` executes `net time`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Net Command
  * The Log: Process Activity where `net.exe` executes `start wuauserv`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Net Command", "expected_alert": false, "rule_uid": "c3d4e5f6-a7b8-9012-cdef-012345678902"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net.exe start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Net Time Command", "expected_alert": true, "rule_uid": "c3d4e5f6-a7b8-9012-cdef-012345678902"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net time \\\\\\\\dc01"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "c3d4e5f6-a7b8-9012-cdef-012345678902"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net time \\\\\\\\dc01"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "c3d4e5f6-a7b8-9012-cdef-012345678902"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\net.exe", "name": "net.exe"}, "cmd_line": "net time \\\\\\\\dc01"}, "time": 1718000100}
```
"""
    },
    
    "AN2090-T1615-DET0947.md": {
        "rule_uid": "d4e5f6a7-b8c9-0123-def0-123456789003",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Group Policy Enumeration (OCSF-Normalized)
id: d4e5f6a7-b8c9-0123-def0-123456789003
status: experimental
description: Detects command-line utilities enumerating Group Policy Objects (GPOs), mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_gpresult:
        process.file.path|endswith:
            - '\\gpresult.exe'
    selection_gpresult_cli:
        process.cmd_line|contains:
            - '/r'
            - '/z'
            - '/scope'
    selection_ps:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_cli:
        process.cmd_line|contains:
            - 'Get-GPO'
            - 'Get-GPResultantSetOfPolicy'
            - 'Get-DomainGPO'
    condition: (selection_gpresult and selection_gpresult_cli) or (selection_ps and selection_ps_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1615
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: GPResult Execution (Rule 1)
  * The Log: Process Activity where `gpresult.exe` executes with `/r`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal GPResult
  * The Log: Process Activity where `gpresult.exe` executes without args.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal GPResult", "expected_alert": false, "rule_uid": "d4e5f6a7-b8c9-0123-def0-123456789003"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\gpresult.exe", "name": "gpresult.exe"}, "cmd_line": "gpresult.exe"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "GPResult Execution", "expected_alert": true, "rule_uid": "d4e5f6a7-b8c9-0123-def0-123456789003"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\gpresult.exe", "name": "gpresult.exe"}, "cmd_line": "gpresult.exe /r"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "d4e5f6a7-b8c9-0123-def0-123456789003"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\gpresult.exe", "name": "gpresult.exe"}, "cmd_line": "gpresult.exe /r"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "d4e5f6a7-b8c9-0123-def0-123456789003"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\gpresult.exe", "name": "gpresult.exe"}, "cmd_line": "gpresult.exe /r"}, "time": 1718000100}
```
"""
    },
    
    "AN2091-T1654-DET0948.md": {
        "rule_uid": "e5f6a7b8-c9d0-1234-ef01-234567890004",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Windows Event Log Enumeration (OCSF-Normalized)
id: e5f6a7b8-c9d0-1234-ef01-234567890004
status: experimental
description: Detects command-line utilities enumerating or exporting Windows event logs, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_wevtutil:
        process.file.path|endswith:
            - '\\wevtutil.exe'
    selection_wevtutil_cli:
        process.cmd_line|re:
            - '(?i)wevtutil(\\.exe)?\\s+(el|gl|qe|epl)\\b'
    selection_ps:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_cli:
        process.cmd_line|contains:
            - 'Get-EventLog'
            - 'Get-WinEvent'
    condition: (selection_wevtutil and selection_wevtutil_cli) or (selection_ps and selection_ps_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1654
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Wevtutil Execution (Rule 1)
  * The Log: Process Activity where `wevtutil.exe` executes `wevtutil el`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Wevtutil
  * The Log: Process Activity where `wevtutil.exe` executes `wevtutil im`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Wevtutil", "expected_alert": false, "rule_uid": "e5f6a7b8-c9d0-1234-ef01-234567890004"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wevtutil.exe", "name": "wevtutil.exe"}, "cmd_line": "wevtutil im"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Wevtutil Execution", "expected_alert": true, "rule_uid": "e5f6a7b8-c9d0-1234-ef01-234567890004"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wevtutil.exe", "name": "wevtutil.exe"}, "cmd_line": "wevtutil el"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "e5f6a7b8-c9d0-1234-ef01-234567890004"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wevtutil.exe", "name": "wevtutil.exe"}, "cmd_line": "wevtutil el"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "e5f6a7b8-c9d0-1234-ef01-234567890004"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\wevtutil.exe", "name": "wevtutil.exe"}, "cmd_line": "wevtutil el"}, "time": 1718000100}
```
"""
    },
    
    "AN2092-T1652-DET0949.md": {
        "rule_uid": "f6a7b8c9-d0e1-2345-f012-345678900005",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Device Driver Enumeration (OCSF-Normalized)
id: f6a7b8c9-d0e1-2345-f012-345678900005
status: experimental
description: Detects command-line utilities enumerating installed device drivers, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_driverquery:
        process.file.path|endswith:
            - '\\driverquery.exe'
    selection_sc:
        process.file.path|endswith:
            - '\\sc.exe'
    selection_sc_cli:
        process.cmd_line|contains:
            - ' query type= driver'
            - ' query type=driver'
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_cli:
        process.cmd_line|contains: 'sysdriver'
    condition: selection_driverquery or (selection_sc and selection_sc_cli) or (selection_wmic and selection_wmic_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1652
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Driverquery Execution (Rule 1)
  * The Log: Process Activity where `driverquery.exe` is executed.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal SC Command
  * The Log: Process Activity where `sc.exe` executes `sc start wuauserv`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal SC Command", "expected_alert": false, "rule_uid": "f6a7b8c9-d0e1-2345-f012-345678900005"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\sc.exe", "name": "sc.exe"}, "cmd_line": "sc start wuauserv"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Driverquery Execution", "expected_alert": true, "rule_uid": "f6a7b8c9-d0e1-2345-f012-345678900005"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\driverquery.exe", "name": "driverquery.exe"}, "cmd_line": "driverquery.exe"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "f6a7b8c9-d0e1-2345-f012-345678900005"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\driverquery.exe", "name": "driverquery.exe"}, "cmd_line": "driverquery.exe"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "f6a7b8c9-d0e1-2345-f012-345678900005"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\driverquery.exe", "name": "driverquery.exe"}, "cmd_line": "driverquery.exe"}, "time": 1718000100}
```
"""
    },
    
    "AN2093-T1040-DET0950.md": {
        "rule_uid": "a7b8c9d0-e1f2-3456-0123-456789000006",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Network Packet Capture Tool Execution (OCSF-Normalized)
id: a7b8c9d0-e1f2-3456-0123-456789000006
status: experimental
description: Detects the execution of network packet capture binaries such as tshark or tcpdump on a Windows host, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\tshark.exe'
            - '\\windump.exe'
            - '\\tcpdump.exe'
            - '\\rawcap.exe'
            - '\\pktmon.exe'
    condition: selection_images
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.discovery
    - attack.t1040
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: TShark Execution (Rule 1)
  * The Log: Process Activity where `tshark.exe` is executed.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Wireshark
  * The Log: Process Activity where `wireshark.exe` executes (GUI).
  * Expected Outcome: Does not match discovery flags (only CLI tools). MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Wireshark", "expected_alert": false, "rule_uid": "a7b8c9d0-e1f2-3456-0123-456789000006"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Program Files\\\\Wireshark\\\\wireshark.exe", "name": "wireshark.exe"}, "cmd_line": "wireshark.exe"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "TShark Execution", "expected_alert": true, "rule_uid": "a7b8c9d0-e1f2-3456-0123-456789000006"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Program Files\\\\Wireshark\\\\tshark.exe", "name": "tshark.exe"}, "cmd_line": "tshark.exe -i 1"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "a7b8c9d0-e1f2-3456-0123-456789000006"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Program Files\\\\Wireshark\\\\tshark.exe", "name": "tshark.exe"}, "cmd_line": "tshark.exe -i 1"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "a7b8c9d0-e1f2-3456-0123-456789000006"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Program Files\\\\Wireshark\\\\tshark.exe", "name": "tshark.exe"}, "cmd_line": "tshark.exe -i 1"}, "time": 1718000100}
```
"""
    },
    
    "AN2094-T1497-DET0951.md": {
        "rule_uid": "b8c9d0e1-f2a3-4567-1234-567890000007",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: VM and Sandbox Detection Artifact Queries (OCSF-Normalized)
id: b8c9d0e1-f2a3-4567-1234-567890000007
status: experimental
description: Detects command-line queries for artifacts commonly checked by malware to detect virtual machine environments, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_reg:
        process.file.path|endswith:
            - '\\reg.exe'
    selection_reg_cli:
        process.cmd_line|contains:
            - 'VirtualBox'
            - 'VMware'
            - 'VBOX'
            - 'QEMU'
            - 'Hyper-V'
            - 'Xen'
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_cli:
        process.cmd_line|contains:
            - 'VBOX'
            - 'VMware'
            - 'VirtualBox'
            - 'biosseralnum'
    filter_hyperv_admin:
        unmapped.parent_file_path|endswith:
            - '\\vmconnect.exe'
            - '\\vmms.exe'
    condition: ((selection_reg and selection_reg_cli) or (selection_wmic and selection_wmic_cli)) and not filter_hyperv_admin
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.defense_evasion
    - attack.discovery
    - attack.t1497
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Reg Query VMware (Rule 1)
  * The Log: Process Activity where `reg.exe` executes querying `VMware`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Reg Query
  * The Log: Process Activity where `reg.exe` queries a benign key.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Reg Query", "expected_alert": false, "rule_uid": "b8c9d0e1-f2a3-4567-1234-567890000007"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query HKLM\\\\Software"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Reg Query VMware", "expected_alert": true, "rule_uid": "b8c9d0e1-f2a3-4567-1234-567890000007"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query HKLM\\\\HARDWARE\\\\DESCRIPTION\\\\System\\\\BIOS /v SystemManufacturer | findstr VMware"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "b8c9d0e1-f2a3-4567-1234-567890000007"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query HKLM\\\\HARDWARE\\\\DESCRIPTION\\\\System\\\\BIOS /v SystemManufacturer | findstr VMware"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "b8c9d0e1-f2a3-4567-1234-567890000007"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query HKLM\\\\HARDWARE\\\\DESCRIPTION\\\\System\\\\BIOS /v SystemManufacturer | findstr VMware"}, "time": 1718000100}
```
"""
    },
    
    "AN2095-T1673-DET0952.md": {
        "rule_uid": "c9d0e1f2-a3b4-5678-2345-678900000008",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Virtual Machine Infrastructure Enumeration (OCSF-Normalized)
id: c9d0e1f2-a3b4-5678-2345-678900000008
status: experimental
description: Detects the use of PowerShell or WMI to enumerate virtual machine infrastructure, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_ps:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_cli:
        process.cmd_line|contains:
            - 'Get-VM'
            - 'Get-VMHost'
            - 'Get-VirtualMachine'
            - 'Get-SCVirtualMachine'
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_cli:
        process.cmd_line|contains:
            - 'HypervisorPresent'
            - 'Msvm_ComputerSystem'
            - 'Win32_VirtualSystemManagementService'
    condition: (selection_ps and selection_ps_cli) or (selection_wmic and selection_wmic_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.discovery
    - attack.t1673
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: PowerShell Get-VM (Rule 1)
  * The Log: Process Activity where `powershell.exe` executes `Get-VM`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal PowerShell
  * The Log: Process Activity where `powershell.exe` executes `Get-Process`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal PowerShell", "expected_alert": false, "rule_uid": "c9d0e1f2-a3b4-5678-2345-678900000008"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe Get-Process"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "PowerShell Get-VM", "expected_alert": true, "rule_uid": "c9d0e1f2-a3b4-5678-2345-678900000008"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-VM"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "c9d0e1f2-a3b4-5678-2345-678900000008"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-VM"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "c9d0e1f2-a3b4-5678-2345-678900000008"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\powershell.exe", "name": "powershell.exe"}, "cmd_line": "powershell.exe -Command Get-VM"}, "time": 1718000100}
```
"""
    },
    
    "AN2096-T1680-DET0953.md": {
        "rule_uid": "d0e1f2a3-b4c5-6789-3456-789000000009",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Local Storage Device Enumeration (OCSF-Normalized)
id: d0e1f2a3-b4c5-6789-3456-789000000009
status: experimental
description: Detects the use of fsutil or WMIC to enumerate local storage volumes and drives, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_fsutil:
        process.file.path|endswith:
            - '\\fsutil.exe'
    selection_fsutil_cli:
        process.cmd_line|contains:
            - ' fsinfo drives'
    selection_wmic:
        process.file.path|endswith:
            - '\\wmic.exe'
    selection_wmic_cli:
        process.cmd_line|contains:
            - ' logicaldisk '
            - ' diskdrive '
    filter_inventory:
        unmapped.parent_file_path|endswith: '\\ccmexec.exe'
    condition: ((selection_fsutil and selection_fsutil_cli) or (selection_wmic and selection_wmic_cli)) and not filter_inventory
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: low
tags:
    - attack.discovery
    - attack.t1680
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: FSUtil Drives (Rule 1)
  * The Log: Process Activity where `fsutil.exe` executes `fsinfo drives`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal FSUtil
  * The Log: Process Activity where `fsutil.exe` executes `dirty query`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal FSUtil", "expected_alert": false, "rule_uid": "d0e1f2a3-b4c5-6789-3456-789000000009"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\fsutil.exe", "name": "fsutil.exe"}, "cmd_line": "fsutil dirty query C:"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "FSUtil Drives", "expected_alert": true, "rule_uid": "d0e1f2a3-b4c5-6789-3456-789000000009"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\fsutil.exe", "name": "fsutil.exe"}, "cmd_line": "fsutil fsinfo drives"}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "d0e1f2a3-b4c5-6789-3456-789000000009"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\fsutil.exe", "name": "fsutil.exe"}, "cmd_line": "fsutil fsinfo drives"}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "d0e1f2a3-b4c5-6789-3456-789000000009"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\fsutil.exe", "name": "fsutil.exe"}, "cmd_line": "fsutil fsinfo drives"}, "time": 1718000100}
```
"""
    },
    
    "AN2097-T1622-DET0954.md": {
        "rule_uid": "e1f2a3b4-c5d6-7890-4567-890000000010",
        "ocsf": """### 3. OCSF Normalized Rule

```xml
title: Debugger Presence Check via Registry or Process Query (OCSF-Normalized)
id: e1f2a3b4-c5d6-7890-4567-890000000010
status: experimental
description: Detects command-line queries targeting debugger artifacts in the registry, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_reg:
        process.file.path|endswith:
            - '\\reg.exe'
    selection_reg_cli:
        process.cmd_line|contains:
            - 'Image File Execution Options'
            - 'AeDebug'
            - 'GlobalFlag'
            - 'postmortem'
    condition: selection_reg and selection_reg_cli
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: medium
tags:
    - attack.defense_evasion
    - attack.t1622
```
""",
        "test_cases": """### 5. Test Cases (Engine Pipeline Verification)

#### True Positives
* True Positive 1: Reg Query AeDebug (Rule 1)
  * The Log: Process Activity where `reg.exe` queries `AeDebug`.
  * Expected Outcome: Matches rule criteria. MUST trigger an alert.
* True Positive 2: Schema Type Validation Failure (Rule 1)
  * The Log: Exact match of TP-01, but `activity_id` is a string.
  * Expected Outcome: Engine parser should coerce gracefully. MUST trigger an alert.
* True Positive 3: Exact Duplicate Event (Rule 1)
  * The Log: Exact duplicate of TP-01 with the same timestamp.
  * Expected Outcome: Engine deduplication test.

#### Benign / True Negatives
* Benign 1: Normal Reg Query
  * The Log: Process Activity where `reg.exe` queries `HKLM\\Software`.
  * Expected Outcome: Does not match discovery flags. MUST NOT trigger an alert.

---

### 6. Raw Telemetry Dataset (OCSF JSON)

#### Benign Telemetry
```jsonl
{"metadata": {"test_case": "TN-01", "description": "Normal Reg Query", "expected_alert": false, "rule_uid": "e1f2a3b4-c5d6-7890-4567-890000000010"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query HKLM\\\\Software"}, "time": 1718000000}
```

#### True Positive Telemetry
```jsonl
{"metadata": {"test_case": "TP-01", "description": "Reg Query AeDebug", "expected_alert": true, "rule_uid": "e1f2a3b4-c5d6-7890-4567-890000000010"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query \\\"HKLM\\\\SOFTWARE\\\\Microsoft\\\\Windows NT\\\\CurrentVersion\\\\AeDebug\\\""}, "time": 1718000100}
{"metadata": {"test_case": "TP-02", "description": "Schema Type Validation Failure", "expected_alert": true, "rule_uid": "e1f2a3b4-c5d6-7890-4567-890000000010"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": "1", "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query \\\"HKLM\\\\SOFTWARE\\\\Microsoft\\\\Windows NT\\\\CurrentVersion\\\\AeDebug\\\""}, "time": 1718000110}
{"metadata": {"test_case": "TP-03", "description": "Exact Duplicate Event", "expected_alert": true, "rule_uid": "e1f2a3b4-c5d6-7890-4567-890000000010"}, "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_id": 1, "activity_name": "Launch", "process": {"file": {"path": "C:\\\\Windows\\\\System32\\\\reg.exe", "name": "reg.exe"}, "cmd_line": "reg query \\\"HKLM\\\\SOFTWARE\\\\Microsoft\\\\Windows NT\\\\CurrentVersion\\\\AeDebug\\\""}, "time": 1718000100}
```
"""
    }
}


for filename, data in updates.items():
    filepath = os.path.join(rules_dir, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    
    def replace_fn(match):
        return data['ocsf'] + '\n---\n\n### 4. Blind Spots & Tuning (The "Problems")\n'
    
    new_content = re.sub(
        r'### 3\.\s*Blind Spots.*?\n', 
        replace_fn, 
        content, 
        flags=re.IGNORECASE
    )
    
    new_content = new_content + "\n---\n\n" + data['test_cases']
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(new_content)

print(f"Updated {len(updates)} files with OCSF and Test Cases.")
