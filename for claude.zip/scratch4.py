import os
import re

directory = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\credential-access"

# 1. Renumbering files
files_to_renumber = [
    "AN0105-T1555.003-DET0037.md",
    "AN0235-T1003.002-DET0085.md",
    "AN0292-T1110.002-DET0105.md",
    "AN0316-T1558.004-DET0113.md",
    "AN0378-T1555.004-DET0134.md",
    "AN0405-T1558.001-DET0144.md",
    "AN0420-T1606.002-DET0148.md",
    "AN0444-T1558.003-DET0157.md"
]
# Note: AN0287-T1556-DET0104 is the template, already perfect, so skipping.

def fix_renumbering(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Replacements
    content = re.sub(r'### OCSF Normalized', r'### 3. OCSF Normalized Rule', content)
    content = re.sub(r'### 3\. Blind Spots', r'### 4. Blind Spots', content)
    content = re.sub(r'### 4\. Test Cases', r'### 5. Test Cases', content)
    content = re.sub(r'### 5\. Raw Telemetry Dataset', r'### 6. Raw Telemetry Dataset', content)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

for fn in files_to_renumber:
    fp = os.path.join(directory, fn)
    if os.path.exists(fp):
        fix_renumbering(fp)
        print(f"Fixed numbering in {fn}")


# 2. Injecting OCSF for 7 files
ocsf_injections = {
    "AN2103-T1552-DET0960.md": """### 3. OCSF Normalized Rule

```xml
title: Credential String Search in Files and Registry (OCSF-Normalized)
id: 2a8c5e71-3f9b-4d26-c8e1-7b4d9a15f263
status: experimental
description: Detects findstr.exe or reg.exe being used to search for plaintext password strings in files or registry, indicating unsecured credential harvesting. Mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_findstr:
        process.file.path|endswith:
            - '\\findstr.exe'
    selection_findstr_cli:
        process.cmd_line|re:
            - '(?i)\\b(password|passwd|credentials|connectionstring)\\b'
    selection_reg:
        process.file.path|endswith:
            - '\\reg.exe'
    selection_reg_cli:
        process.cmd_line|contains:
            - 'password'
            - 'passwd'
            - 'DefaultPassword'
            - 'AutoAdminLogon'
    filter_av_scan:
        unmapped.parent_image|endswith:
            - '\\MsMpEng.exe'
            - '\\SenseCnfg.exe'
    condition: ((selection_findstr and selection_findstr_cli) or (selection_reg and selection_reg_cli)) and not filter_av_scan
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.t1552
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",

    "AN2104-T1187-DET0961.md": """### 3. OCSF Normalized Rule

```xml
title: Forced Authentication via UNC Path or SCF File Creation (OCSF-Normalized)
id: 8f3b6d94-1e7c-4a52-b9f5-2c8e4a37d582
status: experimental
description: Detects net use commands targeting non-standard shares, used to force NTLM authentication to attacker-controlled servers, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_net:
        process.file.path|endswith:
            - '\\net.exe'
            - '\\net1.exe'
    selection_net_cli:
        process.cmd_line|re:
            - '(?i)net(1)?\\s+use\\s+\\\\\\\\\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}'
    selection_ps_unc:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_unc_cli:
        process.cmd_line|re:
            - '(?i)New-PSDrive.+\\\\\\\\\\d{1,3}\\.\\d{1,3}'
    filter_internal:
        process.cmd_line|contains:
            - '\\\\10.'
            - '\\\\192.168.'
            - '\\\\172.16.'
            - '\\\\172.17.'
            - '\\\\172.18.'
            - '\\\\172.19.'
            - '\\\\172.20.'
            - '\\\\172.21.'
            - '\\\\172.22.'
            - '\\\\172.23.'
            - '\\\\172.24.'
            - '\\\\172.25.'
            - '\\\\172.26.'
            - '\\\\172.27.'
            - '\\\\172.28.'
            - '\\\\172.29.'
            - '\\\\172.30.'
            - '\\\\172.31.'
    condition: ((selection_net and selection_net_cli) or (selection_ps_unc and selection_ps_unc_cli)) and not filter_internal
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.t1187
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",

    "AN2107-T1539-DET0964.md": """### 3. OCSF Normalized Rule

```xml
title: Browser Cookie Database Access by Non-Browser Process (OCSF-Normalized)
id: 0d5e8c23-6b4f-4a79-c1e9-5f2b7d84a361
status: experimental
description: Detects processes other than browsers reading SQLite cookie databases from Chrome, Edge, or Firefox profile directories. Mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_sqlite_tools:
        process.file.path|endswith:
            - '\\sqlite3.exe'
            - '\\python.exe'
            - '\\python3.exe'
    selection_cookie_paths:
        process.cmd_line|contains:
            - 'AppData\\Local\\Google\\Chrome\\User Data'
            - 'AppData\\Local\\Microsoft\\Edge\\User Data'
            - 'AppData\\Roaming\\Mozilla\\Firefox\\Profiles'
            - '\\Cookies'
            - '\\Network\\Cookies'
    selection_ps_cookie:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_ps_cookie_cli:
        process.cmd_line|contains:
            - 'Chrome\\User Data'
            - 'Edge\\User Data'
            - 'Firefox\\Profiles'
            - 'Cookies'
    condition: (selection_sqlite_tools and selection_cookie_paths) or (selection_ps_cookie and selection_ps_cookie_cli)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.t1539
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",

    "AN2115-T1111-DET0972.md": """### 3. OCSF Normalized Rule

```xml
title: Custom Security Support Provider or LSA Package Registration (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5d98
status: experimental
description: Detects modifications to registry values under Lsa (Security Packages, Authentication Packages) or SecurityProviders, mapped to OCSF registry_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: registry_activity
detection:
    selection_registry_paths:
        registry.key|contains:
            - '\\System\\CurrentControlSet\\Control\\Lsa\\Security Packages'
            - '\\System\\CurrentControlSet\\Control\\Lsa\\Authentication Packages'
            - '\\System\\CurrentControlSet\\Control\\SecurityProviders\\SecurityProviders'
    filter_installer:
        unmapped.parent_image|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: selection_registry_paths and not filter_installer
fields:
    - registry.key
    - registry.data.content
    - process.file.path
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.t1111
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",

    "AN2118-T1212-DET0975.md": """### 3. OCSF Normalized Rule

```xml
title: Print Spooler Service Spawning Suspicious Child Process (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5d99
status: experimental
description: Detects command shells, interpreters, or system administrative utilities spawned as child processes of spoolsv.exe, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_parent:
        unmapped.parent_image|endswith:
            - '\\spoolsv.exe'
    selection_child_images:
        process.file.path|endswith:
            - '\\cmd.exe'
            - '\\powershell.exe'
            - '\\pwsh.exe'
            - '\\wscript.exe'
            - '\\cscript.exe'
            - '\\rundll32.exe'
            - '\\regsvr32.exe'
            - '\\whoami.exe'
            - '\\nltest.exe'
    condition: selection_parent and selection_child_images
fields:
    - unmapped.parent_image
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: critical
tags:
    - attack.credential_access
    - attack.t1212
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",

    "AN2123-T1649-DET0980.md": """### 3. OCSF Normalized Rule

```xml
title: Authentication Certificate or Private Key Export Tool Execution (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c84
status: experimental
description: Detects the execution of known AD CS enumeration tools (e.g. Certify) or command-line parameters attempting to export authentication certificates and private keys, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_certify:
        process.file.path|endswith: '\\certify.exe'
    selection_export_images:
        process.file.path|endswith:
            - '\\certutil.exe'
            - '\\powershell.exe'
            - '\\pwsh.exe'
    selection_export_cli:
        process.cmd_line|contains:
            - '-exportPFX'
            - '-exportpfx'
            - 'Export-PfxCertificate'
    filter_installer:
        unmapped.parent_image|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    condition: (selection_certify or (selection_export_images and selection_export_cli)) and not filter_installer
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.t1649
```

---

### 4. Blind Spots & Tuning (The "Problems")
""",

    "AN2128-T1684-DET0985.md": """### 3. OCSF Normalized Rule

```xml
title: Social Engineering Script-Based Credential Dialog Prompt (OCSF-Normalized)
id: f1a2b3c4-e5f6-7a8b-9c0d-1e2f3a4b5c89
status: experimental
description: Detects process command line arguments indicating the spawning of credential dialog boxes or login forms, mapped to OCSF process_activity.
author: Krishna Gupta
date: 2026-07-01
logsource:
    category: system
    product: ocsf
    class: process_activity
detection:
    selection_images:
        process.file.path|endswith:
            - '\\powershell.exe'
            - '\\pwsh.exe'
            - '\\mshta.exe'
            - '\\wscript.exe'
            - '\\cscript.exe'
    selection_cli:
        process.cmd_line|contains:
            - 'Get-Credential'
            - 'PromptForCredential'
    filter_installer:
        unmapped.parent_image|endswith:
            - '\\msiexec.exe'
            - '\\setup.exe'
    filter_admin_context:
        unmapped.parent_image|endswith:
            - '\\powershell_ise.exe'
            - '\\vscode\\Code.exe'
            - '\\mmc.exe'
    condition: selection_images and selection_cli and not (filter_installer or filter_admin_context)
fields:
    - process.file.path
    - process.cmd_line
    - actor.user.name
level: high
tags:
    - attack.credential_access
    - attack.t1684
```

---

### 4. Blind Spots & Tuning (The "Problems")
"""
}

def inject_ocsf(filepath, filename):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find the injection point: "### 3. Blind Spots" and replace it and below with the OCSF block + updated numbering
    content = re.sub(r'### 3\. Blind Spots & Tuning \(The "Problems"\)', ocsf_injections[filename], content)
    
    # Update the remaining sections
    content = re.sub(r'### 4\. Test Cases', r'### 5. Test Cases', content)
    content = re.sub(r'### 5\. Raw Telemetry Dataset', r'### 6. Raw Telemetry Dataset', content)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

for fn in ocsf_injections.keys():
    fp = os.path.join(directory, fn)
    if os.path.exists(fp):
        inject_ocsf(fp, fn)
        print(f"Injected OCSF in {fn}")

print("Done with all updates!")
