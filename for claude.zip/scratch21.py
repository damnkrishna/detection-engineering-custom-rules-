import os
import re
import json

directory = r"C:\Users\Sunil\OneDrive\Desktop\coorelation-rules\defense-impairment"

def get_class_payload(cls_name, category_name):
    if not cls_name or cls_name == "UNKNOWN":
        cls_name = category_name.lower().strip()
    else:
        cls_name = cls_name.lower().strip()
        
    if cls_name == "process_activity" or cls_name == "process_creation":
        return {
            "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_name": "Launch",
            "process": {"file": {"path": "C:\\Windows\\System32\\cmd.exe", "name": "cmd.exe"}},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"parent_image": "explorer.exe"}
        }
    elif cls_name == "file_activity" or cls_name == "file_creation" or cls_name == "file_event":
        return {
            "category_uid": 1, "class_uid": 1001, "class_name": "File Activity", "activity_name": "Create",
            "file": {"path": "C:\\Temp\\malware.exe", "name": "malware.exe"},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"process_image": "explorer.exe"}
        }
    elif cls_name == "network_activity":
        return {
            "category_uid": 4, "class_uid": 4001, "class_name": "Network Activity", "activity_name": "Traffic",
            "dst_endpoint": {"ip": "10.0.0.1", "port": 80}, "src_endpoint": {"ip": "192.168.1.100", "port": 50000},
            "unmapped": {"process_image": "powershell.exe"}
        }
    elif cls_name == "authentication":
        return {
            "category_uid": 3, "class_uid": 3002, "class_name": "Authentication", "activity_name": "Logon",
            "logon": {"type_id": 3, "type_name": "Network"},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"logon_process": "NtLmSsp"}
        }
    elif cls_name == "driver_activity" or cls_name == "driver_load":
        return {
            "category_uid": 1, "class_uid": 1010, "class_name": "Driver Activity", "activity_name": "Load",
            "driver": {"path": "C:\\Windows\\System32\\drivers\\malware.sys", "name": "malware.sys"},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"signature_status": "Unsigned"}
        }
    elif cls_name == "registry_key_activity" or cls_name == "registry_set" or cls_name == "registry_event" or cls_name == "registry_add":
        return {
            "category_uid": 1, "class_uid": 1011, "class_name": "Registry Key Activity", "activity_name": "Create",
            "registry": {"key": "HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", "value": "malware"},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"process_image": "reg.exe"}
        }
    elif cls_name == "account_change" or cls_name == "security":
        return {
            "category_uid": 3, "class_uid": 3001, "class_name": "Account Change", "activity_name": "Create",
            "group": {"name": "Administrators"},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"user_account_control": "Password Not Required"}
        }
    else:
        # Default fallback
        return {
            "category_uid": 1, "class_uid": 1007, "class_name": "Process Activity", "activity_name": "Launch",
            "process": {"file": {"path": "C:\\Windows\\System32\\unknown.exe"}},
            "actor": {"user": {"name": "TargetUser"}}, "unmapped": {"generic": "true"}
        }

def generate_telemetry_json(uid, title, cls_name, category_name, test_case, expected_alert, is_malformed=False, is_coercion=False, is_benign=False, time_offset=0):
    payload = get_class_payload(cls_name, category_name)
    payload["metadata"] = {
        "test_case": test_case,
        "description": f"{title} ({test_case})",
        "expected_alert": expected_alert,
        "rule_uid": uid
    }
    payload["activity_id"] = "1" if is_coercion else 1
    payload["time"] = 1718000000 + time_offset
    
    if is_malformed and "unmapped" in payload:
        del payload["unmapped"]
        
    if is_benign and "unmapped" in payload:
        payload["unmapped"]["generic"] = "benign_test"
        
    return json.dumps(payload)

def generate_test_sections(rules):
    # rules is a list of dicts: {'uid', 'title', 'class', 'category'}
    tests_md = "### 5. Test Cases (Engine Pipeline Verification)\n\n"
    
    # Generate True Positives
    tests_md += "#### True Positives\n"
    for i, r in enumerate(rules, 1):
        tests_md += f"* True Positive {i}A: Standard Execution ({r['title']})\n"
        tests_md += f"  * The Log: Activity simulating malicious behavior.\n"
        tests_md += f"  * Expected Outcome: MUST trigger an alert.\n\n"
        
        tests_md += f"* True Positive {i}B: Malformed JSON Robustness Test ({r['title']})\n"
        tests_md += f"  * The Log: Simulating {i}A but intentionally omitting the `unmapped` object entirely.\n"
        tests_md += f"  * Expected Outcome: Engine parser should degrade gracefully. MUST trigger an alert.\n\n"
        
        tests_md += f"* True Positive {i}C: Schema Type Validation Failure ({r['title']})\n"
        tests_md += f"  * The Log: Exact match of {i}A, but `activity_id` is passed as a string `\"1\"` instead of an integer `1`.\n"
        tests_md += f"  * Expected Outcome: Tests if the engine's JSON parser coerces the type gracefully. MUST trigger an alert.\n\n"
        
        tests_md += f"* True Positive {i}D: Exact Duplicate Event ({r['title']})\n"
        tests_md += f"  * The Log: Exact duplicate of {i}A with the exact same timestamp.\n"
        tests_md += f"  * Expected Outcome: Tests deduplication window.\n\n"

    # Generate Benign
    tests_md += "#### Benign / True Negatives\n"
    for i, r in enumerate(rules, 1):
        tests_md += f"* Benign {i}: Allowed Activity ({r['title']})\n"
        tests_md += f"  * The Log: Activity matching legitimate patterns.\n"
        tests_md += f"  * Expected Outcome: Matches exclusion filters. MUST NOT trigger an alert.\n\n"
        
    tests_md += "---\n\n### 6. Raw Telemetry Dataset (OCSF JSON)\n\n"
    
    tests_md += "#### Benign Telemetry\n```jsonl\n"
    for i, r in enumerate(rules, 1):
        tcode = f"TN-{i:02d}"
        tests_md += generate_telemetry_json(r['uid'], r['title'], r['class'], r['category'], tcode, False, is_benign=True, time_offset=i*10) + "\n"
    tests_md += "```\n\n"
    
    tests_md += "#### True Positive Telemetry\n```jsonl\n"
    time_counter = 100
    for i, r in enumerate(rules, 1):
        tcode = f"TP-{i:02d}"
        # A
        tests_md += generate_telemetry_json(r['uid'], r['title'], r['class'], r['category'], tcode+"A", True, time_offset=time_counter) + "\n"
        # B (Malformed)
        tests_md += generate_telemetry_json(r['uid'], r['title'], r['class'], r['category'], tcode+"B", True, is_malformed=True, time_offset=time_counter+1) + "\n"
        # C (Coercion)
        tests_md += generate_telemetry_json(r['uid'], r['title'], r['class'], r['category'], tcode+"C", True, is_coercion=True, time_offset=time_counter+2) + "\n"
        # D (Duplicate)
        tests_md += generate_telemetry_json(r['uid'], r['title'], r['class'], r['category'], tcode+"D", True, time_offset=time_counter) + "\n"
        time_counter += 10
    tests_md += "```\n"

    return tests_md


for filename in os.listdir(directory):
    if not filename.endswith(".md"):
        continue
        
    filepath = os.path.join(directory, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
        
    # Handle the undetectable rule
    if filename == "AN2038-T1687-DET0900.md":
        content = content.replace("### 3. Blind Spots", "### 4. Blind Spots")
        if "### 5. Test Cases" not in content:
            test_case_note = "*Note: Sensor tampering techniques lack endpoint observability natively. OCSF normalized rules, test cases, and telemetry datasets are intentionally omitted to preserve pipeline integrity.*"
            telemetry_note = "*Note: Intentionally omitted for undetectable defense impairment techniques.*"
            content += f"\n\n---\n\n### 5. Test Cases (Engine Pipeline Verification)\n\n{test_case_note}\n\n---\n\n### 6. Raw Telemetry Dataset (OCSF JSON)\n\n{telemetry_note}\n"
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Processed Undetectable File: {filename}")
        continue

    # Handle detectable rules
    if "OCSF Normalized Rule" in content and "### 5. Test Cases" not in content:
        ocsf_sections = content.split("OCSF Normalized Rule")[1]
        
        # Split by ``` to get the blocks
        blocks = ocsf_sections.split("```")
        
        parsed_rules = []
        for i in range(1, len(blocks), 2): # Odd indices are inside the code blocks
            block = blocks[i]
            if "id:" in block and "title:" in block:
                try:
                    uid_match = re.search(r'id:\s*[\'"]?([a-fA-F0-9\-]+)[\'"]?', block)
                    uid = uid_match.group(1).strip() if uid_match else "UNKNOWN_ID"
                    
                    title_match = re.search(r'title:\s*[\'"]?(.+?)[\'"]?\n', block)
                    title = title_match.group(1).strip() if title_match else "UNKNOWN_TITLE"
                    
                    cls_match = re.search(r'class:\s*(.+)', block)
                    cls_name = cls_match.group(1).strip() if cls_match else "UNKNOWN"
                    
                    cat_match = re.search(r'category:\s*(.+)', block)
                    cat_name = cat_match.group(1).strip() if cat_match else "UNKNOWN"
                    
                    parsed_rules.append({"uid": uid, "title": title, "class": cls_name, "category": cat_name})
                except Exception as e:
                    print(f"Error parsing rule in {filename}: {e}")
                    
        if not parsed_rules:
            print(f"Failed to parse any rules in {filename}")
            continue
            
        # Generate Tests
        test_section = generate_test_sections(parsed_rules)
        
        # Fix formatting headers globally
        content = content.replace("### 3. Blind Spots", "### 4. Blind Spots")
        content = content.replace("### 4. Blind Spots & Tuning (The \"Problems\")", "### 4. Blind Spots & Tuning (The \"Problems\")")
        
        # Inject Test Cases
        if "### 4. Blind Spots" in content:
            content += "\n\n---\n\n" + test_section
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Processed Detectable File: {filename} ({len(parsed_rules)} rules injected)")
        
print("Done processing defense-impairment directory.")
